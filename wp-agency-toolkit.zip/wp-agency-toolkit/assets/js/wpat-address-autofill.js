/**
 * AUTOCOMPLETADO RECÍPROCO DE CP, PROVINCIA Y POBLACIÓN (DROPDOWN REAL) - WP AGENCY TOOLKIT
 */
jQuery(document).ready(function($) {
	'use strict';

	if (typeof wpatAutofillOptions === 'undefined' || !wpatAutofillOptions.spain_provinces) {
		return;
	}

	var isProgrammatic = false;

	function isCountrySpain(type) {
		var $countryField = $('#' + type + '_country');
		if (!$countryField.length) {
			if (type === 'shipping') {
				return isCountrySpain('billing');
			}
			return true;
		}

		var val = $countryField.val() || $countryField.attr('value') || '';
		val = $.trim(val).toUpperCase();

		if (!val || val === 'ES' || val === 'SPAIN' || val === 'ESPAÑA') {
			return true;
		}

		var text = $('#' + type + '_country_field').text() || '';
		if (text.indexOf('España') !== -1 || text.indexOf('Spain') !== -1) {
			return true;
		}

		return false;
	}

	function sanitizeKey(str) {
		if (!str) return '';
		return str.toLowerCase()
			.replace(/[áàäâ]/g, 'a')
			.replace(/[éèëê]/g, 'e')
			.replace(/[íìïî]/g, 'i')
			.replace(/[óòöô]/g, 'o')
			.replace(/[úùüû]/g, 'u')
			.replace(/ñ/g, 'n')
			.replace(/[^a-z0-9]/g, '');
	}

	function getProvinceCodeFromVal(stateVal) {
		if (!stateVal) return '';
		var pCode = stateVal;
		$.each(wpatAutofillOptions.spain_provinces, function(prefix, data) {
			if (data.code === stateVal || data.name.toLowerCase() === stateVal.toLowerCase()) {
				pCode = data.code;
				return false;
			}
		});
		return pCode;
	}

	function convertCityToSelect(type, towns, currentVal) {
		var $cityField = $('#' + type + '_city');
		if (!$cityField.length) return;

		// Si ya es un select o un input, construimos las opciones
		var nameAttr = $cityField.attr('name') || (type + '_city');
		var idAttr = $cityField.attr('id') || (type + '_city');

		var $select = $('<select name="' + nameAttr + '" id="' + idAttr + '" class="input-text wpat-city-select" style="width:100%; height:46px; border:1px solid #cbd5e1; border-radius:8px; padding:0 14px; font-size:14px; color:#0f172a; background:#ffffff; outline:none; appearance:none; -webkit-appearance:none; background-image:url(\'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 fill=%22none%22 viewBox=%220 0 24 24%22 stroke=%22%2364748b%22%3E%3Cpath stroke-linecap=%22round%22 stroke-linejoin=%22round%22 stroke-width=%222%22 d=%22M19 9l-7 7-7-7%22%3E%3C/path%3E%3C/svg%3E\'); background-repeat:no-repeat; background-position:right 12px center; background-size:16px 16px;"></select>');

		$select.append('<option value="">Selecciona tu población...</option>');

		var foundMatch = false;
		if (towns && towns.length) {
			$.each(towns, function(i, town) {
				var selectedAttr = '';
				if (currentVal && (town.toLowerCase() === currentVal.toLowerCase() || sanitizeKey(town) === sanitizeKey(currentVal))) {
					selectedAttr = ' selected="selected"';
					foundMatch = true;
				}
				$select.append('<option value="' + town + '"' + selectedAttr + '>' + town + '</option>');
			});
		}

		if (currentVal && !foundMatch && currentVal !== '__custom__') {
			$select.append('<option value="' + currentVal + '" selected="selected">' + currentVal + '</option>');
		}

		$select.append('<option value="__custom__">✏️ Otra población (Escribir manualmente)...</option>');

		if ($cityField.is('input')) {
			$cityField.replaceWith($select);
		} else if ($cityField.is('select')) {
			$cityField.html($select.html());
			if (currentVal && foundMatch) {
				$cityField.val(currentVal);
			}
		}
	}

	function convertCityToInput(type, currentVal) {
		var $cityField = $('#' + type + '_city');
		if (!$cityField.length || $cityField.is('input')) return;

		var nameAttr = $cityField.attr('name') || (type + '_city');
		var idAttr = $cityField.attr('id') || (type + '_city');

		var $input = $('<input type="text" name="' + nameAttr + '" id="' + idAttr + '" class="input-text" style="width:100%; height:46px; border:1px solid #cbd5e1; border-radius:8px; padding:10px 14px; font-size:14px; color:#0f172a; background:#ffffff; outline:none;" placeholder="Escribe tu población..." />');
		if (currentVal && currentVal !== '__custom__') {
			$input.val(currentVal);
		}

		$cityField.replaceWith($input);
		$input.focus();
	}

	// --- 1. CP -> PROVINCIA Y POBLACIÓN ---
	function handlePostcodeChange(type) {
		if (isProgrammatic || !isCountrySpain(type)) return;

		var $postcodeField = $('#' + type + '_postcode');
		if (!$postcodeField.length) return;

		var cp = $.trim($postcodeField.val() || '');
		if (cp.length < 2) return;

		isProgrammatic = true;

		// 1A. Detectar Provincia con 2 dígitos
		var prefix2 = cp.substring(0, 2);
		var provinceData = wpatAutofillOptions.spain_provinces[prefix2];

		if (provinceData) {
			var pCode = provinceData.code;
			var pName = provinceData.name;
			var $stateField = $('#' + type + '_state');

			if ($stateField.length) {
				if ($stateField.is('select')) {
					var $opt = $stateField.find('option[value="' + pCode + '"]');
					if (!$opt.length && pName) {
						$opt = $stateField.find('option').filter(function() {
							return $(this).text().toLowerCase().indexOf(pName.toLowerCase()) !== -1;
						});
					}
					if ($opt.length && $stateField.val() !== $opt.val()) {
						$stateField.val($opt.val()).trigger('change');
						if ($.fn.select2) {
							$stateField.trigger('change.select2');
						}
					}
				} else {
					if ($stateField.val() !== pName && $stateField.val() !== pCode) {
						$stateField.val(pName).trigger('change');
					}
				}
			}

			// Actualizar el desplegable de poblaciones de esa provincia
			var towns = wpatAutofillOptions.spain_province_cities ? wpatAutofillOptions.spain_province_cities[pCode] : null;
			var currentCityVal = $('#' + type + '_city').val();

			// 1B. Detectar ciudad específica si tenemos 3 o 5 dígitos de CP (ej: 114 -> Jerez de la Frontera)
			var prefix3 = cp.substring(0, 3);
			var matchedCity = wpatAutofillOptions.spain_prefix_to_city ? wpatAutofillOptions.spain_prefix_to_city[prefix3] : null;

			if (matchedCity) {
				currentCityVal = matchedCity;
			}

			convertCityToSelect(type, towns, currentCityVal);

			if (matchedCity) {
				$('#' + type + '_city').val(matchedCity);
			}
		}

		isProgrammatic = false;
	}

	// --- 2. PROVINCIA / POBLACIÓN -> CÓDIGO POSTAL (RECÍPROCO) ---
	function handleCityOrStateChange(type) {
		if (isProgrammatic || !isCountrySpain(type)) return;

		var $stateField = $('#' + type + '_state');
		var stateVal = $.trim($stateField.val() || '');
		var pCode = getProvinceCodeFromVal(stateVal);

		var $cityField = $('#' + type + '_city');
		var cityVal = $.trim($cityField.val() || '');

		if (cityVal === '__custom__') {
			convertCityToInput(type, '');
			return;
		}

		isProgrammatic = true;

		// Si se cambió la provincia pero no la ciudad, cargar desplegable de la provincia
		if (pCode && wpatAutofillOptions.spain_province_cities && wpatAutofillOptions.spain_province_cities[pCode]) {
			if ($cityField.is('input') || !$cityField.find('option[value="' + cityVal + '"]').length) {
				var towns = wpatAutofillOptions.spain_province_cities[pCode];
				convertCityToSelect(type, towns, cityVal);
				$cityField = $('#' + type + '_city');
			}
		}

		// Buscar el Código Postal correspondiente a la población elegida
		if (cityVal && cityVal !== '__custom__' && pCode) {
			var key1 = sanitizeKey(cityVal) + '_' + pCode.toLowerCase();
			var key2 = sanitizeKey(cityVal);
			var matchedCP = null;

			if (wpatAutofillOptions.spain_city_to_cp) {
				matchedCP = wpatAutofillOptions.spain_city_to_cp[key1] || wpatAutofillOptions.spain_city_to_cp[key2];
			}

			if (matchedCP) {
				var $postcodeField = $('#' + type + '_postcode');
				if ($postcodeField.length && $postcodeField.val() !== matchedCP) {
					$postcodeField.val(matchedCP).trigger('change');
				}
			}
		}

		isProgrammatic = false;
	}

	// Escuchadores de eventos
	$(document).on('input keyup blur change', '#billing_postcode', function() {
		handlePostcodeChange('billing');
	});

	$(document).on('input keyup blur change', '#shipping_postcode', function() {
		handlePostcodeChange('shipping');
	});

	$(document).on('change', '#billing_state', function() {
		handleCityOrStateChange('billing');
	});

	$(document).on('change', '#shipping_state', function() {
		handleCityOrStateChange('shipping');
	});

	$(document).on('change', '#billing_city', function() {
		handleCityOrStateChange('billing');
	});

	$(document).on('change', '#shipping_city', function() {
		handleCityOrStateChange('shipping');
	});

	$(document).on('change', '#ship-to-different-address-checkbox', function() {
		if ($(this).is(':checked')) {
			setTimeout(function() {
				handleCityOrStateChange('shipping');
			}, 200);
		}
	});

	// Inicialización al cargar la página
	setTimeout(function() {
		handleCityOrStateChange('billing');
		handleCityOrStateChange('shipping');
	}, 400);
});
