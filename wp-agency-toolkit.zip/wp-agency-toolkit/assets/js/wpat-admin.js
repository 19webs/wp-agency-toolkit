/**
 * Script de Administración - WP Agency Toolkit
 */

jQuery(document).ready(function($) {
	
	// Helper global para mostrar notificaciones flotantes (Toast)
	window.showToast = function(message, type) {
		$('.wpat-toast').remove(); // Evitar duplicados
		var bg = '#10b981'; // Verde por defecto para éxito/activación
		
		if (type === true || type === 'error') {
			bg = '#ea580c'; // Naranja para errores
		} else if (type === 'deactivate') {
			bg = '#ef4444'; // Rojo con la misma tonalidad moderna para desactivación
		}

		var $toast = $('<div class="wpat-toast" style="position: fixed; top: 55px; right: 25px; background: ' + bg + '; color: #fff; padding: 12px 22px; border-radius: 8px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.2); z-index: 999999; font-weight: 600; font-size: 13.5px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 16px; font-weight: bold;">✓</span> ' + message + '</div>');
		$('body').append($toast);
		$toast.fadeIn(300).delay(2600).fadeOut(400, function() {
			$(this).remove();
		});
	};
	var showToast = window.showToast;
	
	// Detectar si la URL contiene settings-updated=true y mostrar el aviso flotante (Toast)
	var urlParams = new URLSearchParams(window.location.search);
	if (urlParams.get('settings-updated') === 'true' || urlParams.get('settings-updated') === '1') {
		showToast('Cambios guardados correctamente', false);
	}

	// Record scroll position when clicking module action buttons or submitting forms
	$(document).on('click', '.wpat-remember-scroll-btn, .wpat-back-bar a, button[type="submit"], input[type="submit"]', function() {
		sessionStorage.setItem('wpat_scroll_y', window.scrollY || window.pageYOffset);
	});
	$(document).on('submit', 'form', function() {
		sessionStorage.setItem('wpat_scroll_y', window.scrollY || window.pageYOffset);
	});

	// Restore scroll position without jump on DOM ready
	var savedScrollY = sessionStorage.getItem('wpat_scroll_y');
	if (savedScrollY !== null && savedScrollY !== undefined) {
		window.scrollTo(0, parseInt(savedScrollY, 10));
		sessionStorage.removeItem('wpat_scroll_y');
	}

	// 1. Control de Pestañas (Tabs)
	$('.wpat-tab-link').on('click', function(e) {
		e.preventDefault();
		
		var targetTab = $(this).data('tab');
		
		// Activar enlace
		$('.wpat-tab-link').removeClass('active');
		$(this).addClass('active');
		
		// Mostrar panel correspondiente
		$('.wpat-tab-panel').removeClass('active');
		$('#' + targetTab).addClass('active');
		
		// Guardar pestaña activa en input hidden y localStorage
		$('#wpat_active_tab_input').val(targetTab);
		localStorage.setItem('wpat_active_tab', targetTab);
	});

	// Control de Sub-Pestañas internas dentro de módulos (ej: Checkout vs Carrito)
	$(document).on('click', '.wpat-subtab-nav-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var target = $btn.data('subtab');
		var $parent = $btn.closest('.wpat-module-body');

		$parent.find('.wpat-subtab-nav-btn').removeClass('active').css({
			'border-bottom-color': 'transparent',
			'color': '#64748b'
		});
		$btn.addClass('active').css({
			'border-bottom-color': '#2563eb',
			'color': '#2563eb'
		});

		$parent.find('.wpat-subtab-content').hide();
		$parent.find('#wpat-subtab-' + target).show();

		// Actualizar valor de input oculto para persistencia al guardar
		$parent.find('.wpat-active-subtab-input').val(target);
		localStorage.setItem('wpat_active_subtab', target);
	});

	// Estilizado dinámico para selección de plantillas de Carrito
	$(document).on('change', '.wpat-cart-layout-card input[type="radio"]', function() {
		$('.wpat-cart-layout-card').removeClass('active').css('border-color', 'var(--wpat-border, #e2e8f0)');
		$(this).closest('.wpat-cart-layout-card').addClass('active').css('border-color', '#2563eb');
	});

	// Estilizado dinámico para selección de plantillas de Email
	$(document).on('change', '.wpat-email-layout-card input[type="radio"]', function() {
		$('.wpat-email-layout-card').removeClass('active').css('border-color', 'var(--wpat-border, #e2e8f0)');
		$(this).closest('.wpat-email-layout-card').addClass('active').css('border-color', '#2563eb');
	});

	// Rastreador del último campo de texto activo en el Diseñador de Emails
	var lastFocusedEmailField = null;
	$(document).on('focus', '.wpat-email-input-field, textarea[name="wpat_settings[woo_email_footer_text]"]', function() {
		lastFocusedEmailField = this;
	});

	// Inserción interactiva con un solo clic de Etiquetas Dinámicas
	$(document).on('click', '.wpat-tag-pill-btn', function(e) {
		e.preventDefault();
		var tag = $(this).data('tag');
		var targetField = lastFocusedEmailField;

		if (!targetField || !document.body.contains(targetField)) {
			targetField = $('#wpat_email_field_intro')[0] || $('#wpat_email_field_welcome')[0];
		}

		if (targetField) {
			var startPos = typeof targetField.selectionStart === 'number' ? targetField.selectionStart : targetField.value.length;
			var endPos = typeof targetField.selectionEnd === 'number' ? targetField.selectionEnd : targetField.value.length;
			var val = targetField.value;

			targetField.value = val.substring(0, startPos) + tag + val.substring(endPos);
			if (typeof targetField.selectionStart === 'number') {
				targetField.selectionStart = targetField.selectionEnd = startPos + tag.length;
			}
			targetField.focus();
			$(targetField).trigger('change');

			var $tf = $(targetField);
			$tf.css('transition', 'background-color 0.2s').css('background-color', '#ecfdf5');
			setTimeout(function() {
				$tf.css('background-color', '');
			}, 400);

			showToast('Etiqueta ' + tag + ' insertada', false);
		}
	});

	// Carga de imágenes con wp.media (Subir Logotipo)
	$(document).on('click', '.wpat-upload-image-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var targetSelector = $btn.data('target');
		var $input = $(targetSelector);

		if (typeof wp !== 'undefined' && wp.media) {
			var mediaUploader = wp.media({
				title: 'Seleccionar Logotipo para Correos',
				button: { text: 'Usar este logotipo' },
				multiple: false
			});

			mediaUploader.on('select', function() {
				var attachment = mediaUploader.state().get('selection').first().toJSON();
				if (attachment && attachment.url) {
					$input.val(attachment.url).trigger('change');
				}
			});

			mediaUploader.open();
		} else {
			alert('El selector de medios de WordPress no está disponible.');
		}
	});
	
	// Restaurar pestaña activa guardada en localStorage (solo si no se pasó tab por URL)
	var urlParams = new URLSearchParams(window.location.search);
	if (!urlParams.has('tab')) {
		var activeTab = localStorage.getItem('wpat_active_tab');
		var currentActiveInHtml = $('.wpat-tab-link.active').data('tab');
		if (activeTab && $('#' + activeTab).length && activeTab !== currentActiveInHtml) {
			$('.wpat-tab-link[data-tab="' + activeTab + '"]').click();
		}
	}

	// 1.1 Centro de Módulos v4.0.0 (Buscador, Categorías y AJAX Toggle)
	$(document).on('change', '.wpat-ajax-toggle-module', function() {
		var $checkbox = $(this);
		var moduleId  = $checkbox.data('module');
		var isChecked = $checkbox.is(':checked');
		var state     = isChecked ? '1' : '0';
		var nonce     = $('#wpat_settings_nonce').val();
		var $card     = $checkbox.closest('.wpat-module-grid-card');
		var $status   = $card.find('.wpat-module-status-indicator');
		var $btn      = $card.find('.wpat-card-action-btn.primary');

		$card.css('opacity', '0.7');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_toggle_module',
				security: nonce,
				module_id: moduleId,
				state: state
			},
			success: function(response) {
				$card.css('opacity', '1');
				if (response.success) {
					if (isChecked) {
						$status.addClass('active').find('.text').text('Activo');
						$btn.removeClass('disabled');
						showToast('Módulo activado', false);
					} else {
						$status.removeClass('active').find('.text').text('Inactivo');
						$btn.addClass('disabled');
						showToast('Módulo desactivado', 'deactivate');
					}
				} else {
					$checkbox.prop('checked', !isChecked);
					showToast('Error al actualizar módulo: ' + (response.data ? response.data.message : 'Error'), true);
				}
			},
			error: function() {
				$card.css('opacity', '1');
				$checkbox.prop('checked', !isChecked);
				showToast('Error de conexión al cambiar el módulo.', true);
			}
		});
	});

	// 1.1 Centro de Módulos (Buscador, Categorías y AJAX Toggle)
	var validCategories = ['all', 'woocommerce', 'security', 'performance', 'tools', 'system'];

	function removeAccents(str) {
		if (!str) return '';
		return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
	}

	function getWordRoot(word) {
		var w = removeAccents(word.toLowerCase());
		if (w.length > 4) {
			w = w.replace(/(es|er|ar|ir|ción|cion|dor|dora|do|da|dos|das|s)$/g, '');
		}
		return w;
	}

	function matchesModuleSearch(searchableText, query) {
		if (!query) return true;

		var normQuery = removeAccents(query.toLowerCase());
		var normText = removeAccents(searchableText.toLowerCase());

		var tokens = normQuery.split(/\s+/).filter(Boolean);

		return tokens.every(function(token) {
			if (normText.indexOf(token) !== -1) {
				return true;
			}
			var root = getWordRoot(token);
			if (root.length >= 3 && normText.indexOf(root) !== -1) {
				return true;
			}
			return false;
		});
	}

	function filterModules() {
		var cat = window.wpatActiveCat || 'all';
		var query = $('#wpat_modules_search_input').length ? $('#wpat_modules_search_input').val().trim() : '';
		var visibleCount = 0;

		$('.wpat-module-grid-card').each(function() {
			var $card = $(this);
			var cardClasses = $card.attr('class') || '';

			var matchesCategory = (cat === 'all' || $card.hasClass('cat-' + cat) || $card.hasClass(cat) || cardClasses.indexOf('cat-' + cat) !== -1);
			
			var searchableText = ($card.attr('data-search') || '') + ' ' + ($card.attr('data-name') || '') + ' ' + $card.find('h3').text() + ' ' + $card.find('p').text() + ' ' + ($card.find('.wpat-ajax-toggle-module').attr('data-module') || '');

			var matchesSearch = matchesModuleSearch(searchableText, query);

			if (matchesCategory && matchesSearch) {
				$card.css('display', 'flex').show();
				visibleCount++;
			} else {
				$card.hide();
			}
		});

		var $grid = $('#wpat_modules_grid');
		var $noResults = $('#wpat_no_modules_found');
		if (visibleCount === 0) {
			if (!$noResults.length) {
				$grid.append('<div id="wpat_no_modules_found" style="text-align: center; padding: 45px 20px; grid-column: 1 / -1; color: #64748b; background: var(--wpat-card-bg, #fff); border: 1px dashed var(--wpat-border, #cbd5e1); border-radius: 12px; margin-top: 10px;"><span class="dashicons dashicons-search" style="font-size: 36px; width: 36px; height: 36px; color: #94a3b8; margin-bottom: 10px; display: inline-block;"></span><h4 style="margin: 0 0 6px 0; font-size: 16px; font-weight: 700;">No se encontraron módulos</h4><p style="margin: 0; font-size: 13px; color: #94a3b8;">Prueba con otros términos de búsqueda o cambia el filtro de categoría.</p></div>');
			} else {
				$noResults.show();
			}
		} else {
			if ($noResults.length) {
				$noResults.hide();
			}
		}
	}

	// Función central para aplicar filtrado por Categoría
	function applyCategoryFilter(cat) {
		if (!cat || cat === 'undefined' || cat === 'null' || validCategories.indexOf(cat) === -1) {
			cat = 'all';
		}
		window.wpatActiveCat = cat;

		$('.wpat-cat-item, .wpat-cat-pill').removeClass('active');
		$('.wpat-cat-item[data-cat="' + cat + '"], .wpat-cat-pill[data-cat="' + cat + '"]').addClass('active');
		$('#wpat_mobile_cat_select').val(cat);

		localStorage.setItem('wpat_active_cat', cat);
		sessionStorage.setItem('wpat_active_cat', cat);

		$('.wpat-card-action-btn').each(function() {
			var href = $(this).attr('href');
			if (href) {
				href = href.replace(/&cat=[^&]*/g, '') + '&cat=' + encodeURIComponent(cat);
				$(this).attr('href', href);
			}
		});

		filterModules();
	}

	// Clics en la Navegación Vertical o Pills
	$(document).on('click', '.wpat-cat-item, .wpat-cat-pill', function(e) {
		var $item = $(this).closest('[data-cat]');
		if ($item.length) {
			e.preventDefault();
			e.stopPropagation();
			var cat = $item.attr('data-cat') || $item.data('cat');
			if (cat) {
				applyCategoryFilter(cat);
			}
		}
	});

	// Cambio en el Selector Desplegable Móvil
	$(document).on('change', '#wpat_mobile_cat_select', function(e) {
		e.preventDefault();
		var cat = $(this).val();
		if (cat) {
			applyCategoryFilter(cat);
		}
	});

	// Buscador en Vivo en Centro de Módulos
	$(document).on('keyup input search', '#wpat_modules_search_input', function() {
		filterModules();
	});

	// Restaurar Categoría Activa al Cargar la Página
	var urlParams = new URLSearchParams(window.location.search);
	var savedCat = urlParams.get('cat') || localStorage.getItem('wpat_active_cat') || sessionStorage.getItem('wpat_active_cat');
	if (savedCat && validCategories.indexOf(savedCat) !== -1) {
		applyCategoryFilter(savedCat);
	} else {
		applyCategoryFilter('all');
	}

	// LÓGICA MODO CLARO / MODO OSCURO (DARK MODE)
	function applyThemeMode(theme) {
		if (theme === 'dark') {
			$('body, html, .wpat-admin-wrapper').addClass('wpat-dark-mode');
			document.documentElement.classList.add('wpat-dark-mode');
			document.cookie = "wpat_theme_mode=dark; path=/; max-age=31536000";
			$('#wpat_theme_icon').text('🌙');
			$('#wpat_theme_label').text('Modo Claro');
			localStorage.setItem('wpat_theme_mode', 'dark');
		} else {
			$('body, html, .wpat-admin-wrapper').removeClass('wpat-dark-mode');
			document.documentElement.classList.remove('wpat-dark-mode');
			document.cookie = "wpat_theme_mode=light; path=/; max-age=31536000";
			$('#wpat_theme_icon').text('☀️');
			$('#wpat_theme_label').text('Modo Oscuro');
			localStorage.setItem('wpat_theme_mode', 'light');
		}
	}

	$(document).on('click', '#wpat_theme_toggle_btn', function(e) {
		e.preventDefault();
		var currentTheme = localStorage.getItem('wpat_theme_mode') === 'dark' || $('html').hasClass('wpat-dark-mode') ? 'dark' : 'light';
		var newTheme = currentTheme === 'dark' ? 'light' : 'dark';
		applyThemeMode(newTheme);
	});

	var savedTheme = localStorage.getItem('wpat_theme_mode');
	if (savedTheme === 'dark' || document.cookie.indexOf('wpat_theme_mode=dark') !== -1) {
		applyThemeMode('dark');
	} else if (savedTheme === 'light') {
		applyThemeMode('light');
	}

	// Restaurar kit activo si estaba guardado en sessionStorage
	var activeKitSlug = sessionStorage.getItem('wpat_active_kit_slug');
	if (activeKitSlug) {
		setTimeout(function() {
			var $btn = $('.wpat-view-kit-templates-btn[data-slug="' + activeKitSlug + '"]');
			if ($btn.length) {
				$btn.trigger('click');
			}
		}, 150);
	}
	
	

	// Auto-guardar si es un conmutador principal de módulo (dentro de .wpat-module-header)
	$(document).on('change', '.wpat-module-header input[type="checkbox"]', function() {
		var $checkbox = $(this);
		var $card = $checkbox.closest('.wpat-module-card, .wpat-card, .wpat-module-header');
		var $body = $card.find('.wpat-module-body, .wpat-card-body');
		var nameAttr = $checkbox.attr('name');
		if (nameAttr) {
			var match = nameAttr.match(/wpat_settings\[(.*?)\]/);
			if (match) {
				var moduleId = match[1];
				var state = $checkbox.is(':checked') ? '1' : '0';
				var nonce = $('#wpat_settings_nonce').val();

				// Efecto visual de guardando
				$card.css('opacity', '0.7');

				$.ajax({
					url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
					type: 'POST',
					data: {
						action: 'wpat_toggle_module',
						security: nonce,
						module_id: moduleId,
						state: state
					},
					success: function(response) {
						$card.css('opacity', '1');
						if (response.success) {
							if (state === '1') {
								showToast('Módulo activado', false);
							} else {
								showToast('Módulo desactivado', 'deactivate');
							}
						} else {
							// Revertir interruptor
							$checkbox.prop('checked', state === '0');
							if (state === '0') { $body.slideDown(250); } else { $body.slideUp(250); }
							showToast('Error al actualizar módulo: ' + (response.data ? response.data.message : 'Error desconocido'), true);
						}
					},
					error: function() {
						$card.css('opacity', '1');
						$checkbox.prop('checked', state === '0');
						if (state === '0') { $body.slideDown(250); } else { $body.slideUp(250); }
						showToast('Error de conexión al guardar el estado.', true);
					}
				});
			}
		}
	});

	// 3. Inicializar Selector de Color (Color Picker)
	if ($.fn.wpColorPicker) {
		$('.wpat-color-picker').wpColorPicker();
	}

	// 4. Cargador de Medios de WordPress para el Logotipo
	var custom_uploader;
	
	$('#wpat_login_logo_btn').on('click', function(e) {
		e.preventDefault();
		
		// Si el uploader ya existe, abrirlo
		if (custom_uploader) {
			custom_uploader.open();
			return;
		}
		
		// Crear el uploader de medios
		custom_uploader = wp.media.frames.file_frame = wp.media({
			title: 'Seleccionar Logotipo para la pantalla de Login',
			button: {
				text: 'Usar este Logo'
			},
			multiple: false
		});
		
		// Acción al seleccionar un archivo
		custom_uploader.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			
			// Guardar URL en el input
			$('#wpat_login_logo').val(attachment.url);
			
			// Mostrar vista previa
			var $preview = $('#wpat_login_logo_preview');
			$preview.html('<img src="' + attachment.url + '" alt="Logo de Login" />').show();
			
			// Mostrar botón de eliminar
			$('#wpat_login_logo_remove').show();
		});
		
		// Abrir modal
		custom_uploader.open();
	});
	
	// Eliminar logotipo seleccionado
	$('#wpat_login_logo_remove').on('click', function(e) {
		e.preventDefault();
		
		$('#wpat_login_logo').val('');
		$('#wpat_login_logo_preview').html('').hide();
		$(this).hide();
	});

	// Selector de imagen de fondo de login moderno
	var bg_uploader;
	$('#wpat_login_bg_image_btn').on('click', function(e) {
		e.preventDefault();
		if (bg_uploader) {
			bg_uploader.open();
			return;
		}
		bg_uploader = wp.media.frames.file_frame = wp.media({
			title: 'Seleccionar Imagen de Fondo para el Login',
			button: {
				text: 'Usar esta Imagen'
			},
			multiple: false
		});
		bg_uploader.on('select', function() {
			var attachment = bg_uploader.state().get('selection').first().toJSON();
			$('#wpat_login_bg_image').val(attachment.url);
			var $preview = $('#wpat_login_bg_image_preview');
			$preview.html('<img src="' + attachment.url + '" style="max-width:200px; max-height:100px; display:block; border-radius:4px;" />').show();
			$('#wpat_login_bg_image_remove').show();
		});
		bg_uploader.open();
	});
	
	$('#wpat_login_bg_image_remove').on('click', function(e) {
		e.preventDefault();
		$('#wpat_login_bg_image').val('');
		$('#wpat_login_bg_image_preview').html('').hide();
		$(this).hide();
	});

	// Mostrar/Ocultar campos avanzados según el estilo de login seleccionado
	$('#wpat_login_style').on('change', function() {
		if ($(this).val() === 'modern') {
			$('.wpat-modern-login-subfields').slideDown(250);
		} else {
			$('.wpat-modern-login-subfields').slideUp(250);
		}
	}).trigger('change');

	// Mostrar/Ocultar cargador de imagen de fondo según el tipo de fondo seleccionado
	$('#wpat_login_bg_type').on('change', function() {
		if ($(this).val() === 'image') {
			$('.wpat-login-bg-image-group').slideDown(200);
		} else {
			$('.wpat-login-bg-image-group').slideUp(200);
		}
	}).trigger('change');

	// 5. Ocultar/Mostrar subcampos de límite de intentos de login
	$('#wpat_hide_login_limit_attempts').on('change', function() {
		var $subfields = $(this).closest('.wpat-module-body').find('.wpat-sub-field');
		if ($(this).is(':checked')) {
			$subfields.slideDown(200);
		} else {
			$subfields.slideUp(200);
		}
	});

	// 6. Optimización masiva retroactiva de imágenes por lotes AJAX
	var imagesToOptimizeIds = [];
	var totalImagesToOptimize = 0;
	var optimizedSuccessCount = 0;
	var optimizedFailedCount = 0;
	var currentOptimizeIndex = 0;

	// Acción: Escanear biblioteca
	$('#wpat_scan_images_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);

		var selectedFormats = [];
		$('.wpat-bulk-format-cb:checked').each(function() {
			selectedFormats.push($(this).val());
		});

		if (selectedFormats.length === 0) {
			alert('Debes seleccionar al menos un formato de imagen a escanear (JPG, PNG o GIF).');
			return;
		}

		$btn.prop('disabled', true).text('Escaneando...');
		$('#wpat_start_bulk_btn').hide();
		$('#wpat_bulk_status').hide();

		var minSize = $('#wpat_bulk_filter_min_size').val();
		var dateStart = $('#wpat_bulk_filter_date_start').val();
		var dateEnd = $('#wpat_bulk_filter_date_end').val();

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_scan_images',
				min_size: minSize,
				date_start: dateStart,
				date_end: dateEnd,
				formats: selectedFormats
			},
			success: function(response) {
				$btn.prop('disabled', false).text('Escanear Biblioteca');
				
				if (response.success) {
					imagesToOptimizeIds = response.data.ids;
					totalImagesToOptimize = response.data.count;
					optimizedSuccessCount = 0;
					optimizedFailedCount = 0;
					currentOptimizeIndex = 0;

					// Actualizar interfaz
					$('#wpat_stat_pending').text(totalImagesToOptimize);
					$('#wpat_stat_processed').text(0);
					$('#wpat_stat_failed').text(0);
					$('#wpat_bulk_progress_fill').css('width', '0%');
					$('#wpat_bulk_progress_percent').text('0%');
					
					if (totalImagesToOptimize > 0) {
						$('#wpat_stat_total_weight').text(response.data.total_bytes_pref);
						$('#wpat_stat_opt_weight').text(response.data.est_opt_bytes_f);
						$('#wpat_stat_weight_container').show();
					} else {
						$('#wpat_stat_weight_container').hide();
					}

					$('#wpat_bulk_log').html('<div>[Escaneo completado. Encontradas ' + totalImagesToOptimize + ' imágenes que coinciden con los filtros.]</div>');
					$('#wpat_bulk_status').slideDown(200);

					if (totalImagesToOptimize > 0) {
						$('#wpat_start_bulk_btn').show();
					} else {
						$('#wpat_bulk_log').append('<div>[No hay imágenes que requieran optimización con los filtros aplicados.]</div>');
					}
				} else {
					alert('Error al escanear la biblioteca: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Escanear Biblioteca');
				alert('Fallo en la comunicación con el servidor.');
			}
		});
	});

	// Acción: Iniciar Optimización
	$('#wpat_start_bulk_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		$btn.prop('disabled', true).text('Procesando...');
		$('#wpat_scan_images_btn').prop('disabled', true);
		
		$('#wpat_bulk_log').append('<div>[Iniciando proceso de conversión...]</div>');
		
		runOptimizationBatch($btn);
	});

	function runOptimizationBatch($startBtn) {
		if (currentOptimizeIndex >= imagesToOptimizeIds.length) {
			$('#wpat_bulk_log').append('<div style="color:var(--wpat-success); font-weight:bold;">[Proceso completado. ' + optimizedSuccessCount + ' imágenes procesadas con éxito.]</div>');
			$startBtn.hide().prop('disabled', false).text('Iniciar Optimización');
			$('#wpat_scan_images_btn').prop('disabled', false);
			return;
		}

		// Tomar lote de 5 IDs
		var batchIds = imagesToOptimizeIds.slice(currentOptimizeIndex, currentOptimizeIndex + 5);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_optimize_image_batch',
				ids: batchIds
			},
			success: function(response) {
				if (response.success) {
					var data = response.data;
					
					// Acumular contadores e índice
					optimizedSuccessCount += parseInt(data.processed);
					optimizedFailedCount += parseInt(data.failed);
					currentOptimizeIndex += batchIds.length;
					
					// Escribir logs
					if (data.log && data.log.length > 0) {
						data.log.forEach(function(msg) {
							$('#wpat_bulk_log').append('<div>' + msg + '</div>');
						});
					}

					// Desplazar log al final
					var logBox = document.getElementById('wpat_bulk_log');
					if (logBox) {
						logBox.scrollTop = logBox.scrollHeight;
					}

					// Calcular restantes y porcentaje
					var remaining = Math.max(0, totalImagesToOptimize - currentOptimizeIndex);
					var percent = Math.round((currentOptimizeIndex / totalImagesToOptimize) * 100);
					percent = Math.min(100, Math.max(0, percent));

					// Actualizar estadísticas en UI
					$('#wpat_stat_pending').text(remaining);
					$('#wpat_stat_processed').text(optimizedSuccessCount);
					$('#wpat_stat_failed').text(optimizedFailedCount);
					$('#wpat_bulk_progress_fill').css('width', percent + '%');
					$('#wpat_bulk_progress_percent').text(percent + '%');

					// Siguiente lote
					setTimeout(function() {
						runOptimizationBatch($startBtn);
					}, 300);
				} else {
					$('#wpat_bulk_log').append('<div style="color:#ea580c;">[Error en lote: ' + (response.data ? response.data.message : 'Error de respuesta') + ']</div>');
					currentOptimizeIndex += batchIds.length;
					setTimeout(function() {
						runOptimizationBatch($startBtn);
					}, 300);
				}
			},
			error: function() {
				$('#wpat_bulk_log').append('<div style="color:#ea580c;">[Fallo de conexión en este lote. Reintentando...]</div>');
				setTimeout(function() {
					runOptimizationBatch($startBtn);
				}, 1000);
			}
		});
	}

	// --- LIMPIADOR DE IMÁGENES HUÉRFANAS (NO USADAS) ---
	var orphanCandidateIds = [];
	var totalOrphansScanned = 0;
	var orphansFoundCount = 0;
	var currentOrphanIndex = 0;
	var detectedOrphans = [];

	// Escanear huérfanas
	$('#wpat_scan_orphans_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		$btn.prop('disabled', true).text('Buscando...');
		$('#wpat_delete_selected_orphans_btn').hide();
		$('#wpat_orphans_results_wrapper').hide();
		$('#wpat_orphans_table_body').html('');
		$('#wpat_orphans_status').hide();
		
		orphanCandidateIds = [];
		detectedOrphans = [];
		totalOrphansScanned = 0;
		orphansFoundCount = 0;
		currentOrphanIndex = 0;

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_scan_unused_images'
			},
			success: function(response) {
				if (response.success) {
					orphanCandidateIds = response.data.ids;
					totalOrphansScanned = orphanCandidateIds.length;

					if (totalOrphansScanned > 0) {
						$('#wpat_orphans_stat_scanned').text(0);
						$('#wpat_orphans_stat_found').text(0);
						$('#wpat_orphans_progress_fill').css('width', '0%');
						$('#wpat_orphans_progress_percent').text('0%');
						$('#wpat_orphans_status').slideDown(200);
						
						runOrphansBatchScan($btn);
					} else {
						$btn.prop('disabled', false).text('Buscar Imágenes Huérfanas');
						alert('No se encontraron imágenes en la biblioteca para analizar.');
					}
				} else {
					$btn.prop('disabled', false).text('Buscar Imágenes Huérfanas');
					alert('Error al escanear: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Buscar Imágenes Huérfanas');
				alert('Fallo de conexión al escanear la biblioteca.');
			}
		});
	});

	function runOrphansBatchScan($scanBtn) {
		if (currentOrphanIndex >= orphanCandidateIds.length) {
			// Finalizado
			$scanBtn.prop('disabled', false).text('Buscar Imágenes Huérfanas');
			
			if (detectedOrphans.length > 0) {
				// Dibujar resultados
				renderOrphansTable();
				$('#wpat_orphans_results_wrapper').slideDown(200);
				$('#wpat_delete_selected_orphans_btn').show();
			} else {
				alert('¡Enhorabuena! Todas las imágenes de tu biblioteca están en uso.');
			}
			return;
		}

		var batchIds = orphanCandidateIds.slice(currentOrphanIndex, currentOrphanIndex + 20);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_check_unused_images_batch',
				ids: batchIds
			},
			success: function(response) {
				if (response.success) {
					var unusedList = response.data.unused;
					if (unusedList && unusedList.length > 0) {
						detectedOrphans = detectedOrphans.concat(unusedList);
						orphansFoundCount += unusedList.length;
					}

					currentOrphanIndex += batchIds.length;
					
					// Calcular porcentaje
					var percent = Math.round((currentOrphanIndex / totalOrphansScanned) * 100);
					percent = Math.min(100, Math.max(0, percent));

					// Actualizar interfaz
					$('#wpat_orphans_stat_scanned').text(currentOrphanIndex);
					$('#wpat_orphans_stat_found').text(orphansFoundCount);
					$('#wpat_orphans_progress_fill').css('width', percent + '%');
					$('#wpat_orphans_progress_percent').text(percent + '%');

					// Siguiente lote
					setTimeout(function() {
						runOrphansBatchScan($scanBtn);
					}, 150);
				} else {
					currentOrphanIndex += batchIds.length;
					setTimeout(function() {
						runOrphansBatchScan($scanBtn);
					}, 150);
				}
			},
			error: function() {
				// Reintentar en 1s
				setTimeout(function() {
					runOrphansBatchScan($scanBtn);
				}, 1000);
			}
		});
	}

	function renderOrphansTable() {
		var html = '';
		detectedOrphans.forEach(function(img) {
			var thumbHtml = img.url ? '<img src="' + img.url + '" style="width:40px; height:40px; object-fit:cover; border-radius:4px; border:1px solid #ddd;" />' : '<span class="dashicons dashicons-format-image" style="font-size:30px; width:30px; height:30px; color:#ccc;"></span>';
			
			html += '<tr>';
			html += '<td style="text-align:center; padding:10px; vertical-align:middle;"><input type="checkbox" class="wpat-orphan-checkbox" value="' + img.id + '" /></td>';
			html += '<td style="text-align:center; padding:10px; vertical-align:middle;">' + thumbHtml + '</td>';
			html += '<td style="padding:10px; vertical-align:middle;"><strong>' + img.name + '</strong><br/><span style="color:#94a3b8; font-size:11px;">ID: ' + img.id + '</span></td>';
			html += '<td style="padding:10px; vertical-align:middle;">' + img.size + '</td>';
			html += '<td style="padding:10px; vertical-align:middle;">' + img.date + '</td>';
			html += '</tr>';
		});
		$('#wpat_orphans_table_body').html(html);
	}

	// Seleccionar/Deseleccionar todas las huérfanas
	$(document).on('change', '#wpat_select_all_orphans', function() {
		var checked = $(this).is(':checked');
		$('.wpat-orphan-checkbox').prop('checked', checked);
	});

	// Eliminar seleccionadas
	$('#wpat_delete_selected_orphans_btn').on('click', function(e) {
		e.preventDefault();
		var selectedIds = [];
		$('.wpat-orphan-checkbox:checked').each(function() {
			selectedIds.push(parseInt($(this).val()));
		});

		if (selectedIds.length === 0) {
			alert('Por favor, selecciona al menos una imagen para eliminar.');
			return;
		}

		if (!confirm('¿Estás seguro de que deseas eliminar permanentemente las ' + selectedIds.length + ' imágenes seleccionadas de tu servidor y base de datos? Esta acción es irreversible.')) {
			return;
		}

		var $btn = $(this);
		$btn.prop('disabled', true).text('Eliminando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_delete_unused_images',
				ids: selectedIds
			},
			success: function(response) {
				$btn.prop('disabled', false).text('Eliminar Seleccionadas');
				if (response.success) {
					showToast(response.data.deleted + ' imágenes eliminadas correctamente.', false);
					
					// Quitar de la lista local
					detectedOrphans = detectedOrphans.filter(function(img) {
						return !selectedIds.includes(img.id);
					});

					// Actualizar contadores
					orphansFoundCount = detectedOrphans.length;
					$('#wpat_orphans_stat_found').text(orphansFoundCount);
					
					// Re-renderizar tabla o cerrar si está vacía
					if (detectedOrphans.length > 0) {
						renderOrphansTable();
						$('#wpat_select_all_orphans').prop('checked', false);
					} else {
						$('#wpat_orphans_results_wrapper').slideUp(200);
						$btn.hide();
					}
				} else {
					alert('Error al eliminar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Eliminar Seleccionadas');
				alert('Fallo de conexión al eliminar las imágenes.');
			}
		});
	});


	// 7. Ocultar/Mostrar opciones selectivas de comentarios según deshabilitación global
	$('#wpat_disable_comments_global').on('change', function() {
		var $options = $(this).closest('.wpat-module-body').find('.wpat-comments-options');
		if ($(this).is(':checked')) {
			$options.slideUp(200);
		} else {
			$options.slideDown(200);
		}
	});

	// 8. Ocultar/Mostrar opciones de Modo Catálogo según "Desactivar añadir al carrito"
	$('input[name="wpat_settings[woo_catalog_hide_cart]"]').on('change', function() {
		if ($(this).is(':checked')) {
			$('.wpat-catalog-actions-container').slideDown(250);
		} else {
			$('.wpat-catalog-actions-container').slideUp(250);
		}
	});

	$('#wpat_woo_catalog_wa_enable').on('change', function() {
		if ($(this).is(':checked')) {
			$('.wpat-catalog-wa-subfields').slideDown(250);
		} else {
			$('.wpat-catalog-wa-subfields').slideUp(250);
		}
	});

	$('#wpat_woo_catalog_form_enable').on('change', function() {
		if ($(this).is(':checked')) {
			$('.wpat-catalog-form-subfields').slideDown(250);
		} else {
			$('.wpat-catalog-form-subfields').slideUp(250);
		}
	});


	// --- GESTOR DE SNIPPETS (AJAX) ---

	// Importación rápida de fragmentos de código (.json)
	$('#wpat_import_snippets_only_btn').on('click', function(e) {
		e.preventDefault();
		$('#wpat_import_snippets_only_file').trigger('click');
	});

	$('#wpat_import_snippets_only_file').on('change', function() {
		if ($(this).val()) {
			$('#wpat_execute_import_snippets_only_submit').trigger('click');
		}
	});

	// 1. Mostrar formulario de Añadir Nuevo Snippet
	$('#wpat_add_new_snippet_btn').on('click', function(e) {
		e.preventDefault();
		
		// Limpiar campos del editor
		$('#wpat_editor_id').val('');
		$('#wpat_editor_name').val('');
		$('#wpat_editor_type').val('php');
		$('#wpat_editor_code').val('');
		$('#wpat_editor_active').prop('checked', true);
		
		$('.wpat-editor-title').text('Añadir Nuevo Fragmento');
		
		// Cambiar vistas con animación suave
		$('.wpat-snippets-list').hide();
		$('.wpat-snippet-editor').fadeIn(200);
	});

	// 2. Cancelar edición/creación
	$('#wpat_cancel_snippet_btn').on('click', function(e) {
		e.preventDefault();
		$('.wpat-snippet-editor').hide();
		$('.wpat-snippets-list').fadeIn(200);
	});

	// 3. Cargar para editar
	$(document).on('click', '.wpat-snippet-edit-btn, .wpat-snippet-edit-link', function(e) {
		e.preventDefault();
		var $row = $(this).closest('tr');
		
		var id = $row.data('id');
		var name = $row.data('name');
		var type = $row.data('type');
		var active = $row.data('active');
		var code = $row.find('.wpat-snippet-raw-code').text(); // Obtener el código crudo

		// Llenar campos
		$('#wpat_editor_id').val(id);
		$('#wpat_editor_name').val(name);
		$('#wpat_editor_type').val(type);
		$('#wpat_editor_code').val(code);
		$('#wpat_editor_active').prop('checked', active === 1 || active === '1');
		
		$('.wpat-editor-title').text('Editar Fragmento: ' + name);

		// Cambiar vistas
		$('.wpat-snippets-list').hide();
		$('.wpat-snippet-editor').fadeIn(200);
	});

	// 4. Guardar fragmento vía AJAX
	$('#wpat_save_snippet_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		
		var id = $('#wpat_editor_id').val();
		var name = $('#wpat_editor_name').val().trim();
		var type = $('#wpat_editor_type').val();
		var code = $('#wpat_editor_code').val();
		var active = $('#wpat_editor_active').is(':checked') ? '1' : '0';
		var nonce = $('#wpat_snippet_ajax_nonce').val();

		if (name === '') {
			alert('Por favor, introduce el nombre del fragmento.');
			return;
		}

		$btn.prop('disabled', true).text('Guardando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_save_snippet',
				security: nonce,
				snippet_id: id,
				snippet_name: name,
				snippet_type: type,
				snippet_code: code,
				snippet_active: active
			},
			success: function(response) {
				$btn.prop('disabled', false).text('Guardar Fragmento');
				if (response.success) {
					// Actualizar tabla
					$('#wpat_snippets_table_body').html(response.data.html);
					// Volver al listado
					$('.wpat-snippet-editor').hide();
					$('.wpat-snippets-list').fadeIn(200);
				} else {
					alert('Error al guardar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Guardar Fragmento');
				alert('Fallo de conexión al guardar el fragmento.');
			}
		});
	});

	// 5. Alternar estado ON/OFF (badge) vía AJAX
	$(document).on('click', '.wpat-snippet-toggle-badge', function(e) {
		e.preventDefault();
		var $badge = $(this);
		var $row = $badge.closest('tr');
		var id = $row.data('id');
		var nonce = $('#wpat_snippet_ajax_nonce').val();

		$badge.text('Cargando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_toggle_snippet',
				security: nonce,
				snippet_id: id
			},
			success: function(response) {
				if (response.success) {
					$('#wpat_snippets_table_body').html(response.data.html);
				} else {
					$badge.text($row.data('active') === '1' ? 'Activo' : 'Inactivo');
					alert('Error al alternar estado: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$badge.text($row.data('active') === '1' ? 'Activo' : 'Inactivo');
				alert('Fallo de conexión al cambiar el estado del fragmento.');
			}
		});
	});

	// 6. Clonar fragmento vía AJAX
	$(document).on('click', '.wpat-snippet-clone-btn', function(e) {
		e.preventDefault();
		var $row = $(this).closest('tr');
		var id = $row.data('id');
		var nonce = $('#wpat_snippet_ajax_nonce').val();

		if (!confirm('¿Deseas duplicar este fragmento de código?')) {
			return;
		}

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_clone_snippet',
				security: nonce,
				snippet_id: id
			},
			success: function(response) {
				if (response.success) {
					$('#wpat_snippets_table_body').html(response.data.html);
				} else {
					alert('Error al clonar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				alert('Fallo de conexión al clonar el fragmento.');
			}
		});
	});

	// 7. Eliminar fragmento vía AJAX
	$(document).on('click', '.wpat-snippet-delete-btn', function(e) {
		e.preventDefault();
		var $row = $(this).closest('tr');
		var id = $row.data('id');
		var nonce = $('#wpat_snippet_ajax_nonce').val();

		if (!confirm('¿Estás seguro de que deseas eliminar este fragmento de código?')) {
			return;
		}

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_delete_snippet',
				security: nonce,
				snippet_id: id
			},
			success: function(response) {
				if (response.success) {
					$('#wpat_snippets_table_body').html(response.data.html);
				} else {
					alert('Error al eliminar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				alert('Fallo de conexión al eliminar el fragmento.');
			}
		});
	});

	// --- OPTIMIZACIÓN Y LIMPIEZA DE BASE DE DATOS ---

	function syncDbCounters(stats, db_sizes) {
		if (!stats) return;
		$.each(stats, function(key, val) {
			var $counter = $('.wpat-db-counter[data-type="' + key + '"]');
			var $btn     = $('.wpat-db-clean-btn[data-type="' + key + '"]');
			if ($counter.length) {
				$counter.text(val);
				if (parseInt(val, 10) === 0) {
					$counter.css('color', '#94a3b8');
					$btn.prop('disabled', true).text('Limpio');
				} else {
					$counter.css('color', '#0f172a');
					$btn.prop('disabled', false).text('Limpiar');
				}
			}
		});

		// Actualizar contador de optimización de tablas
		if (db_sizes && db_sizes.overhead_size) {
			var $optCounter = $('.wpat-db-counter[data-type="optimize_tables"]');
			var $optBtn     = $('.wpat-db-clean-btn[data-type="optimize_tables"]');
			$optCounter.text(db_sizes.overhead_size);
			if (db_sizes.overhead_raw > 0) {
				$optCounter.css('color', '#ea580c');
				$optBtn.prop('disabled', false).text('Optimizar');
			} else {
				$optCounter.css('color', '#16a34a').text('0 B (Optimizado)');
				$optBtn.prop('disabled', true).text('Optimizado');
			}
		}
	}

	// Limpiador individual
	$(document).on('click', '.wpat-db-clean-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var type = $btn.data('type');
		var nonce = $('#wpat_cleanup_ajax_nonce').val() || (typeof wpat_object !== 'undefined' ? wpat_object.cleanup_nonce : '');
		var origText = $btn.text();

		$btn.prop('disabled', true).text(type === 'optimize_tables' ? 'Optimizando...' : 'Limpiando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_cleanup_database',
				security: nonce,
				cleanup_type: type
			},
			success: function(response) {
				if (response.success) {
					if (response.data && response.data.stats) {
						syncDbCounters(response.data.stats, response.data.db_sizes);
					} else {
						var $counter = $('.wpat-db-counter[data-type="' + type + '"]');
						$counter.text('0').css('color', '#94a3b8');
						$btn.prop('disabled', true).text('Limpio');
					}
					if (type === 'optimize_tables') {
						$btn.prop('disabled', true).text('Optimizado');
					}
					showToast(response.data && response.data.message ? response.data.message : 'Limpieza completada con éxito.', false);
				} else {
					$btn.prop('disabled', false).text(origText);
					alert('Error al limpiar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function(xhr, status, error) {
				$btn.prop('disabled', false).text(origText);
				alert('Fallo de conexión al realizar el mantenimiento: ' + (xhr && xhr.responseText ? xhr.responseText.substring(0, 100) : (error || 'Error de red')));
			}
		});
	});

	// Limpiar todo (Optimizar todo)
	$('#wpat_db_clean_all_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var nonce = $('#wpat_cleanup_ajax_nonce').val() || (typeof wpat_object !== 'undefined' ? wpat_object.cleanup_nonce : '');

		if (!confirm('¿Estás seguro de que deseas limpiar y optimizar la base de datos por completo? Se vaciarán revisiones, borradores automáticos, papelera, spam, transitorios expirados, metadatos huérfanos y se optimizarán todas las tablas.')) {
			return;
		}

		$btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpat-spin" style="vertical-align: middle; font-size:16px; width:16px; height:16px; margin-right:5px;"></span> Optimizando Todo...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_cleanup_database',
				security: nonce,
				cleanup_type: 'all'
			},
			success: function(response) {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools" style="vertical-align: middle; font-size:16px; width:16px; height:16px; margin-right:5px;"></span> Limpiar y Optimizar Todo');
				if (response.success) {
					if (response.data && response.data.stats) {
						syncDbCounters(response.data.stats, response.data.db_sizes);
					} else {
						$('.wpat-db-counter').text('0').css('color', '#94a3b8');
						$('.wpat-db-clean-btn').prop('disabled', true).text('Limpio');
					}
					$('.wpat-db-counter[data-type="optimize_tables"]').css('color', '#16a34a').text('0 B (Optimizado)');
					$('.wpat-db-clean-btn[data-type="optimize_tables"]').prop('disabled', true).text('Optimizado');
					showToast(response.data && response.data.message ? response.data.message : 'Base de datos optimizada y limpia al completo.', false);
				} else {
					alert('Error al optimizar: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function(xhr, status, error) {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools" style="vertical-align: middle; font-size:16px; width:16px; height:16px; margin-right:5px;"></span> Limpiar y Optimizar Todo');
				alert('Fallo de conexión al optimizar la base de datos: ' + (xhr && xhr.responseText ? xhr.responseText.substring(0, 100) : (error || 'Error de red')));
			}
		});
	});

	// Actualizar datos de Salud y Base de Datos vía AJAX
	$(document).on('click', '#wpat_refresh_health_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var nonce = $('#wpat_cleanup_ajax_nonce').val() || (typeof wpat_object !== 'undefined' ? wpat_object.cleanup_nonce : '');
		var originalHtml = $btn.html();

		// Deshabilitar y mostrar loader con animación de giro wpat-spin
		$btn.prop('disabled', true).html('<span class="dashicons dashicons-update wpat-spin" style="vertical-align: middle; font-size:16px; width:16px; height:16px; margin-right:5px;"></span> Cargando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_get_health_status',
				security: nonce
			},
			success: function(response) {
				$btn.prop('disabled', false).html(originalHtml);
				if (response.success) {
					$('#wpat_health_content_wrapper').html(response.data.html);
					showToast('Datos de salud actualizados.', false);
				} else {
					alert('Error al actualizar datos: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).html(originalHtml);
				alert('Fallo de conexión al actualizar datos.');
			}
		});
	});

	// --- IMPORTADOR DE KITS DE PLANTILLAS (ENVATO) ---
	var $dragDropZone = $('#wpat_kit_dragdrop_zone');
	var $fileInput    = $('#wpat_kit_file_input');
	var $selectBtn    = $('#wpat_select_kit_zip_btn');

	if ($dragDropZone.length) {
		// Abrir explorador de archivos al pulsar el botón
		$selectBtn.on('click', function(e) {
			e.preventDefault();
			$fileInput.click();
		});

		// Manejar cambio en el input file
		$fileInput.on('change', function() {
			var files = this.files;
			if (files.length > 0) {
				handleKitZipUpload(files[0]);
			}
		});

		// Eventos Drag & Drop
		$dragDropZone.on('dragover', function(e) {
			e.preventDefault();
			$(this).css('background-color', '#f1f5f9').css('border-color', '#9333ea');
		});

		$dragDropZone.on('dragleave', function(e) {
			e.preventDefault();
			$(this).css('background-color', '#f8fafc').css('border-color', 'var(--wpat-border)');
		});

		$dragDropZone.on('drop', function(e) {
			e.preventDefault();
			$(this).css('background-color', '#f8fafc').css('border-color', 'var(--wpat-border)');
			
			var files = e.originalEvent.dataTransfer.files;
			if (files.length > 0) {
				handleKitZipUpload(files[0]);
			}
		});
	}

	function handleKitZipUpload(file) {
		if (file.type !== 'application/zip' && !file.name.endsWith('.zip')) {
			alert('Por favor, selecciona un archivo comprimido .zip.');
			return;
		}

		var nonce = $('#wpat_envato_importer_nonce').val();
		var formData = new FormData();
		formData.append('action', 'wpat_upload_envato_kit');
		formData.append('security', nonce);
		formData.append('kit_zip', file);

		$('#wpat_kit_upload_progress').show();
		$('#wpat_kit_upload_bar').css('width', '0%');
		$('#wpat_kit_upload_status').text('Subiendo kit: ' + file.name + ' (0%)');
		$selectBtn.prop('disabled', true);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: formData,
			contentType: false,
			processData: false,
			xhr: function() {
				var myXhr = $.ajaxSettings.xhr();
				if (myXhr.upload) {
					myXhr.upload.addEventListener('progress', function(e) {
						if (e.lengthComputable) {
							var percent = Math.round((e.loaded / e.total) * 100);
							$('#wpat_kit_upload_bar').css('width', percent + '%');
							$('#wpat_kit_upload_status').text('Subiendo kit: ' + file.name + ' (' + percent + '%)');
						}
					}, false);
				}
				return myXhr;
			},
			success: function(response) {
				$selectBtn.prop('disabled', false);
				if (response.success) {
					var newKit = response.data.kit;
					
					// Asegurar la variable de datos global
					if (typeof wpatEnvatoEditor === 'undefined') {
						wpatEnvatoEditor = { kits: {} };
					}
					if (!wpatEnvatoEditor.kits) {
						wpatEnvatoEditor.kits = {};
					}
					wpatEnvatoEditor.kits[newKit.slug] = newKit;
					
					// Limpiar progreso e input
					$('#wpat_kit_upload_progress').hide();
					$('#wpat_kit_file_input').val('');
					
					// Función auxiliar para renderizar el HTML del card
					function renderKitCardHtml(slug, kit) {
						var thumbHtml = '';
						if (kit.thumbnail) {
							thumbHtml = '<div class="wpat-kit-cover" style="height: 140px; background-image: url(\'' + kit.thumbnail + '\'); background-size: cover; background-position: center; border-bottom: 1px solid var(--wpat-border);"></div>';
						} else {
							thumbHtml = '<div class="wpat-kit-cover" style="height: 140px; background: linear-gradient(135deg, #f1f5f9 0%, #cbd5e1 100%); display: flex; align-items: center; justify-content: center; border-bottom: 1px solid var(--wpat-border);">' +
										'  <span class="dashicons dashicons-download" style="font-size: 48px; width:48px; height:48px; color: #94a3b8;"></span>' +
										'</div>';
						}
						
						var templatesCount = kit.templates ? kit.templates.length : 0;
						var pluginsCount = kit.required_plugins ? kit.required_plugins.length : 0;
						var pluginsBadge = '';
						if (pluginsCount > 0) {
							pluginsBadge = '<span class="wpat-badge" style="background: #fee2e2; color: #991b1b; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">' + pluginsCount + ' plugins necesarios</span>';
						} else {
							pluginsBadge = '<span class="wpat-badge" style="background: #d1fae5; color: #065f46; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">0 plugins necesarios</span>';
						}

						var html = '<div class="wpat-module-card wpat-kit-card" style="margin: 0; padding: 0; overflow:hidden; display: flex; flex-direction: column; border: 1px solid var(--wpat-border);" data-slug="' + slug + '">' +
								   thumbHtml +
								   '  <div style="padding: 20px; display: flex; flex-direction: column; flex-grow: 1;">' +
								   '    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 12px;">' +
								   '      <h4 style="margin: 0; font-size: 15px; font-weight: 600; color: var(--wpat-text);">' + kit.title + '</h4>' +
								   '      <button type="button" class="wpat-delete-kit-btn button-link-delete" data-slug="' + slug + '" title="Eliminar Kit Completo" style="border:none; background:none; cursor:pointer; padding:0; color:#ea580c;"><span class="dashicons dashicons-trash" style="font-size:18px;"></span></button>' +
								   '    </div>' +
								   '    <div style="display: flex; gap: 5px; margin-bottom: 15px; flex-wrap: wrap;">' +
								   '      <span class="wpat-badge" style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;">' + templatesCount + ' plantillas</span>' +
								   pluginsBadge +
								   '    </div>' +
								   '    <button type="button" class="button wpat-view-kit-templates-btn" data-slug="' + slug + '" style="width: 100%; margin-top: auto;">Ver Plantillas</button>' +
								   '  </div>' +
								   '</div>';
						return html;
					}

					var cardHtml = renderKitCardHtml(newKit.slug, newKit);
					var $container = $('#wpat_installed_kits_container');
					var $emptyState = $container.find('.wpat-empty-kits');
					
					if ($emptyState.length > 0) {
						$emptyState.remove();
						$container.html('<div class="wpat-kits-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;"></div>');
					}
					
					var $grid = $container.find('.wpat-kits-grid');
					if ($grid.length > 0) {
						var $newCard = $(cardHtml).hide();
						$grid.append($newCard);
						$newCard.fadeIn(300);
					}
					
					showToast('Kit subido y descomprimido correctamente.', false);
				} else {
					$('#wpat_kit_upload_progress').hide();
					alert('Error al subir el kit: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function(xhr, status, errorThrown) {
				$selectBtn.prop('disabled', false);
				$('#wpat_kit_upload_progress').hide();
				
				var errorMsg = 'Fallo al subir el kit de plantilla.\n\n';
				
				if (xhr.status === 413) {
					errorMsg += 'El servidor rechazó el archivo porque es demasiado grande (Error 413: Payload Too Large).\n\nSolución: Solicita a tu hosting aumentar los límites "upload_max_filesize" y "post_max_size" en el archivo php.ini de tu servidor.';
				} else if (xhr.status === 504 || status === 'timeout') {
					errorMsg += 'Se agotó el tiempo de espera del servidor (Error 504 / Timeout).\n\nSolución: El servidor tardó demasiado en cargar o descomprimir el kit. Incrementa "max_execution_time" en tu configuración de PHP.';
				} else if (xhr.status === 500) {
					errorMsg += 'Error interno del servidor (Error 500).\n\nSolución: Esto suele deberse a un límite de memoria PHP excedido (Memory Limit) o un error de código crítico al descomprimir. Revisa el registro de errores de PHP (error_log) en tu hosting.';
				} else if (status === 'parsererror') {
					errorMsg += 'Respuesta del servidor corrupta (Error de análisis JSON).\n\nSolución: Esto ocurre si WordPress tiene activada la visualización de avisos o advertencias de PHP (PHP Notices/Warnings) en pantalla. Puedes ver la respuesta cruda en la consola del navegador (F12).';
				} else if (xhr.status === 0) {
					errorMsg += 'No se pudo conectar con el servidor. Revisa tu conexión a Internet o comprueba si la subida fue bloqueada por un plugin de seguridad o cortafuegos.';
				} else {
					errorMsg += 'Detalle del error: HTTP ' + xhr.status + ' (' + (errorThrown || 'Error de Red') + ').';
				}
				
				alert(errorMsg);
			}
		});
	}

	// Acción: Ver las plantillas de un kit
	$(document).on('click', '.wpat-view-kit-templates-btn', function(e) {
		e.preventDefault();
		var slug = $(this).data('slug');
		
		// Guardar en sessionStorage para restaurar después de recargar
		sessionStorage.setItem('wpat_active_kit_slug', slug);
		
		// Ocultar cuadrícula de kits
		$('#wpat_installed_kits_container').hide();
		
		// Obtener datos del kit desde los datos encolados en PHP
		var kits = wpatEnvatoEditor.kits || {};
		var kit = kits[slug];

		if (kit) {
			console.log("WPAT Debug: Kit loaded info:", kit);
			$('#wpat_active_kit_title').text('Plantillas del Kit: ' + kit.title);
			
			// Renderizar plugins requeridos si los hay
			var pluginsHtml = '';
			if (kit.required_plugins && kit.required_plugins.length > 0) {
				pluginsHtml += '<div class="wpat-module-card" style="margin: 0 0 25px 0; padding: 20px; background: #fafafa; border: 1px dashed var(--wpat-border);">';
				pluginsHtml += '  <h4 style="margin: 0 0 10px 0; font-size:14px; font-weight:600;"><span class="dashicons dashicons-admin-plugins" style="vertical-align: middle; margin-right:5px; font-size:18px; width:18px; height:18px;"></span> Plugins Requeridos por el Kit</h4>';
				pluginsHtml += '  <p style="margin:0 0 15px 0; font-size:12px; color:#64748b;">Para garantizar que las plantillas de este kit funcionen y se vean correctamente, es necesario tener instalados y activos los siguientes plugins:</p>';
				pluginsHtml += '  <ul style="margin:0; padding:0; list-style:none;">';
				
				kit.required_plugins.forEach(function(p) {
					var badge = '';
					var button = '';
					
					if (p.is_plugin === false) {
						// Es un ajuste de configuración de Elementor
						if (p.active) {
							badge = '<span style="background:#d1fae5; color:#065f46; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Aplicado</span>';
						} else {
							badge = '<span style="background:#fee2e2; color:#991b1b; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">No configurado</span>';
							button = '<button type="button" class="button button-small button-primary wpat-configure-setting-btn" data-slug="' + p.slug + '" style="margin-left:auto;">Configurar</button>';
						}
					} else {
						// Es un plugin
						if (p.active) {
							badge = '<span style="background:#d1fae5; color:#065f46; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Activo</span>';
						} else if (p.installed) {
							badge = '<span style="background:#fef3c7; color:#92400e; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Desactivado</span>';
							button = '<button type="button" class="button button-small wpat-activate-plugin-btn" data-slug="' + p.slug + '" style="margin-left:auto;">Activar</button>';
						} else {
							badge = '<span style="background:#fee2e2; color:#991b1b; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">No instalado</span>';
							button = '<button type="button" class="button button-small button-primary wpat-install-plugin-btn" data-slug="' + p.slug + '" style="margin-left:auto;">Instalar y Activar</button>';
						}
					}
					
					pluginsHtml += '    <li style="display:flex; align-items:center; padding:8px 0; border-bottom:1px solid #f1f5f9; font-size:13px; margin:0;">';
					pluginsHtml += '      <strong>' + p.name + '</strong>' + badge;
					pluginsHtml += button;
					pluginsHtml += '    </li>';
				});
				
				pluginsHtml += '  </ul>';
				pluginsHtml += '</div>';
				
				$('#wpat_kit_plugins_container').html(pluginsHtml).show();
			} else {
				$('#wpat_kit_plugins_container').hide();
			}

			var gridHtml = '';
			kit.templates.forEach(function(tpl) {
				var thumb = tpl.thumbnail ? tpl.thumbnail : 'https://placehold.co/400x300/f1f5f9/94a3b8?text=Plantilla';
				var previewUrl = tpl.preview_url ? tpl.preview_url : thumb;
				var isGlobal = tpl.title.toLowerCase().indexOf('global') !== -1;
				
				gridHtml += '<div class="wpat-module-card wpat-tpl-card-admin" style="margin:0; padding:15px; display:flex; flex-direction:column; border: 1px solid var(--wpat-border);">';
				gridHtml += '  <div class="wpat-tpl-thumb" style="height:140px; background-size:cover; background-position:center; background-image:url(\'' + thumb + '\'); border-radius:6px; border:1px solid #e2e8f0; margin-bottom:12px; background-color:#f8fafc; background-repeat:no-repeat;"></div>';
				gridHtml += '  <h4 style="margin:0 0 4px 0; font-size:14px; font-weight:600;">' + tpl.title + '</h4>';
				gridHtml += '  <span style="font-size:10px; font-weight:700; color:#64748b; background:#f1f5f9; padding:2px 6px; border-radius:4px; align-self:flex-start; margin-bottom:12px;">' + tpl.type.toUpperCase() + '</span>';
				gridHtml += '  <div style="display:flex; gap:8px; margin-top:auto; width:100%;">';
				if (!isGlobal) {
					gridHtml += '    <a href="' + previewUrl + '" class="button wpat-preview-template-btn" data-kit="' + slug + '" data-id="' + tpl.id + '" data-title="' + tpl.title + '" data-thumb="' + thumb + '" style="flex:1; text-align:center; display:inline-flex; align-items:center; justify-content:center; gap:4px; font-size:12px; font-weight:500;"><span class="dashicons dashicons-visibility" style="font-size:15px; width:15px; height:15px; margin:0; line-height:1;"></span> Ver</a>';
				}
				gridHtml += '    <button type="button" class="button button-primary wpat-admin-import-template-btn" data-kit="' + slug + '" data-id="' + tpl.id + '" style="' + (isGlobal ? 'width:100%;' : 'flex:2;') + ' font-size:12px;">' + (isGlobal ? 'Aplicar Estilos Globales' : 'Importar a Elementor') + '</button>';
				gridHtml += '  </div>';
				gridHtml += '</div>';
			});

			$('#wpat_templates_grid_container').html(gridHtml);
			$('#wpat_kit_templates_detail_wrapper').fadeIn(200);
		}
	});

	// Cerrar detalle y volver al listado de kits
	$('#wpat_close_kit_detail_btn').on('click', function(e) {
		e.preventDefault();
		sessionStorage.removeItem('wpat_active_kit_slug');
		$('#wpat_kit_templates_detail_wrapper').hide();
		$('#wpat_installed_kits_container').fadeIn(200);
	});

	// Acción: Importar una plantilla a la biblioteca de Elementor desde el admin
	$(document).on('click', '.wpat-admin-import-template-btn', function(e) {
		e.preventDefault();
		
		// Cerrar el lightbox de vista previa si estuviera abierto
		$('.wpat-preview-lightbox-overlay').remove();
		
		var $btn = $(this);
		var kitSlug = $btn.data('kit');
		var tplId   = $btn.data('id');
		var nonce   = $('#wpat_envato_importer_nonce').val();

		$btn.prop('disabled', true).text('Importando...');

		var progress = 0;
		var progressHtml = 
			'<div class="wpat-editor-modal-loader-overlay" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.7); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; z-index:99999; font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;">' +
			'  <div class="wpat-editor-modal-loader-card" style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04); text-align:center; width:350px; border: 1px solid #e2e8f0;">' +
			'    <h4 style="margin:0 0 15px 0; font-size:16px; font-weight:600; color:#1e293b;">Importando plantilla a Elementor...</h4>' +
			'    <div class="wpat-import-progress-container" style="background:#f1f5f9; border-radius:9999px; height:8px; width:100%; overflow:hidden; margin-bottom:12px; border:1px solid #e2e8f0;">' +
			'      <div class="wpat-import-progress-bar" style="width: 0%; height:100%; background:linear-gradient(90deg, #6366f1 0%, #4f46e5 100%); transition: width 0.3s ease; border-radius:9999px;"></div>' +
			'    </div>' +
			'    <p class="wpat-import-progress-text" style="margin:0; font-size:12px; color:#64748b; font-weight:500;">0% completado (descargando imágenes...)</p>' +
			'  </div>' +
			'</div>';
		$('body').append(progressHtml);

		var progressInterval = setInterval(function() {
			if (progress < 90) {
				if (progress < 40) {
					progress += Math.floor(Math.random() * 8) + 3;
				} else if (progress < 70) {
					progress += Math.floor(Math.random() * 4) + 1;
				} else {
					progress += Math.floor(Math.random() * 2) + 0.5;
				}
				if (progress > 90) progress = 90;
				
				$('.wpat-import-progress-bar').css('width', progress + '%');
				$('.wpat-import-progress-text').text(Math.round(progress) + '% completado (descargando imágenes...)');
			}
		}, 300);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_import_envato_template',
				security: nonce,
				kit_slug: kitSlug,
				template_id: tplId
			},
			success: function(response) {
				clearInterval(progressInterval);
				$('.wpat-import-progress-bar').css('width', '100%');
				$('.wpat-import-progress-text').text('100% completado');
				
				setTimeout(function() {
					$('.wpat-editor-modal-loader-overlay').remove();
					$btn.prop('disabled', false).text('Importar a Elementor');
					if (response.success) {
						showToast('Plantilla registrada en Elementor.', false);
						$btn.removeClass('button-primary').addClass('button-secondary').text('¡Importada!');
					} else {
						alert('Error al importar: ' + (response.data ? response.data.message : 'Error desconocido.'));
					}
				}, 600);
			},
			error: function() {
				clearInterval(progressInterval);
				$('.wpat-editor-modal-loader-overlay').remove();
				$btn.prop('disabled', false).text('Importar a Elementor');
			}
		});
	});

	// Acción: Crear una página directa a partir de una plantilla del kit
	$(document).on('click', '.wpat-admin-create-page-btn', function(e) {
		e.preventDefault();
		$('.wpat-preview-lightbox-overlay').remove();
		
		var $btn = $(this);
		var kitSlug = $btn.data('kit');
		var tplId   = $btn.data('id');
		var defaultTitle = $btn.data('title') || 'Nueva Página';
		var nonce   = $('#wpat_envato_importer_nonce').val();

		var pageTitle = prompt('Introduce el título para la nueva página:', defaultTitle);
		if (pageTitle === null || pageTitle.trim() === '') {
			return;
		}

		$btn.prop('disabled', true).text('Creando...');

		var progress = 0;
		var progressHtml = 
			'<div class="wpat-editor-modal-loader-overlay" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.7); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; z-index:99999; font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">' +
			'  <div class="wpat-editor-modal-loader-card" style="background:#fff; padding:30px; border-radius:12px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1); text-align:center; width:360px; border: 1px solid #e2e8f0;">' +
			'    <h4 style="margin:0 0 15px 0; font-size:16px; font-weight:600; color:#1e293b;">Creando página y procesando imágenes...</h4>' +
			'    <div class="wpat-import-progress-container" style="background:#f1f5f9; border-radius:9999px; height:8px; width:100%; overflow:hidden; margin-bottom:12px; border:1px solid #e2e8f0;">' +
			'      <div class="wpat-import-progress-bar" style="width: 0%; height:100%; background:linear-gradient(90deg, #10b981 0%, #059669 100%); transition: width 0.3s ease; border-radius:9999px;"></div>' +
			'    </div>' +
			'    <p class="wpat-import-progress-text" style="margin:0; font-size:12px; color:#64748b; font-weight:500;">Descargando assets y configurando Elementor...</p>' +
			'  </div>' +
			'</div>';
		$('body').append(progressHtml);

		var progressInterval = setInterval(function() {
			if (progress < 90) {
				progress += Math.floor(Math.random() * 8) + 3;
				if (progress > 90) progress = 90;
				$('.wpat-import-progress-bar').css('width', progress + '%');
			}
		}, 300);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_create_page_from_template',
				security: nonce,
				kit_slug: kitSlug,
				template_id: tplId,
				page_title: pageTitle
			},
			success: function(response) {
				clearInterval(progressInterval);
				$('.wpat-import-progress-bar').css('width', '100%');
				
				setTimeout(function() {
					$('.wpat-editor-modal-loader-overlay').remove();
					$btn.prop('disabled', false).text('⚡ Crear Página');
					if (response.success) {
						showToast('¡Página creada correctamente!', false);
						$btn.parent().html(
							'<a href="' + response.data.edit_url + '" class="button button-primary" style="flex:1; text-align:center; font-size:11px; padding:0 6px;">✏️ Editar Elementor</a>' +
							'<a href="' + response.data.view_url + '" target="_blank" class="button button-secondary" style="font-size:11px; padding:0 8px;">Ver Página</a>'
						);
					} else {
						alert('Error al crear la página: ' + (response.data ? response.data.message : 'Error desconocido.'));
					}
				}, 500);
			},
			error: function() {
				clearInterval(progressInterval);
				$('.wpat-editor-modal-loader-overlay').remove();
				$btn.prop('disabled', false).text('⚡ Crear Página');
				alert('Fallo de conexión al crear la página.');
			}
		});
	});

	// Acción: Eliminar un kit completo
	$(document).on('click', '.wpat-delete-kit-btn', function(e) {
		e.preventDefault();
		e.stopPropagation();
		var $btn = $(this);
		var slug = $btn.data('slug');
		var nonce = $('#wpat_envato_importer_nonce').val();

		if (!confirm('¿Estás seguro de que deseas eliminar este kit de plantillas del servidor? Esta acción eliminará permanentemente la carpeta de archivos.')) {
			return;
		}

		$btn.prop('disabled', true);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_delete_envato_kit',
				security: nonce,
				kit_slug: slug
			},
			success: function(response) {
				if (response.success) {
					showToast('Kit eliminado correctamente.', false);
					
					// Eliminar de los datos en memoria
					if (typeof wpatEnvatoEditor !== 'undefined' && wpatEnvatoEditor.kits) {
						delete wpatEnvatoEditor.kits[slug];
					}
					
					$btn.closest('.wpat-kit-card').fadeOut(200, function() {
						$(this).remove();
						if ($('.wpat-kit-card').length === 0) {
							var $container = $('#wpat_installed_kits_container');
							$container.html(
								'<div class="wpat-empty-kits" style="background:#ffffff; border: 1px solid var(--wpat-border); padding: 40px; border-radius: 8px; text-align: center; color: #64748b;">' +
								'  <p style="margin: 0; font-size:14px;">No hay ningún kit de plantilla instalado.</p>' +
								'  <p style="margin: 5px 0 0 0; font-size:12px; color: #94a3b8;">Usa el cargador de arriba para subir tu primer kit comprimido en ZIP.</p>' +
								'</div>'
							);
						}
					});
				} else {
					$btn.prop('disabled', false);
					alert('Error al eliminar kit: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false);
				alert('Fallo de conexión al eliminar el kit.');
			}
		});
	});

	// 9. Colapsar/Desplegar cuerpo del módulo de forma independiente
	$(document).on('click', '.wpat-collapse-btn', function(e) {
		e.preventDefault();
		e.stopPropagation();
		var $btn = $(this);
		var $card = $btn.closest('.wpat-module-card');
		var $body = $card.find('.wpat-module-body');
		
		if ($body.length) {
			$body.slideToggle(200);
			$btn.toggleClass('collapsed');
		}
	});

	$(document).on('click', '.wpat-module-header', function(e) {
		if ($(e.target).closest('.wpat-switch, a, button, input, textarea, select').length) return;
		var $card = $(this).closest('.wpat-module-card');
		var $btn = $card.find('.wpat-collapse-btn');
		if ($btn.length && $btn.is(':visible')) {
			$btn.trigger('click');
		}
	});

	// 10. Mostrar/Ocultar campos de autenticación SMTP
	// 10. Mostrar/Ocultar campos de autenticación SMTP
	$(document).on('change', '#wpat_smtp_auth', function() {
		var $fields = $('.wpat-smtp-auth-fields');
		if ($(this).is(':checked')) {
			$fields.slideDown(250);
		} else {
			$fields.slideUp(250);
		}
	});

	// 10.1 Presets rápidos de proveedor SMTP
	$(document).on('click', '.wpat-smtp-preset-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var host = $btn.data('host') || '';
		var port = $btn.data('port') || '587';
		var secure = $btn.data('secure') || 'tls';
		var auth = $btn.data('auth') || '1';
		var user = $btn.data('user') || '';
		var provider = $btn.data('provider') || 'Proveedor';

		$('#wpat_smtp_host').val(host);
		$('#wpat_smtp_port').val(port);
		$('#wpat_smtp_secure').val(secure);
		
		if (auth === '1' || auth === 1) {
			$('#wpat_smtp_auth').prop('checked', true).trigger('change');
		}

		if (user) {
			$('#wpat_smtp_username').val(user);
		}

		var $notice = $('#wpat_smtp_preset_notice');
		$notice.html('✔ Plantilla de <strong>' + provider + '</strong> aplicada (Host: <code>' + host + '</code>, Puerto: <code>' + port + '</code>, Cifrado: <code>' + secure.toUpperCase() + '</code>). Introduce tu usuario y contraseña si es necesario.').fadeIn(200);
	});

	// 11. Acción: Enviar correo de prueba SMTP
	$(document).on('click', '#wpat_smtp_send_test_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $input = $('#wpat_smtp_test_email');
		var $result = $('#wpat_smtp_test_result');
		var email = $input.val();
		var nonce = $('#wpat_smtp_test_nonce').val();

		if (!email) {
			alert('Introduce un correo electrónico para realizar la prueba.');
			return;
		}

		$btn.prop('disabled', true).text('Enviando...');
		$result.hide().html('');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_smtp_send_test',
				security: nonce,
				test_email: email
			},
			success: function(response) {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-email-alt" style="margin-top: 2px;"></span> Enviar Prueba');
				$result.fadeIn(200);
				if (response.success) {
					$result.css({
						'background': '#e6f4ea',
						'color': '#137333',
						'border': '1px solid #c3e6cb'
					}).html('<strong>' + response.data.message + '</strong>');

					// Si la tabla de logs existe, añadir el nuevo registro arriba
					if ($('#wpat_smtp_log_tbody').length) {
						$('#wpat_smtp_no_logs_row').remove();
						var newRow = '<tr>' +
							'<td style="padding: 12px 16px;"><span style="display: inline-flex; align-items: center; gap: 4px; background: #dcfce7; color: #15803d; padding: 3px 8px; border-radius: 9999px; font-size: 11px; font-weight: 600;"><span class="dashicons dashicons-yes-alt" style="font-size: 14px; width: 14px; height: 14px;"></span> Enviado</span></td>' +
							'<td style="padding: 12px 16px; font-weight: 500; color: #1e293b;">' + $('<div>').text(email).html() + '</td>' +
							'<td style="padding: 12px 16px; color: #334155;"><strong>WP Agency Toolkit - Correo de prueba SMTP</strong></td>' +
							'<td style="padding: 12px 16px; color: #64748b; font-size: 12px;">' + (response.data.time || 'Ahora mismo') + '</td>' +
						'</tr>';
						$('#wpat_smtp_log_tbody').prepend(newRow);
					}
				} else {
					var html = '<strong>' + response.data.message + '</strong>';
					if (response.data.debug) {
						html += '<div style="margin-top: 10px; border-top: 1px solid #f5c6cb; padding-top: 10px; font-size: 11px; text-align: left; max-height: 200px; overflow-y: auto; white-space: pre-wrap; font-family: monospace; line-height: 1.4;">' + response.data.debug + '</div>';
					}
					$result.css({
						'background': '#fce8e6',
						'color': '#c5221f',
						'border': '1px solid #f5c6cb'
					}).html(html);
				}
			},
			error: function() {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-email-alt" style="margin-top: 2px;"></span> Enviar Prueba');
				$result.fadeIn(200).css({
					'background': '#fce8e6',
					'color': '#c5221f',
					'border': '1px solid #f5c6cb'
				}).html('Error de conexión o tiempo de espera agotado al conectar con el servidor.');
			}
		});
	});

	// 11.1 Vaciar historial de envíos SMTP
	$(document).on('click', '#wpat_smtp_clear_log_btn', function(e) {
		e.preventDefault();
		if (!confirm('¿Estás seguro de que deseas vaciar el historial de envíos de correo?')) {
			return;
		}
		var $btn = $(this);
		var nonce = $('#wpat_smtp_test_nonce').val();
		$btn.prop('disabled', true);

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_smtp_clear_log',
				security: nonce
			},
			success: function(response) {
				$btn.prop('disabled', false);
				if (response.success) {
					$('#wpat_smtp_log_tbody').html(
						'<tr id="wpat_smtp_no_logs_row">' +
							'<td colspan="4" style="text-align: center; padding: 30px; color: #64748b;">' +
								'<span class="dashicons dashicons-info" style="font-size: 28px; width: 28px; height: 28px; display: block; margin: 0 auto 8px; color: #94a3b8;"></span>' +
								'No hay envíos registrados todavía. Realiza un envío de prueba o espera a que tu sitio emita un correo.' +
							'</td>' +
						'</tr>'
					);
				} else {
					alert(response.data && response.data.message ? response.data.message : 'Error al vaciar el registro.');
				}
			},
			error: function() {
				$btn.prop('disabled', false);
				alert('Error de conexión al vaciar el historial.');
			}
		});
	});

	// 12. Auto-completar el puerto recomendable según el cifrado SMTP elegido
	$(document).on('change', '#wpat_smtp_secure', function() {
		var secureVal = $(this).val();
		var $portInput = $('#wpat_smtp_port');
		
		if (secureVal === 'ssl') {
			$portInput.val('465');
		} else if (secureVal === 'tls') {
			$portInput.val('587');
		} else if (secureVal === 'none') {
			$portInput.val('25');
		}
	});

	// 13. Acción: Activar un plugin requerido
	$(document).on('click', '.wpat-activate-plugin-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var slug = $btn.data('slug');
		var nonce = $('#wpat_envato_importer_nonce').val();
		
		$btn.prop('disabled', true).text('Activando...');
		
		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_activate_required_plugin',
				security: nonce,
				plugin_slug: slug
			},
			success: function(response) {
				if (response.success) {
					showToast('Plugin activado con éxito.', false);
					
					// Actualizar estado en memoria
					var activeKitSlug = sessionStorage.getItem('wpat_active_kit_slug');
					if (activeKitSlug && typeof wpatEnvatoEditor !== 'undefined' && wpatEnvatoEditor.kits && wpatEnvatoEditor.kits[activeKitSlug]) {
						var plugins = wpatEnvatoEditor.kits[activeKitSlug].required_plugins || [];
						plugins.forEach(function(p) {
							if (p.slug === slug) {
								p.active = true;
								p.installed = true;
							}
						});
					}
					
					// Actualizar la interfaz (DOM)
					var $li = $btn.closest('li');
					$li.find('span.wpat-badge, span[style*="background"]').replaceWith(
						'<span style="background:#d1fae5; color:#065f46; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Activo</span>'
					);
					$btn.fadeOut(200, function() { $(this).remove(); });
				} else {
					$btn.prop('disabled', false).text('Activar');
					alert('Error al activar plugin: ' + response.data.message);
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Activar');
				alert('Fallo de conexión al activar el plugin.');
			}
		});
	});
 
	// 14. Acción: Instalar y Activar un plugin requerido
	$(document).on('click', '.wpat-install-plugin-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var slug = $btn.data('slug');
		var nonce = $('#wpat_envato_importer_nonce').val();
		
		$btn.prop('disabled', true).text('Instalando...');
		
		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_install_required_plugin',
				security: nonce,
				plugin_slug: slug
			},
			success: function(response) {
				if (response.success) {
					showToast('Plugin instalado y activado con éxito.', false);
					
					// Actualizar estado en memoria
					var activeKitSlug = sessionStorage.getItem('wpat_active_kit_slug');
					if (activeKitSlug && typeof wpatEnvatoEditor !== 'undefined' && wpatEnvatoEditor.kits && wpatEnvatoEditor.kits[activeKitSlug]) {
						var plugins = wpatEnvatoEditor.kits[activeKitSlug].required_plugins || [];
						plugins.forEach(function(p) {
							if (p.slug === slug) {
								p.active = true;
								p.installed = true;
							}
						});
					}
					
					// Actualizar la interfaz (DOM)
					var $li = $btn.closest('li');
					$li.find('span.wpat-badge, span[style*="background"]').replaceWith(
						'<span style="background:#d1fae5; color:#065f46; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Activo</span>'
					);
					$btn.fadeOut(200, function() { $(this).remove(); });
				} else {
					$btn.prop('disabled', false).text('Instalar y Activar');
					alert('Error al instalar plugin: ' + response.data.message);
				}
			},
			error: function(xhr, status, error) {
				console.error("WPAT Plugin Install AJAX Error details:", status, error, xhr.responseText);
				$btn.prop('disabled', false).text('Instalar y Activar');
				alert('Fallo de conexión al instalar el plugin. Revisa la consola (F12) para más detalles.');
			}
		});
	});
 
	// 15. Acción: Configurar un ajuste de Elementor
	$(document).on('click', '.wpat-configure-setting-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var slug = $btn.data('slug');
		var nonce = $('#wpat_envato_importer_nonce').val();
		
		$btn.prop('disabled', true).text('Configurando...');
		
		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_enable_elementor_setting',
				security: nonce,
				setting_slug: slug
			},
			success: function(response) {
				if (response.success) {
					showToast('Ajuste aplicado con éxito.', false);
					
					// Actualizar estado en memoria
					var activeKitSlug = sessionStorage.getItem('wpat_active_kit_slug');
					if (activeKitSlug && typeof wpatEnvatoEditor !== 'undefined' && wpatEnvatoEditor.kits && wpatEnvatoEditor.kits[activeKitSlug]) {
						var plugins = wpatEnvatoEditor.kits[activeKitSlug].required_plugins || [];
						plugins.forEach(function(p) {
							if (p.slug === slug) {
								p.active = true;
							}
						});
					}
					
					// Actualizar la interfaz (DOM)
					var $li = $btn.closest('li');
					$li.find('span.wpat-badge, span[style*="background"]').replaceWith(
						'<span style="background:#d1fae5; color:#065f46; font-size:11px; font-weight:700; padding:2px 8px; border-radius:4px; margin-left:10px;">Aplicado</span>'
					);
					$btn.fadeOut(200, function() { $(this).remove(); });
				} else {
					$btn.prop('disabled', false).text('Configurar');
					alert('Error al aplicar ajuste: ' + response.data.message);
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Configurar');
				alert('Fallo de conexión al aplicar el ajuste.');
			}
		});
	});

	// Evento: Abrir vista previa en lightbox (modal de imagen vertical scrollable de 700px)
	$(document).on('click', '.wpat-preview-template-btn', function(e) {
		e.preventDefault();
		var $previewBtn = $(this);
		var previewUrl = $previewBtn.attr('href');
		var thumbUrl = $previewBtn.data('thumb') || '';
		var kitSlug = $previewBtn.data('kit') || '';
		var tplId = $previewBtn.data('id') || '';
		var tplTitle = $previewBtn.data('title') || 'Plantilla';
		
		if (!previewUrl || previewUrl.indexOf('placehold.co') !== -1) {
			alert('No hay una vista previa disponible para esta plantilla.');
			return;
		}
		
		// Botón de acción: Importar plantilla
		var actionButtonHtml = 
			'<button type="button" class="wpat-admin-import-template-btn" data-kit="' + kitSlug + '" data-id="' + tplId + '" style="background:#5cb85c; border:none; color:#fff; font-size:12px; font-weight:700; cursor:pointer; padding:6px 16px; border-radius:4px; outline:none; display:inline-flex; align-items:center; gap:6px; transition:background 0.2s; height:32px; line-height:1.2; font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">' +
			'  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg> Importar Plantilla' +
			'</button>';
		
		// Crear el lightbox modal centrado (ancho máximo 700px, cabecera oscura y cuerpo scrollable con imagen de captura al 100%)
		var lightboxHtml = 
			'<div class="wpat-preview-lightbox-overlay" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.75); display:flex; align-items:center; justify-content:center; z-index:999999; font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">' +
			'  <div class="wpat-preview-lightbox-container" style="background:#fff; width:95%; max-width:700px; height:90%; border-radius:8px; overflow:hidden; position:relative; display:flex; flex-direction:column; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);">' +
			'    <div class="wpat-preview-lightbox-header" style="padding:10px 20px; border-bottom:1px solid #1a1a1a; display:flex; justify-content:space-between; align-items:center; background:#222; height:55px; box-sizing:border-box;">' +
			'      <span style="font-weight:600; color:#fff; font-size:14px; text-transform:capitalize;">' + tplTitle + '</span>' +
			'      <div style="display:flex; align-items:center; gap:15px;">' +
			         actionButtonHtml +
			'        <button type="button" class="wpat-close-lightbox-btn" onmouseover="this.style.color=\'#fff\'" onmouseout="this.style.color=\'#8a8a8a\'" style="background:none; border:none; color:#8a8a8a; font-size:24px; cursor:pointer; line-height:1; padding:0; margin:0 0 2px 0; outline:none; transition:color 0.2s;">&times;</button>' +
			'      </div>' +
			'    </div>' +
			'    <div class="wpat-preview-lightbox-body" style="flex:1; background:#eaeaea; position:relative; overflow-y:auto; overflow-x:hidden;">' +
			'      <img src="' + thumbUrl + '" style="width:100%; height:auto; display:block; margin:0;" />' +
			'    </div>' +
			'  </div>' +
			'</div>';
		
		$('body').append(lightboxHtml);
	});

	// Cerrar lightbox al hacer clic en cerrar o fuera del modal
	$(document).on('click', '.wpat-close-lightbox-btn, .wpat-preview-lightbox-overlay', function(e) {
		if (e.target === this || $(this).hasClass('wpat-close-lightbox-btn')) {
			$('.wpat-preview-lightbox-overlay').remove();
		}
	});

	// --- ACCIONES AJAX DEL BOT BLOCKER ---
	$(document).on('click', '.wpat-unblock-ip-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var ip = $btn.data('ip');
		var nonce = $('#wpat_bot_blocker_ajax_nonce').val();
		var $row = $btn.closest('tr');

		if (!confirm('¿Estás seguro de que deseas desbloquear la IP ' + ip + '?')) {
			return;
		}

		$btn.prop('disabled', true).text('Procesando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_unblock_ip',
				security: nonce,
				ip: ip
			},
			success: function(response) {
				if (response.success) {
					$row.fadeOut(300, function() {
						$row.remove();
						var $tbody = $('.wpat-blocked-ips-table tbody');
						if ($tbody.find('tr').length === 0) {
							$tbody.append('<tr class="no-blocked-ips-row"><td colspan="5" style="text-align: center; color: #94a3b8; padding: 25px 0;">No hay direcciones IPs bloqueadas en este momento.</td></tr>');
						}
					});
					showToast('IP desbloqueada correctamente.', false);
				} else {
					$btn.prop('disabled', false).text('Desbloquear');
					alert('Error: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Desbloquear');
				alert('Fallo de conexión al desbloquear la IP.');
			}
		});
	});

	$(document).on('click', '.wpat-whitelist-ip-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var ip = $btn.data('ip');
		var nonce = $('#wpat_bot_blocker_ajax_nonce').val();
		var $row = $btn.closest('tr');

		if (!confirm('¿Estás seguro de que deseas desbloquear y añadir la IP ' + ip + ' a la lista blanca?')) {
			return;
		}

		$btn.prop('disabled', true).text('Procesando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_whitelist_ip',
				security: nonce,
				ip: ip
			},
			success: function(response) {
				if (response.success) {
					$row.fadeOut(300, function() {
						$row.remove();
						var $tbody = $('.wpat-blocked-ips-table tbody');
						if ($tbody.find('tr').length === 0) {
							$tbody.append('<tr class="no-blocked-ips-row"><td colspan="5" style="text-align: center; color: #94a3b8; padding: 25px 0;">No hay direcciones IPs bloqueadas en este momento.</td></tr>');
						}
					});
					// Actualizar textarea de lista blanca
					$('#wpat_bot_blocker_whitelist').val(response.data.whitelist);
					showToast('IP añadida a la lista blanca.', false);
				} else {
					$btn.prop('disabled', false).text('Lista Blanca');
					alert('Error: ' + (response.data ? response.data.message : 'Error desconocido.'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Lista Blanca');
				alert('Fallo de conexión al añadir a la lista blanca.');
			}
		});
	});

	// --- ASISTENTE DE CONFIGURACIÓN INICIAL ---
	// Marcar/Desmarcar sub-páginas de forma coordinada
	$('#wpat_init_create_pages').on('change', function() {
		var isChecked = $(this).is(':checked');
		$('.wpat-init-page-checkbox').prop('checked', isChecked);
	});

	// Si se desmarca cualquier sub-página de página individual, actualizar el padre
	$('.wpat-init-page-checkbox').on('change', function() {
		var totalCheckboxes = $('.wpat-init-page-checkbox').length;
		var checkedCheckboxes = $('.wpat-init-page-checkbox:checked').length;
		$('#wpat_init_create_pages').prop('checked', totalCheckboxes === checkedCheckboxes);
	});

	// Confirmación y overlay de carga antes de ejecutar
	$('#wpat_run_initial_setup_btn').on('click', function(e) {
		var anyChecked = $('.wpat-init-action-checkbox:checked').length > 0;
		if (!anyChecked) {
			alert('Por favor, selecciona al menos una acción para ejecutar.');
			e.preventDefault();
			return;
		}
		
		var confirmed = confirm('¿Estás seguro de que deseas ejecutar la configuración inicial seleccionada?\n\nEsta acción descargará temas/plugins y modificará contenidos y ajustes del sitio.');
		if (!confirmed) {
			e.preventDefault();
			return;
		}

		// Mostrar overlay de carga premium
		var overlayHtml = 
			'<div id="wpat_setup_loading_overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(4px); z-index: 999999; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Oxygen-Sans, Ubuntu, Cantarell, \'Helvetica Neue\', sans-serif;">' +
				'<div style="background: #1e293b; padding: 35px 40px; border-radius: 12px; border: 1px solid #334155; text-align: center; max-width: 450px; width: 90%; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5);">' +
					'<div style="font-size: 20px; font-weight: 700; margin-bottom: 12px; color: #38bdf8; letter-spacing: -0.025em;">Configuración Inicial en Progreso</div>' +
					'<div style="font-size: 14px; color: #94a3b8; margin-bottom: 25px; line-height: 1.5;">Descargando recursos, configurando páginas y aplicando ajustes del sitio. Por favor, no cierres ni recargues la página...</div>' +
					'<div style="width: 100%; height: 6px; background: #334155; border-radius: 999px; overflow: hidden; position: relative;">' +
						'<div style="width: 35%; height: 100%; background: #38bdf8; border-radius: 999px; position: absolute; animation: wpatSetupProgress 1.6s infinite ease-in-out;"></div>' +
					'</div>' +
				'</div>' +
				'<style>' +
					'@keyframes wpatSetupProgress { 0% { left: -35%; } 50% { width: 45%; } 100% { left: 100%; } }' +
				'</style>' +
			'</div>';
		$('body').append(overlayHtml);
	});

	// 5. Módulo SEO: Pestañas, Previsualización y Análisis SEO/Legibilidad Reactivo
	
	// Selector de Pestañas Yoast Style
	$(document).on('click', '.wpat-seo-nav-tab', function(e) {
		e.preventDefault();
		$('.wpat-seo-nav-tab').removeClass('active').css({
			'background': 'none',
			'border-color': 'transparent',
			'color': '#64748b'
		});
		$(this).addClass('active').css({
			'background': '#fff',
			'border-color': '#cbd5e1',
			'color': '#1e293b'
		});
		$('.wpat-seo-tab-content').hide();
		var targetTab = $(this).data('wpat-tab');
		$('#' + targetTab).show();
	});

	// Cambiar modo de previsualización (móvil vs escritorio radio buttons)
	$(document).on('change', 'input[name="wpat_seo_preview_mode"]', function() {
		var mode = $(this).val();
		if (mode === 'mobile') {
			$('#wpat-seo-google-preview-mobile').show();
			$('#wpat-seo-google-preview-desktop').hide();
		} else {
			$('#wpat-seo-google-preview-mobile').hide();
			$('#wpat-seo-google-preview-desktop').show();
		}
	});

	// Cargador de medios para Open Graph
	$(document).on('click', '#wpat_seo_og_image_btn', function(e) {
		e.preventDefault();
		var custom_og_uploader = wp.media({
			title: 'Seleccionar Imagen para Redes Sociales',
			button: { text: 'Usar esta Imagen' },
			multiple: false
		}).on('select', function() {
			var attachment = custom_og_uploader.state().get('selection').first().toJSON();
			$('#wpat_seo_og_image_input').val(attachment.url);
		}).open();
	});

	// Barras de progreso de caracteres
	function updateSeoTitleBar(len) {
		var $bar = $('#wpat_seo_title_progress_bar');
		if (!$bar.length) return;
		var percent = Math.min((len / 60) * 100, 100);
		$bar.css('width', percent + '%');
		if (len === 0) {
			$bar.css('background', '#e2e8f0');
		} else if (len >= 50 && len <= 60) {
			$bar.css('background', '#10b981'); // Verde
		} else if (len > 60) {
			$bar.css('background', '#ef4444'); // Rojo (Largo)
		} else {
			$bar.css('background', '#eab308'); // Amarillo (Corto)
		}
	}

	function updateSeoDescBar(len) {
		var $bar = $('#wpat_seo_desc_progress_bar');
		if (!$bar.length) return;
		var percent = Math.min((len / 160) * 100, 100);
		$bar.css('width', percent + '%');
		if (len === 0) {
			$bar.css('background', '#e2e8f0');
		} else if (len >= 120 && len <= 160) {
			$bar.css('background', '#10b981'); // Verde
		} else if (len > 160) {
			$bar.css('background', '#ef4444'); // Rojo (Largo)
		} else {
			$bar.css('background', '#eab308'); // Amarillo (Corto)
		}
	}

	// Helper para eliminar acentos de un string (insensibilidad a tildes/acentos)
	function removeAccents(str) {
		if (!str) return "";
		return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
	}

	// Análisis SEO y Legibilidad interactivo en tiempo real (Estilo Yoast con soporte para múltiples frases clave)
	function runSeoAndReadabilityAnalysis() {
		if (!$('#wpat_seo_keyword_input').length) return;

		// Sincronizar título y slug de WordPress en tiempo real
		if (window.wp && wp.data && wp.data.select && wp.data.select('core/editor')) {
			try {
				var currentSlug = wp.data.select('core/editor').getEditedPostAttribute('slug');
				if (currentSlug && $('#wpat_seo_slug_input').val() !== currentSlug && !$('#wpat_seo_slug_input').is(':focus')) {
					$('#wpat_seo_slug_input').val(currentSlug);
				}
				
				var currentTitle = wp.data.select('core/editor').getEditedPostAttribute('title') || "";
				var placeholderAttr = $('#wpat_seo_title_input').attr('placeholder') || "";
				var parts = placeholderAttr.split(' - ');
				var siteName = parts.length > 1 ? parts.slice(1).join(' - ') : "";
				var formattedPlaceholder = currentTitle ? (currentTitle + (siteName ? ' - ' + siteName : '')) : "Título de la entrada";
				$('#wpat_seo_title_input').attr('placeholder', formattedPlaceholder);
			} catch (err) {}
		} else if ($('#title').length) {
			var currentTitle = $('#title').val() || "";
			var placeholderAttr = $('#wpat_seo_title_input').attr('placeholder') || "";
			var parts = placeholderAttr.split(' - ');
			var siteName = parts.length > 1 ? parts.slice(1).join(' - ') : "";
			var formattedPlaceholder = currentTitle ? (currentTitle + (siteName ? ' - ' + siteName : '')) : "Título de la entrada";
			$('#wpat_seo_title_input').attr('placeholder', formattedPlaceholder);
		}

		// 1. Obtener entradas de texto
		var keywordInput = $('#wpat_seo_keyword_input').val() ? $('#wpat_seo_keyword_input').val().trim() : "";
		var keywords = keywordInput.split(',').map(function(k) { return k.trim().toLowerCase(); }).filter(function(k) { return k.length > 0; });
		
		var title = $('#wpat_seo_title_input').val() ? $('#wpat_seo_title_input').val().trim() : $('#wpat_seo_title_input').attr('placeholder');
		var desc = $('#wpat_seo_desc_input').val() ? $('#wpat_seo_desc_input').val().trim() : "";
		
		var isCornerstone = $('#wpat_seo_cornerstone_input').is(':checked');
		var minWords = isCornerstone ? 900 : 300;

		// Actualizar previsualización de Google
		var displayTitle = title ? title : "Título del post";
		var displayDesc = desc ? desc : "Por favor, escribe una meta descripción atractiva para que este contenido capte visitas en los resultados de búsqueda de Google.";
		$('.wpat-seo-preview-title').text(displayTitle);
		$('.wpat-seo-preview-desc').text(displayDesc);
		$('#wpat_seo_title_len').text(displayTitle.length);
		$('#wpat_seo_desc_len').text(desc.length);
		updateSeoTitleBar(displayTitle.length);
		updateSeoDescBar(desc.length);

		// 2. Obtener contenido del editor (Gutenberg o Clásico)
		var content = "";
		if (window.wp && wp.data && wp.data.select && wp.data.select('core/editor')) {
			try {
				content = wp.data.select('core/editor').getEditedPostContent() || "";
			} catch (err) {}
		}
		if (!content && $('#content').length) {
			if (window.tinyMCE && tinyMCE.get('content')) {
				content = tinyMCE.get('content').getContent();
			} else {
				content = $('#content').val();
			}
		}

		var cleanText = content ? content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() : "";
		var words = cleanText ? cleanText.split(/\s+/).length : 0;

		// --- ANÁLISIS SEO ---
		var seoGood = [];
		var seoImprovements = [];
		var seoIssues = [];

		if (keywords.length === 0) {
			$('#wpat_seo_bullet_seo').css('background', '#94a3b8'); // Gris
			$('#wpat_seo_analysis_bullets').html('<div><span style="color:#94a3b8; font-size:16px; margin-right:6px;">⚪</span> Por favor, escribe una o más frases clave objetivo (separadas por comas) para habilitar los análisis automáticos de SEO.</div>');
		} else {
			
			// A. Palabra clave en el título SEO (insensible a acentos)
			var titleFound = [];
			var titleMissing = [];
			var normalizedTitle = removeAccents(title.toLowerCase());
			keywords.forEach(function(kw) {
				var normalizedKw = removeAccents(kw);
				if (normalizedTitle.indexOf(normalizedKw) !== -1) {
					titleFound.push(kw);
				} else {
					titleMissing.push(kw);
				}
			});
			if (titleMissing.length === 0) {
				seoGood.push('<strong>Frases clave en el título:</strong> ¡Perfecto! Todas tus frases clave objetivo aparecen en el título SEO.');
			} else if (titleFound.length > 0) {
				seoImprovements.push('<strong>Frases clave en el título:</strong> Se encontraron en el título las frases ("' + titleFound.join('", "') + '"), pero faltan ("' + titleMissing.join('", "') + '").');
			} else {
				seoIssues.push('<strong>Frases clave en el título:</strong> Ninguna de tus frases clave objetivo aparece en el título SEO.');
			}

			// B. Palabra clave en la meta descripción (insensible a acentos)
			var descFound = [];
			var descMissing = [];
			var normalizedDesc = removeAccents(desc.toLowerCase());
			keywords.forEach(function(kw) {
				var normalizedKw = removeAccents(kw);
				if (normalizedDesc.indexOf(normalizedKw) !== -1) {
					descFound.push(kw);
				} else {
					descMissing.push(kw);
				}
			});
			if (descMissing.length === 0) {
				seoGood.push('<strong>Frases clave en la descripción:</strong> Todas tus frases clave objetivo aparecen en la meta descripción.');
			} else if (descFound.length > 0) {
				seoImprovements.push('<strong>Frases clave en la descripción:</strong> Algunas frases clave no aparecen en la meta descripción ("' + descMissing.join('", "') + '").');
			} else {
				seoIssues.push('<strong>Frases clave en la descripción:</strong> Ninguna de tus frases clave objetivo aparece en la meta descripción.');
			}

			// C. Frase clave al inicio del texto (insensible a acentos)
			var introFound = [];
			var introMissing = [];
			var introWords = cleanText.toLowerCase().split(/\s+/).slice(0, 100).join(' ');
			var normalizedIntro = removeAccents(introWords);
			keywords.forEach(function(kw) {
				var normalizedKw = removeAccents(kw);
				if (normalizedIntro.indexOf(normalizedKw) !== -1) {
					introFound.push(kw);
				} else {
					introMissing.push(kw);
				}
			});
			if (introMissing.length === 0) {
				seoGood.push('<strong>Frases clave en la introducción:</strong> ¡Excelente! Todas tus frases clave aparecen en el primer párrafo.');
			} else if (introFound.length > 0) {
				seoImprovements.push('<strong>Frases clave en la introducción:</strong> Faltan algunas frases clave al inicio del texto ("' + introMissing.join('", "') + '").');
			} else {
				seoIssues.push('<strong>Frases clave en la introducción:</strong> Ninguna de tus frases clave aparece en el primer párrafo del texto.');
			}

			// D. Densidad de palabra clave (insensible a acentos con límites de palabra precisos)
			var normalizedCleanText = removeAccents(cleanText.toLowerCase());
			keywords.forEach(function(kw) {
				var normalizedKw = removeAccents(kw);
				var escapedKeyword = normalizedKw.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
				var regex = new RegExp('(?<=^|[^a-zA-Z0-9])' + escapedKeyword + '(?=$|[^a-zA-Z0-9])', 'gi');
				var matches = normalizedCleanText.match(regex);
				var occurrences = matches ? matches.length : 0;
				var density = words > 0 ? ((occurrences / words) * 100) : 0;

				if (occurrences === 0) {
					seoIssues.push('<strong>Frase clave "' + kw + '" en el texto:</strong> No se encontró esta frase clave en el contenido del artículo. Procura escribirla al menos un par de veces para que Google entienda la temática.');
				} else if (density >= 0.5 && density <= 2.5) {
					seoGood.push('<strong>Densidad de "' + kw + '":</strong> ¡Excelente! Aparece ' + occurrences + ' veces (densidad del ' + density.toFixed(2) + '%), lo cual es ideal.');
				} else if (density > 2.5) {
					seoIssues.push('<strong>Densidad de "' + kw + '":</strong> Aparece ' + occurrences + ' veces (densidad del ' + density.toFixed(2) + '%). ¡Es demasiado alta! Reduce su frecuencia para evitar el Keyword Stuffing.');
				} else {
					seoImprovements.push('<strong>Densidad de "' + kw + '":</strong> Aparece ' + occurrences + ' veces (densidad del ' + density.toFixed(2) + '%). Es un poco baja; se recomienda al menos un 0.50% de densidad.');
				}
			});

			// E. Longitud del título SEO
			var tLen = displayTitle.length;
			if (tLen >= 50 && tLen <= 60) {
				seoGood.push('<strong>Longitud del título SEO:</strong> ¡Excelente longitud!');
			} else if (tLen > 60) {
				seoIssues.push('<strong>Longitud del título SEO:</strong> Es demasiado largo (' + tLen + ' caracteres). Procura que no supere los 60.');
			} else {
				seoImprovements.push('<strong>Longitud del título SEO:</strong> Es corto (' + tLen + ' caracteres). Rellena más espacio usando palabras atractivas.');
			}

			// F. Longitud de la meta descripción
			var dLen = desc.length;
			if (dLen >= 120 && dLen <= 160) {
				seoGood.push('<strong>Longitud de la meta descripción:</strong> ¡Excelente longitud!');
			} else if (dLen > 160) {
				seoIssues.push('<strong>Longitud de la meta descripción:</strong> Supera los 160 caracteres. Intenta acortarla para que no se recorte en Google.');
			} else if (dLen > 0) {
				seoImprovements.push('<strong>Longitud de la meta descripción:</strong> Es corta (' + dLen + ' caracteres). Escribe más argumentos de venta.');
			} else {
				seoIssues.push('<strong>Meta descripción vacía:</strong> Escribe una meta descripción para capturar visitas.');
			}

			// G. Palabra clave en el Slug / URL
			var slugVal = $('#wpat_seo_slug_input').val() || "";
			if (slugVal) {
				var normalizedSlug = removeAccents(slugVal.toLowerCase()).replace(/[^a-z0-9]/g, '-');
				var slugFound = [];
				var slugMissing = [];
				keywords.forEach(function(kw) {
					var kwSlug = removeAccents(kw.toLowerCase()).trim().replace(/\s+/g, '-').replace(/[^a-z0-9\-]/g, '');
					if (kwSlug && normalizedSlug.indexOf(kwSlug) !== -1) {
						slugFound.push(kw);
					} else {
						slugMissing.push(kw);
					}
				});
				if (slugMissing.length === 0) {
					seoGood.push('<strong>Frases clave en el Slug (URL):</strong> ¡Excelente! El enlace permanente contiene la frase clave.');
				} else if (slugFound.length > 0) {
					seoImprovements.push('<strong>Frases clave en el Slug (URL):</strong> Se encontraron en la URL ("' + slugFound.join('", "') + '"), pero faltan ("' + slugMissing.join('", "') + '").');
				} else {
					seoImprovements.push('<strong>Frases clave en el Slug (URL):</strong> Tu URL no incluye la frase clave objetivo.');
				}
			}

			// H. Palabra clave en subtítulos H2/H3
			if (content) {
				var hMatches = content.match(/<h[2-4][^>]*>([\s\S]*?)<\/h[2-4]>/gi);
				var headersHtml = hMatches ? removeAccents(hMatches.join(' ').toLowerCase()) : "";
				if (headersHtml) {
					var hFound = false;
					keywords.forEach(function(kw) {
						var normalizedKw = removeAccents(kw);
						if (normalizedKw && headersHtml.indexOf(normalizedKw) !== -1) {
							hFound = true;
						}
					});
					if (hFound) {
						seoGood.push('<strong>Subtítulos (H2/H3):</strong> ¡Genial! Usas la frase clave en encabezados de sección.');
					} else {
						seoImprovements.push('<strong>Subtítulos (H2/H3):</strong> Se aconseja incluir la frase clave en al menos un subtítulo H2 o H3.');
					}
				}
			}

			// I. Palabra clave en atributos Alt de imágenes
			if (content) {
				var imgTags = content.match(/<img[^>]+>/gi);
				if (imgTags && imgTags.length > 0) {
					var altTexts = [];
					imgTags.forEach(function(img) {
						var altMatch = img.match(/alt=["']([^"']*)["']/i);
						if (altMatch && altMatch[1]) {
							altTexts.push(removeAccents(altMatch[1].toLowerCase()));
						}
					});
					var allAlts = altTexts.join(' ');
					var altFound = false;
					keywords.forEach(function(kw) {
						var normalizedKw = removeAccents(kw);
						if (normalizedKw && allAlts.indexOf(normalizedKw) !== -1) {
							altFound = true;
						}
					});
					if (altFound) {
						seoGood.push('<strong>Texto alternativo (Alt) de imágenes:</strong> ¡Correcto! Tus imágenes incluyen la frase clave.');
					} else {
						seoImprovements.push('<strong>Texto alternativo (Alt) de imágenes:</strong> Añade la frase clave al atributo Alt de tus imágenes para posicionar en Google Imágenes.');
					}
				}
			}

			// Renderizar lista SEO
			var seoHTML = "";
			if (seoIssues.length > 0) {
				seoHTML += '<div style="margin-bottom:10px;"><strong style="color:#ef4444; font-size:12px; text-transform:uppercase;">Problemas (' + seoIssues.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
				seoIssues.forEach(function(item) {
					seoHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#ef4444; margin-right:8px; font-size:14px;">🔴</span> <span>' + item + '</span></li>';
				});
				seoHTML += '</ul></div>';
			}
			if (seoImprovements.length > 0) {
				seoHTML += '<div style="margin-bottom:10px;"><strong style="color:#eab308; font-size:12px; text-transform:uppercase;">Mejoras (' + seoImprovements.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
				seoImprovements.forEach(function(item) {
					seoHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#eab308; margin-right:8px; font-size:14px;">🟡</span> <span>' + item + '</span></li>';
				});
				seoHTML += '</ul></div>';
			}
			if (seoGood.length > 0) {
				seoHTML += '<div><strong style="color:#10b981; font-size:12px; text-transform:uppercase;">Buenos resultados (' + seoGood.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
				seoGood.forEach(function(item) {
					seoHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#10b981; margin-right:8px; font-size:14px;">🟢</span> <span>' + item + '</span></li>';
				});
				seoHTML += '</ul></div>';
			}
			$('#wpat_seo_analysis_bullets').html(seoHTML);

			// Actualizar color de la pestaña SEO
			if (seoIssues.length > 0) {
				$('#wpat_seo_bullet_seo').css('background', '#ef4444');
			} else if (seoImprovements.length > 0) {
				$('#wpat_seo_bullet_seo').css('background', '#eab308');
			} else {
				$('#wpat_seo_bullet_seo').css('background', '#10b981');
			}
		}

		// --- ANÁLISIS DE LEGIBILIDAD ---
		var readGood = [];
		var readImprovements = [];
		var readIssues = [];

		// A. Longitud del texto (Ajustable por contenido esencial)
		if (words >= minWords) {
			readGood.push('<strong>Longitud del texto:</strong> Contiene ' + words + ' palabras (óptimo para contenido ' + (isCornerstone ? 'esencial' : 'estándar') + ').');
		} else {
			readIssues.push('<strong>Longitud del texto:</strong> El contenido tiene solo ' + words + ' palabras. Se recomienda un mínimo de ' + minWords + ' palabras para contenidos de tipo ' + (isCornerstone ? 'esencial' : 'estándar') + '.');
		}

		// B. Distribución de subtítulos H2/H3
		if (words > 300) {
			var hasHeaders = (content.indexOf('<h2') !== -1 || content.indexOf('<h3') !== -1 || content.indexOf('<!-- wp:heading') !== -1);
			if (hasHeaders) {
				readGood.push('<strong>Distribución de subtítulos:</strong> Excelente variedad, usas encabezados de sección.');
			} else {
				readIssues.push('<strong>Distribución de subtítulos:</strong> Tu texto es largo y no contiene subtítulos (H2/H3). Agrégalos para facilitar la lectura.');
			}
		} else {
			readGood.push('<strong>Distribución de subtítulos:</strong> No se requieren subtítulos para un texto tan corto.');
		}

		// C. Longitud de los párrafos
		var paragraphs = content ? content.split(/<\/p>|<br\s*\/?>/i) : [];
		var tooLongParagraph = false;
		paragraphs.forEach(function(p) {
			var pWords = p.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().split(/\s+/).length;
			if (pWords > 150) {
				tooLongParagraph = true;
			}
		});

		if (!tooLongParagraph) {
			readGood.push('<strong>Longitud de los párrafos:</strong> Todos tus párrafos tienen una extensión adecuada.');
		} else {
			readIssues.push('<strong>Longitud de los párrafos:</strong> Tienes algún párrafo que supera las 150 palabras. Divídelo para que sea más legible.');
		}

		// D. Palabras de transición en español
		var SpanishTransitions = ['además', 'sin embargo', 'por lo tanto', 'también', 'pero', 'entonces', 'así que', 'por consiguiente', 'no obstante', 'dado que', 'debido a', 'así como', 'ya que', 'por ejemplo', 'por último', 'finalmente', 'en primer lugar', 'por otra parte', 'en consecuencia'];
		var sentences = cleanText.split(/[.!?]+/);
		var totalSentences = 0;
		var transitionSentences = 0;

		sentences.forEach(function(s) {
			var sentenceText = s.trim().toLowerCase();
			if (sentenceText.length > 5) {
				totalSentences++;
				var hasTransition = false;
				SpanishTransitions.forEach(function(t) {
					if (sentenceText.indexOf(t) !== -1) {
						hasTransition = true;
					}
				});
				if (hasTransition) {
					transitionSentences++;
				}
			}
		});

		var ratio = totalSentences > 0 ? (transitionSentences / totalSentences) * 100 : 0;
		if (ratio >= 20) {
			readGood.push('<strong>Palabras de transición:</strong> El ' + Math.round(ratio) + '% de las frases contienen palabras de transición. ¡Excelente!');
		} else {
			readImprovements.push('<strong>Palabras de transición:</strong> Solo el ' + Math.round(ratio) + '% de las frases usan palabras de transición. Intenta usar más nexos como "además", "sin embargo" o "por lo tanto".');
		}

		// E. Frases consecutivas que inician igual
		var consecutiveStart = false;
		var lastStartWord = "";
		var consecutiveCount = 1;
		sentences.forEach(function(s) {
			var wordsInSentence = s.trim().split(/\s+/);
			if (wordsInSentence.length > 0 && wordsInSentence[0].length > 2) {
				var startWord = wordsInSentence[0].toLowerCase();
				if (startWord === lastStartWord) {
					consecutiveCount++;
					if (consecutiveCount >= 3) {
						consecutiveStart = true;
					}
				} else {
					lastStartWord = startWord;
					consecutiveCount = 1;
				}
			}
		});

		if (!consecutiveStart) {
			readGood.push('<strong>Frases consecutivas:</strong> Excelente variedad en el inicio de las frases.');
		} else {
			readImprovements.push('<strong>Frases consecutivas:</strong> Tienes 3 o más frases seguidas que empiezan con la misma palabra. Varía los inicios.');
		}

		// Renderizar lista de Legibilidad
		var readHTML = "";
		if (readIssues.length > 0) {
			readHTML += '<div style="margin-bottom:10px;"><strong style="color:#ef4444; font-size:12px; text-transform:uppercase;">Problemas (' + readIssues.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
			readIssues.forEach(function(item) {
				readHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#ef4444; margin-right:8px; font-size:14px;">🔴</span> <span>' + item + '</span></li>';
			});
			readHTML += '</ul></div>';
		}
		if (readImprovements.length > 0) {
			readHTML += '<div style="margin-bottom:10px;"><strong style="color:#eab308; font-size:12px; text-transform:uppercase;">Mejoras (' + readImprovements.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
			readImprovements.forEach(function(item) {
				readHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#eab308; margin-right:8px; font-size:14px;">🟡</span> <span>' + item + '</span></li>';
			});
			readHTML += '</ul></div>';
		}
		if (readGood.length > 0) {
			readHTML += '<div><strong style="color:#10b981; font-size:12px; text-transform:uppercase;">Buenos resultados (' + readGood.length + ')</strong><ul style="margin:5px 0 0 0; padding-left:15px; list-style-type:none;">';
			readGood.forEach(function(item) {
				readHTML += '<li style="margin-bottom:4px; display:flex; align-items:start;"><span style="color:#10b981; margin-right:8px; font-size:14px;">🟢</span> <span>' + item + '</span></li>';
			});
			readHTML += '</ul></div>';
		}
		$('#wpat_readability_analysis_bullets').html(readHTML);

		// Actualizar color de la pestaña Legibilidad
		if (readIssues.length > 0) {
			$('#wpat_readability_bullet_readability').css('background', '#ef4444');
		} else if (readImprovements.length > 0) {
			$('#wpat_readability_bullet_readability').css('background', '#eab308');
		} else {
			$('#wpat_readability_bullet_readability').css('background', '#10b981');
		}
	}

	// Debounce timer para comprobar canibalización
	var canDebounceTimer = null;
	function checkKeywordCannibalization() {
		clearTimeout(canDebounceTimer);
		canDebounceTimer = setTimeout(function() {
			var kw = $('#wpat_seo_keyword_input').val() ? $('#wpat_seo_keyword_input').val().trim() : '';
			if (!kw || typeof wpat_seo_data === 'undefined') {
				$('#wpat_seo_cannibalization_alert').slideUp(150).empty();
				return;
			}
			$.ajax({
				url: wpat_seo_data.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wpat_seo_check_cannibalization',
					_wpnonce: wpat_seo_data.nonce,
					keyword: kw,
					post_id: wpat_seo_data.post_id || 0
				},
				success: function(res) {
					if (res.success && res.data && res.data.cannibalized && res.data.duplicates.length > 0) {
						var html = '<div style="display:flex; align-items:flex-start; gap:8px;">' +
							'<span class="dashicons dashicons-warning" style="color:#ef4444; font-size:18px; width:18px; height:18px; line-height:18px; margin-top:2px;"></span>' +
							'<div><strong>¡Alerta de Canibalización SEO!</strong> Esta palabra clave ya está asignada a otros contenidos:<ul style="margin:4px 0 6px 0; padding-left:18px; list-style-type:disc;">';
						res.data.duplicates.forEach(function(d) {
							html += '<li><a href="' + d.edit_url + '" target="_blank" style="color:#b91c1c; text-decoration:underline; font-weight:600;">' + d.title + '</a> (Clave: "<em>' + d.keyword + '</em>")</li>';
						});
						html += '</ul><span style="font-size:11px; color:#7f1d1d;">Evita repetir la misma palabra clave objetivo en múltiples páginas para no competir contigo mismo en Google.</span></div></div>';
						$('#wpat_seo_cannibalization_alert').html(html).slideDown(200);
					} else {
						$('#wpat_seo_cannibalization_alert').slideUp(150).empty();
					}
				}
			});
		}, 500);
	}

	// Sugerir palabra clave desde el título
	$(document).on('click', '#wpat_seo_suggest_kw_btn', function(e) {
		e.preventDefault();
		var title = $('#wpat_seo_title_input').val() || $('#wpat_seo_title_input').attr('placeholder') || "";
		if (title) {
			title = title.split(' - ')[0].trim();
		}
		if (!title && $('#title').length) {
			title = $('#title').val() ? $('#title').val().trim() : "";
		}
		if (!title) return;

		var stopwords = ['de', 'la', 'el', 'en', 'y', 'a', 'los', 'del', 'las', 'un', 'por', 'con', 'no', 'una', 'su', 'para', 'es', 'al', 'lo', 'como', 'más', 'o', 'pero', 'sus', 'le', 'ha', 'me', 'si', 'sin', 'sobre', 'este', 'ya', 'entre', 'cuando', 'todo', 'esta', 'ser', 'son', 'dos', 'también', 'fue', 'había', 'era', 'muy', 'hasta', 'desde', 'está', 'mi', 'porque', 'qué', 'solo', 'han', 'yo', 'hay', 'vez', 'puede', 'todos', 'así', 'nos', 'ni', 'parte', 'tiene', 'él', 'uno', 'donde', 'bien', 'guía', 'completa', 'cómo', 'paso'];
		var cleanTitle = title.toLowerCase().replace(/[^a-z0-9áéíóúüñ\s]/gi, ' ');
		var wordsArr = cleanTitle.split(/\s+/).filter(function(w) {
			return w.length > 2 && stopwords.indexOf(w) === -1;
		});

		if (wordsArr.length > 0) {
			var suggested = wordsArr.slice(0, 3).join(' ');
			$('#wpat_seo_keyword_input').val(suggested).trigger('input');
		}
	});

	// Escuchar cambios de escritura en vivo para actualizar análisis
	$(document).on('input keyup change', '#wpat_seo_keyword_input, #wpat_seo_title_input, #wpat_seo_desc_input', function() {
		runSeoAndReadabilityAnalysis();
		if ($(this).attr('id') === 'wpat_seo_keyword_input') {
			checkKeywordCannibalization();
		}
	});

	// Escuchar conmutador de contenido esencial (Cornerstone)
	$(document).on('change', '#wpat_seo_cornerstone_input', function() {
		runSeoAndReadabilityAnalysis();
	});

	// Escuchar cambios de slug en nuestra metabox para actualizar Gutenberg
	$(document).on('input change', '#wpat_seo_slug_input', function() {
		var newSlug = $(this).val();
		if (window.wp && wp.data && wp.data.dispatch && wp.data.dispatch('core/editor')) {
			try {
				wp.data.dispatch('core/editor').editPost({ slug: newSlug });
			} catch (err) {}
		}
	});

	// Suscribirse a cambios en Gutenberg (Contenido, Título y Slug)
	if (window.wp && wp.data && wp.data.subscribe) {
		var lastContent = "";
		var lastTitle = "";
		var lastSlug = "";
		wp.data.subscribe(function() {
			try {
				var newContent = wp.data.select('core/editor').getEditedPostContent() || "";
				var newTitle = wp.data.select('core/editor').getEditedPostAttribute('title') || "";
				var newSlug = wp.data.select('core/editor').getEditedPostAttribute('slug') || "";

				if (newContent !== lastContent || newTitle !== lastTitle || newSlug !== lastSlug) {
					lastContent = newContent;
					lastTitle = newTitle;
					lastSlug = newSlug;
					runSeoAndReadabilityAnalysis();
				}
			} catch (err) {}
		});
	}

	// Suscribirse al editor clásico (incluyendo TinyMCE)
	if ($('#content').length) {
		$('#content, #title').on('input change', function() {
			runSeoAndReadabilityAnalysis();
		});

		setTimeout(function() {
			if (window.tinyMCE && tinyMCE.get('content')) {
				tinyMCE.get('content').on('keyup change', function() {
					runSeoAndReadabilityAnalysis();
				});
			}
		}, 1500);
	}

	// Ejecutar primer análisis al cargar la página
	setTimeout(function() {
		runSeoAndReadabilityAnalysis();
	}, 1000);
	
	// Re-análisis preventivo al hacer clic en las pestañas
	$(document).on('click', '.wpat-seo-nav-tab', function() {
		runSeoAndReadabilityAnalysis();
	});

	// 6. Auditoría SEO del Sitio (AJAX Secuencial con Filtros e Historial)
	$('#wpat_seo_scan_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $status = $('#wpat_seo_scan_status');
		var $progressWrapper = $('#wpat_seo_scan_progress');
		var $progressBar = $('#wpat_seo_progress_bar');
		var $progressPercent = $('#wpat_seo_progress_percent');
		var $progressLabel = $('#wpat_seo_progress_label');
		var $resultsWrapper = $('#wpat_seo_audit_results');
		var $tableBody = $('#wpat_seo_audit_table_body');
		var $tableFilters = $('#wpat_seo_table_filters');

		// Resetear filtros previos
		$tableFilters.hide();
		$('#wpat_seo_table_search').val('');
		$('#wpat_seo_table_status_filter').val('all');
		seoAuditCurrentPage = 1;

		var postTypeFilter = $('#wpat_seo_filter_post_type').val() || 'all';

		$btn.prop('disabled', true).text('Escaneando...');
		$status.text('Obteniendo lista de páginas...');
		$progressWrapper.slideDown(200);
		$resultsWrapper.hide();
		$tableBody.empty();
		$progressBar.css('width', '0%').css('background', '#3b82f6');
		$progressPercent.text('0%');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_seo_get_pages_to_scan',
				post_type_filter: postTypeFilter
			},
			success: function(response) {
				if (response.success && response.data.ids && response.data.ids.length > 0) {
					var ids = response.data.ids;
					var total = ids.length;
					var processed = 0;
					var batchSize = 10;
					var batches = [];

					for (var i = 0; i < ids.length; i += batchSize) {
						batches.push(ids.slice(i, i + batchSize));
					}

					var currentBatchIndex = 0;

					function processNextBatch() {
						if (currentBatchIndex >= batches.length) {
							$btn.prop('disabled', false).text('Escanear Sitio Ahora');
							$status.text('¡Auditoría completada!');
							$progressLabel.text('Análisis completado al 100%');
							$progressBar.css('width', '100%').css('background', '#10b981');
							$progressPercent.text('100%');
							
							// Configurar y mostrar los filtros rápidos
							$tableFilters.css('display', 'flex');
							applySeoTableFilters();
							return;
						}

						var currentBatch = batches[currentBatchIndex];
						$progressLabel.text('Escaneando lote ' + (currentBatchIndex + 1) + ' de ' + batches.length + '...');

						$.ajax({
							url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
							type: 'POST',
							data: {
								action: 'wpat_seo_audit_page',
								post_ids: currentBatch
							},
							success: function(res) {
								if (res.success && res.data.results) {
									res.data.results.forEach(function(row) {
										var indexableBadge = row.indexable === 'index' 
											? '<span style="color:#047857; background:#d1fae5; padding:3px 8px; border-radius:12px; font-weight:700; font-size:11px;">🟢 Index</span>'
											: '<span style="color:#4b5563; background:#e5e7eb; padding:3px 8px; border-radius:12px; font-weight:700; font-size:11px;">⚪ noindex</span>';
										
										var keywordBadge = row.keyword 
											? '<span style="color:#1e293b; background:#f1f5f9; padding:4px 8px; border-radius:4px; font-size:12px; font-weight:600; display:inline-block; border:1px solid #cbd5e1;">' + row.keyword + '</span>'
											: '<span style="color:#b91c1c; font-weight:700; font-size:11px; background:#fee2fee; padding:2px 6px; border-radius:4px;">🔴 Vacío</span>';

										var titleBadge = '';
										if (row.title_status === 'empty') {
											titleBadge = '<span style="color:#b91c1c; font-weight:700; font-size:12px;">🔴 Vacío</span>';
										} else if (row.title_status === 'correct') {
											titleBadge = '<span style="color:#047857; font-weight:700; font-size:12px;">🟢 ' + row.title_length + ' carac.</span>';
										} else {
											titleBadge = '<span style="color:#b45309; font-weight:700; font-size:12px;">🟡 ' + row.title_length + ' carac. (Ajustar)</span>';
										}

										var descBadge = '';
										if (row.desc_status === 'empty') {
											descBadge = '<span style="color:#b91c1c; font-weight:700; font-size:12px;">🔴 Vacío</span>';
										} else if (row.desc_status === 'correct') {
											descBadge = '<span style="color:#047857; font-weight:700; font-size:12px;">🟢 ' + row.desc_length + ' carac.</span>';
										} else {
											descBadge = '<span style="color:#b45309; font-weight:700; font-size:12px;">🟡 ' + row.desc_length + ' carac. (Ajustar)</span>';
										}

										var editLink = row.edit_url 
											? '<a href="' + row.edit_url + '" class="row-title" style="font-weight:600; color:#3b82f6; text-decoration:none;" target="_blank">' + row.title + '</a>'
											: '<strong class="row-title">' + row.title + '</strong>';

										// Evaluar estado para los filtros de la tabla
										var hasIssues = (row.title_status !== 'correct' || row.desc_status !== 'correct' || row.title_status === 'empty' || row.desc_status === 'empty');
										var hasNoKeyword = (!row.keyword);
										var isOptimized = (row.title_status === 'correct' && row.desc_status === 'correct' && row.keyword);

										var actionButton = '';
										if (row.title_status === 'empty' || row.desc_status === 'empty') {
											actionButton = '<button type="button" class="button button-small wpat-seo-single-fill-btn" data-post-id="' + row.id + '" style="background: #10b981; border-color: #059669; color: #fff; font-weight: 600; padding: 0 8px; height: 26px; line-height: 24px; font-size: 11px; margin: 0 auto; display: block; cursor: pointer;">Auto-rellenar</button>';
										} else {
											actionButton = '<div style="text-align: center; color: #10b981; font-weight: 700; font-size: 11.5px;">✓ Completo</div>';
										}

										var rowHTML = '<tr class="wpat-seo-audit-row" ' +
											'data-title="' + row.title.toLowerCase() + '" ' +
											'data-issues="' + (hasIssues ? '1' : '0') + '" ' +
											'data-no-keyword="' + (hasNoKeyword ? '1' : '0') + '" ' +
											'data-optimized="' + (isOptimized ? '1' : '0') + '">' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9;">' + editLink + '<div style="font-size:11px; color:#64748b; margin-top:2px;">Tipo: ' + row.type + '</div></td>' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9; vertical-align:middle;">' + indexableBadge + '</td>' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9; vertical-align:middle;">' + keywordBadge + '</td>' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9; vertical-align:middle;">' + titleBadge + '</td>' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9; vertical-align:middle;">' + descBadge + '</td>' +
											'<td style="padding:10px; border-bottom: 1px solid #f1f5f9; vertical-align:middle; text-align:center;">' + actionButton + '</td>' +
											'</tr>';
										
										$tableBody.append(rowHTML);
									});

									$resultsWrapper.show();
									
									processed += currentBatch.length;
									var percent = Math.round((processed / total) * 100);
									$progressBar.css('width', percent + '%');
									$progressPercent.text(percent + '%');
									
									currentBatchIndex++;
									processNextBatch();
								} else {
									alert('Error al escanear lote de páginas.');
									resetScanBtn();
								}
							},
							error: function() {
								alert('Error de conexión al analizar lote de páginas.');
								resetScanBtn();
							}
						});
					}

					processNextBatch();
				} else {
					$btn.prop('disabled', false).text('Escanear Sitio Ahora');
					$status.text('No se encontraron páginas públicas para analizar.');
					$progressWrapper.slideUp(200);
				}
			},
			error: function() {
				alert('Error de conexión al obtener páginas del sitio.');
				resetScanBtn();
			}
		});

		function resetScanBtn() {
			$btn.prop('disabled', false).text('Escanear Sitio Ahora');
			$status.text('Análisis interrumpido por un error.');
			$progressWrapper.slideUp(200);
		}
	});

	// Lógica de filtrado y paginación de la tabla de auditoría SEO
	var seoAuditCurrentPage = 1;
	var seoAuditPageSize = 15; // Mostrar 15 registros por página

	function updateSeoTableCounter() {
		var total = $('.wpat-seo-audit-row').length;
		var visible = $('.wpat-seo-audit-row:visible').length;
		$('#wpat_seo_total_count').text(total);
		$('#wpat_seo_filtered_count').text(visible);
	}

	function applySeoTableFilters() {
		var searchQuery = $('#wpat_seo_table_search').val().trim().toLowerCase();
		var statusFilter = $('#wpat_seo_table_status_filter').val();
		var $matchingRows = $();

		$('.wpat-seo-audit-row').each(function() {
			var $row = $(this);
			var title = $row.attr('data-title') || '';
			var matchesSearch = (title.indexOf(searchQuery) !== -1);
			var matchesStatus = false;

			if (statusFilter === 'all') {
				matchesStatus = true;
			} else if (statusFilter === 'issues') {
				matchesStatus = ($row.attr('data-issues') === '1');
			} else if (statusFilter === 'no-keyword') {
				matchesStatus = ($row.attr('data-no-keyword') === '1');
			} else if (statusFilter === 'optimized') {
				matchesStatus = ($row.attr('data-optimized') === '1');
			}

			if (matchesSearch && matchesStatus) {
				$matchingRows = $matchingRows.add($row);
			} else {
				$row.hide();
			}
		});

		var totalMatching = $matchingRows.length;
		var totalPages = Math.max(1, Math.ceil(totalMatching / seoAuditPageSize));

		// Forzar límites de página
		if (seoAuditCurrentPage > totalPages) {
			seoAuditCurrentPage = totalPages;
		}
		if (seoAuditCurrentPage < 1) {
			seoAuditCurrentPage = 1;
		}

		var startIndex = (seoAuditCurrentPage - 1) * seoAuditPageSize;
		var endIndex = startIndex + seoAuditPageSize;

		// Mostrar solo los elementos de la página actual
		$matchingRows.each(function(index) {
			if (index >= startIndex && index < endIndex) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});

		// Actualizar estado de botones y números en la UI
		$('#wpat_seo_audit_page_num').text(seoAuditCurrentPage);
		$('#wpat_seo_audit_total_pages').text(totalPages);
		if (!$('#wpat_seo_audit_goto_page').is(':focus')) {
			$('#wpat_seo_audit_goto_page').attr('max', totalPages).val(seoAuditCurrentPage);
		}

		$('#wpat_seo_audit_prev_btn').prop('disabled', seoAuditCurrentPage <= 1);
		$('#wpat_seo_audit_next_btn').prop('disabled', seoAuditCurrentPage >= totalPages);

		updateSeoTableCounter();
	}

	$(document).on('input', '#wpat_seo_table_search', function() {
		seoAuditCurrentPage = 1;
		applySeoTableFilters();
	});

	$(document).on('change', '#wpat_seo_table_status_filter', function() {
		seoAuditCurrentPage = 1;
		applySeoTableFilters();
	});

	// Botones de navegación de la paginación
	$(document).on('click', '#wpat_seo_audit_prev_btn', function(e) {
		e.preventDefault();
		if (seoAuditCurrentPage > 1) {
			seoAuditCurrentPage--;
			applySeoTableFilters();
		}
	});

	$(document).on('click', '#wpat_seo_audit_next_btn', function(e) {
		e.preventDefault();
		var totalPages = parseInt($('#wpat_seo_audit_total_pages').text(), 10) || 1;
		if (seoAuditCurrentPage < totalPages) {
			seoAuditCurrentPage++;
			applySeoTableFilters();
		}
	});

	// Salto directo de página en la paginación SEO Audit
	$(document).on('input change', '#wpat_seo_audit_goto_page', function(e) {
		var totalPages = parseInt($('#wpat_seo_audit_total_pages').text(), 10) || 1;
		var rawVal = $(this).val();
		if (rawVal === '') {
			return; // Permitir borrar temporalmente el valor para escribir
		}
		var page = parseInt(rawVal, 10);
		if (isNaN(page)) {
			return;
		}
		if (page < 1) {
			page = 1;
		}
		if (page > totalPages) {
			page = totalPages;
		}
		if (seoAuditCurrentPage !== page) {
			seoAuditCurrentPage = page;
			applySeoTableFilters();
		}
	});

	// === 7. PESTAÑA DE HERRAMIENTAS Y MANTENIMIENTO ===
	// Toggle de checkboxes del exportador
	$(document).on('change', '#wpat_export_all_checkbox', function() {
		if ($(this).is(':checked')) {
			$('#wpat_export_types_wrapper').slideUp(200);
		} else {
			$('#wpat_export_types_wrapper').slideDown(200).css('display', 'flex');
		}
	});

	// Selector de Formato de Exportación (JSON vs CSV)
	$(document).on('change', '#wpat_export_format_selector', function() {
		var format = $(this).val();
		if (format === 'csv') {
			$('#wpat_export_json_options').hide();
			$('#wpat_export_json_submit_btn').hide();
			$('#wpat_export_csv_options').slideDown(200);
			$('#wpat_csv_export_btn').show();
		} else {
			$('#wpat_export_csv_options').hide();
			$('#wpat_csv_export_btn').hide();
			$('#wpat_export_json_options').slideDown(200);
			$('#wpat_export_json_submit_btn').show();
		}
	});

	// Trigger selector de archivo de importación
	$(document).on('click', '#wpat_select_import_file_btn', function(e) {
		e.preventDefault();
		$('#wpat_import_file_field').trigger('click');
	});

	// Auto-detección inteligente de formato al seleccionar un archivo (.json o .csv)
	$(document).on('change', '#wpat_import_file_field', function() {
		var file = this.files[0];
		if (file) {
			var name = file.name;
			var ext = name.split('.').pop().toLowerCase();
			$('#wpat_import_feedback_name').text(name);
			$('#wpat_import_file_feedback').slideDown(200);

			if (ext === 'csv') {
				$('#wpat_import_file_label').text('Archivo CSV listo (Excel)');
				$('#wpat_import_contents_submit_btn').hide().prop('disabled', true);
				$('#wpat_import_csv_options').slideDown(200);
				$('#wpat_csv_start_import_btn').show().prop('disabled', true).text('Analizando CSV...');

				var reader = new FileReader();
				reader.onload = function(evt) {
					var text = evt.target.result;
					csvParsedRows = parseCSV(text);
					if (csvParsedRows.length > 0) {
						$('#wpat_csv_start_import_btn').prop('disabled', false).text('Iniciar Importación CSV (' + csvParsedRows.length + ' entradas)');
					} else {
						alert('El archivo CSV está vacío o no tiene un formato válido.');
						$('#wpat_csv_start_import_btn').prop('disabled', true).text('Iniciar Importación CSV');
					}
				};
				reader.readAsText(file);
			} else {
				// Es un archivo JSON (Backup/Migración)
				$('#wpat_import_file_label').text('Archivo JSON listo (Backup/Migración)');
				$('#wpat_import_csv_options').slideUp(200);
				$('#wpat_csv_start_import_btn').hide().prop('disabled', true);
				$('#wpat_import_contents_submit_btn').show().prop('disabled', false);
			}
		} else {
			$('#wpat_import_feedback_name').text('ninguno');
			$('#wpat_import_file_feedback').slideUp(200);
			$('#wpat_import_csv_options').slideUp(200);
			$('#wpat_import_contents_submit_btn').show().prop('disabled', true);
			$('#wpat_csv_start_import_btn').hide().prop('disabled', true);
			$('#wpat_import_file_label').text('Selecciona tu archivo (.json o .csv)');
		}
	});

	// 7. Generador SEO en Masa (Auto-rellenado)
	$('#wpat_seo_bulk_fill_btn').on('click', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $status = $('#wpat_seo_bulk_status');
		var $progressWrapper = $('#wpat_seo_bulk_progress');
		var $progressBar = $('#wpat_seo_bulk_progress_bar');
		var $progressPercent = $('#wpat_seo_bulk_progress_percent');
		var $progressLabel = $('#wpat_seo_bulk_progress_label');

		var postTypeFilter = $('#wpat_seo_bulk_post_type').val() || 'all';

		if (!confirm('¿Estás seguro de que deseas auto-rellenar los campos SEO vacíos? Esto escribirá en la base de datos títulos y descripciones por defecto para todos los contenidos que no los tengan configurados.')) {
			return;
		}

		$btn.prop('disabled', true).text('Procesando...');
		$status.text('Buscando contenidos sin SEO...');
		$progressWrapper.slideDown(200);
		$progressBar.css('width', '0%').css('background', '#10b981');
		$progressPercent.text('0%');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_seo_get_posts_to_fill',
				post_type_filter: postTypeFilter
			},
			success: function(response) {
				if (response.success && response.data.ids && response.data.ids.length > 0) {
					var ids = response.data.ids;
					var total = ids.length;
					var processed = 0;
					var batchSize = 25; // Procesamos 25 a la vez para máxima velocidad
					var batches = [];

					for (var i = 0; i < ids.length; i += batchSize) {
						batches.push(ids.slice(i, i + batchSize));
					}

					var currentBatchIndex = 0;

					function processNextBatch() {
						if (currentBatchIndex >= batches.length) {
							$btn.prop('disabled', false).text('Auto-rellenar Campos Vacíos');
							$status.text('¡Optimización en masa completada!');
							$progressLabel.text('Se han optimizado ' + total + ' contenidos.');
							$progressBar.css('width', '100%');
							$progressPercent.text('100%');

							alert('Se han auto-rellenado con éxito los campos SEO de ' + total + ' elementos. Se recomienda ejecutar la Auditoría SEO de nuevo para ver los nuevos resultados.');
							return;
						}

						var currentBatch = batches[currentBatchIndex];
						$progressLabel.text('Procesando lote ' + (currentBatchIndex + 1) + ' de ' + batches.length + '...');

						$.ajax({
							url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
							type: 'POST',
							data: {
								action: 'wpat_seo_fill_posts_batch',
								post_ids: currentBatch
							},
							success: function(res) {
								if (res.success) {
									processed += currentBatch.length;
									var pct = Math.round((processed / total) * 100);
									$progressBar.css('width', pct + '%');
									$progressPercent.text(pct + '%');
									$status.text('Optimizados ' + processed + ' de ' + total + '...');
									
									currentBatchIndex++;
									processNextBatch();
								} else {
									$btn.prop('disabled', false).text('Auto-rellenar Campos Vacíos');
									$status.text('Error al procesar lote.');
								}
							},
							error: function() {
								$btn.prop('disabled', false).text('Auto-rellenar Campos Vacíos');
								$status.text('Error de conexión.');
							}
						});
					}

					processNextBatch();
				} else {
					$btn.prop('disabled', false).text('Auto-rellenar Campos Vacíos');
					$status.text('¡No hay contenidos vacíos para optimizar!');
					$progressWrapper.slideUp(200);
					alert('¡Todos los contenidos ya tienen campos SEO configurados en el tipo seleccionado!');
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Auto-rellenar Campos Vacíos');
				$status.text('Error de conexión.');
			}
		});
	});

	// Auto-relleno individual de campos SEO vacíos en la Auditoría
	$(document).on('click', '.wpat-seo-single-fill-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var postId = $btn.data('post-id');
		var $row = $btn.closest('tr');

		$btn.prop('disabled', true).text('Procesando...');

		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_seo_fill_posts_batch',
				post_ids: [postId]
			},
			success: function(res) {
				if (res.success) {
					// Obtener los datos actualizados del post para refrescar la fila en caliente
					$.ajax({
						url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
						type: 'POST',
						data: {
							action: 'wpat_seo_audit_page',
							post_ids: [postId]
						},
						success: function(auditRes) {
							if (auditRes.success && auditRes.data.results && auditRes.data.results.length > 0) {
								var updatedRow = auditRes.data.results[0];
								
								// Volver a calcular badges y estados
								var indexableBadge = updatedRow.indexable === 'index' 
									? '<span style="color:#047857; background:#d1fae5; padding:3px 8px; border-radius:12px; font-weight:700; font-size:11px;">🟢 Index</span>'
									: '<span style="color:#4b5563; background:#e5e7eb; padding:3px 8px; border-radius:12px; font-weight:700; font-size:11px;">⚪ noindex</span>';
								
								var keywordBadge = updatedRow.keyword 
									? '<span style="color:#1e293b; background:#f1f5f9; padding:4px 8px; border-radius:4px; font-size:12px; font-weight:600; display:inline-block; border:1px solid #cbd5e1;">' + updatedRow.keyword + '</span>'
									: '<span style="color:#b91c1c; font-weight:700; font-size:11px; background:#fee2e2; padding:2px 6px; border-radius:4px;">🔴 Vacío</span>';

								var titleBadge = '';
								if (updatedRow.title_status === 'empty') {
									titleBadge = '<span style="color:#b91c1c; font-weight:700; font-size:12px;">🔴 Vacío</span>';
								} else if (updatedRow.title_status === 'correct') {
									titleBadge = '<span style="color:#047857; font-weight:700; font-size:12px;">🟢 ' + updatedRow.title_length + ' carac.</span>';
								} else {
									titleBadge = '<span style="color:#b45309; font-weight:700; font-size:12px;">🟡 ' + updatedRow.title_length + ' carac. (Ajustar)</span>';
								}

								var descBadge = '';
								if (updatedRow.desc_status === 'empty') {
									descBadge = '<span style="color:#b91c1c; font-weight:700; font-size:12px;">🔴 Vacío</span>';
								} else if (updatedRow.desc_status === 'correct') {
									descBadge = '<span style="color:#047857; font-weight:700; font-size:12px;">🟢 ' + updatedRow.desc_length + ' carac.</span>';
								} else {
									descBadge = '<span style="color:#b45309; font-weight:700; font-size:12px;">🟡 ' + updatedRow.desc_length + ' carac. (Ajustar)</span>';
								}

								var hasIssues = (updatedRow.title_status !== 'correct' || updatedRow.desc_status !== 'correct' || updatedRow.title_status === 'empty' || updatedRow.desc_status === 'empty');
								var hasNoKeyword = (!updatedRow.keyword);
								var isOptimized = (updatedRow.title_status === 'correct' && updatedRow.desc_status === 'correct' && updatedRow.keyword);

								// Actualizar los atributos data de la fila para los filtros
								$row.attr('data-issues', hasIssues ? '1' : '0');
								$row.attr('data-no-keyword', hasNoKeyword ? '1' : '0');
								$row.attr('data-optimized', isOptimized ? '1' : '0');

								// Actualizar celdas específicas en caliente
								$row.find('td:eq(1)').html(indexableBadge);
								$row.find('td:eq(2)').html(keywordBadge);
								$row.find('td:eq(3)').html(titleBadge);
								$row.find('td:eq(4)').html(descBadge);

								// Actualizar celda de acciones
								var updatedActionButton = '';
								if (updatedRow.title_status === 'empty' || updatedRow.desc_status === 'empty') {
									updatedActionButton = '<button type="button" class="button button-small wpat-seo-single-fill-btn" data-post-id="' + updatedRow.id + '" style="background: #10b981; border-color: #059669; color: #fff; font-weight: 600; padding: 0 8px; height: 26px; line-height: 24px; font-size: 11px; margin: 0 auto; display: block; cursor: pointer;">Auto-rellenar</button>';
								} else {
									updatedActionButton = '<div style="text-align: center; color: #10b981; font-weight: 700; font-size: 11.5px;">✓ Completo</div>';
								}
								$row.find('td:eq(5)').html(updatedActionButton);
								
								// Efecto de flash verde de éxito
								$row.css('background-color', '#d1fae5');
								setTimeout(function() {
									$row.css('background-color', '');
								}, 800);
							}
						}
					});
				} else {
					$btn.prop('disabled', false).text('Auto-rellenar');
					alert('Error al auto-rellenar: ' + (res.data.message || 'Desconocido'));
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Auto-rellenar');
				alert('Error de conexión.');
			}
		});
	});

	// 8. Comprobación de actualización por AJAX (sin recarga de página)
	$(document).on('click', '#wpat_force_update_check_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $statusText = $('#wpat_updater_widget_status');
		var $actionContainer = $('#wpat_updater_widget_action');
		
		$btn.prop('disabled', true).text('Comprobando...');
		
		$.ajax({
			url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
			type: 'POST',
			data: {
				action: 'wpat_force_update_check'
			},
			success: function(response) {
				if (response.success) {
					var data = response.data;
					if (data.has_update) {
						$statusText.html(
							'Versión actual: <strong>v' + data.current_version + '</strong><br>' +
							'Última versión: <strong style="color: #ea580c;">v' + data.new_version + '</strong>'
						);
						$actionContainer.html(
							'<a href="' + data.update_url + '" class="button button-primary" style="width: 100%; text-align: center; background: #ea580c; border-color: #d97706; font-weight: 700; height: 28px; line-height: 26px; display: block; box-sizing: border-box;">' +
								'Actualizar ahora' +
							'</a>'
						);
					} else {
						$statusText.html(
							'Versión actual: <strong>v' + data.current_version + '</strong><br>' +
							'Estado: <span style="color: #10b981; font-weight: 600;">Actualizado 🟢</span>'
						);
						$btn.prop('disabled', false).text('Comprobar de nuevo');
						
						alert('¡Tu plugin WP Agency Toolkit ya está actualizado a la última versión disponible (v' + data.current_version + ')!');
					}
				}
			},
			error: function() {
				$btn.prop('disabled', false).text('Comprobar de nuevo');
				alert('Error de conexión con el servidor.');
			}
		});
	});

	/* ==========================================================================
	   IMPORTADOR Y EXPORTADOR DE ENTRADAS EN CSV (EXCEL)
	/* ==========================================================================
	   27. EXPORTACIÓN E IMPORTACIÓN MASIVA (CSV & JSON)
	   ========================================================================== */
	$(document).on('click', '#wpat_csv_export_btn', function(e) {
		e.preventDefault();
		var postType   = $('#wpat_csv_export_post_type').val() || 'post';
		var status     = $('#wpat_csv_export_status').val() || 'any';
		var formatType = $('#wpat_export_format_type').val() || 'csv';
		var ajaxTarget = (typeof ajaxurl !== 'undefined' && ajaxurl) ? ajaxurl : ((typeof wpat_object !== 'undefined') ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php');
		
		var actionName = (formatType === 'json') ? 'wpat_json_export_posts' : 'wpat_csv_export_posts';
		window.location.href = ajaxTarget + '?action=' + actionName + '&post_type=' + postType + '&post_status=' + status;
	});

	var csvParsedRows = [];

	$(document).on('click', '#wpat_csv_select_file_btn', function(e) {
		e.preventDefault();
		$('#wpat_csv_file_input').trigger('click');
	});

	$(document).on('change', '#wpat_csv_file_input', function(e) {
		var file = e.target.files[0];
		if (!file) return;

		$('#wpat_csv_file_name').text('📄 ' + file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)').show();

		var reader = new FileReader();
		reader.onload = function(evt) {
			var text = evt.target.result;
			csvParsedRows = [];

			// Detectar si es archivo JSON o CSV
			var isJSON = file.name.toLowerCase().endsWith('.json') || text.trim().startsWith('[') || text.trim().startsWith('{');

			if (isJSON) {
				try {
					var parsed = JSON.parse(text);
					if (Array.isArray(parsed)) {
						csvParsedRows = parsed;
					} else if (parsed && typeof parsed === 'object') {
						csvParsedRows = [parsed];
					}
				} catch (err) {
					alert('El archivo JSON contiene errores de sintaxis y no pudo ser interpretado.');
				}
			} else {
				csvParsedRows = parseCSV(text);
			}

			if (csvParsedRows.length > 0) {
				$('#wpat_csv_start_import_btn').prop('disabled', false).html('<span class="dashicons dashicons-update" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px;"></span> Iniciar Importación (' + csvParsedRows.length + ' elementos)');
			} else {
				alert('El archivo está vacío o no tiene un formato compatible.');
				$('#wpat_csv_start_import_btn').prop('disabled', true).html('<span class="dashicons dashicons-update" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px;"></span> Iniciar Importación');
			}
		};
		reader.readAsText(file);
	});

	function parseCSV(text) {
		if (text.charCodeAt(0) === 0xFEFF) {
			text = text.substr(1);
		}
		var lines = text.split(/\r\n|\n|\r/);
		if (lines.length < 2) return [];

		var delimiter = ';';
		if (lines[0].indexOf(';') === -1 && lines[0].indexOf(',') !== -1) {
			delimiter = ',';
		}

		var headers = parseCSVLine(lines[0], delimiter);
		var cleanHeaders = headers.map(function(h) {
			return h.trim().toLowerCase().replace(/^["']|["']$/g, '');
		});

		var results = [];
		for (var i = 1; i < lines.length; i++) {
			if (!lines[i].trim()) continue;
			var row = parseCSVLine(lines[i], delimiter);
			var obj = {};
			for (var j = 0; j < cleanHeaders.length; j++) {
				obj[cleanHeaders[j]] = row[j] ? row[j].trim() : '';
			}
			results.push(obj);
		}
		return results;
	}

	function parseCSVLine(text, delimiter) {
		var pattern = new RegExp(
			'(\\' + delimiter + '|\\r?\\n|\\r|^)' +
			'(?:"([^"]*(?:""[^"]*)*)"|([^"\\' + delimiter + '\\r\\n]*))',
			'gi'
		);
		var result = [];
		var matches = null;
		while (matches = pattern.exec(text)) {
			var matchedDelimiter = matches[1];
			if (matchedDelimiter.length && matchedDelimiter !== delimiter) {
				break;
			}
			var matchedValue;
			if (matches[2]) {
				matchedValue = matches[2].replace(new RegExp('""', 'g'), '"');
			} else {
				matchedValue = matches[3];
			}
			result.push(matchedValue);
		}
		return result;
	}

	$(document).on('click', '#wpat_csv_start_import_btn', function(e) {
		e.preventDefault();
		if (!csvParsedRows || !csvParsedRows.length) return;

		var $btn = $(this);
		$btn.prop('disabled', true).text('Importando elementos...');

		var $progressWrapper = $('#wpat_csv_progress_wrapper').slideDown(200);
		var $progressLabel = $('#wpat_csv_progress_label');
		var $progressPercent = $('#wpat_csv_progress_percent');
		var $progressBar = $('#wpat_csv_progress_bar');

		var targetPostType = $('#wpat_csv_import_post_type').val() || 'post';
		var strategy       = $('#wpat_csv_import_strategy').val() || 'update';
		var totalRows      = csvParsedRows.length;
		var batchSize      = 10;
		var currentIndex   = 0;
		var totalImported  = 0;
		var totalUpdated   = 0;
		var totalSkipped   = 0;

		function processNextBatch() {
			if (currentIndex >= totalRows) {
				var summaryMsg = '<span style="color:#10b981; font-weight:700;">✓ ¡Importación completada con éxito!</span> ' +
					'(' + totalImported + ' creadas, ' + totalUpdated + ' actualizadas' + (totalSkipped > 0 ? ', ' + totalSkipped + ' omitidas' : '') + ').';
				$progressLabel.html(summaryMsg);
				$progressPercent.text('100%');
				$progressBar.css('width', '100%');
				$btn.text('Importación Finalizada').prop('disabled', false);
				return;
			}

			var chunk = csvParsedRows.slice(currentIndex, currentIndex + batchSize);
			var percent = Math.round((currentIndex / totalRows) * 100);

			$progressLabel.text('Procesando ' + (currentIndex + 1) + ' a ' + Math.min(currentIndex + batchSize, totalRows) + ' de ' + totalRows + '...');
			$progressPercent.text(percent + '%');
			$progressBar.css('width', percent + '%');

			var ajaxTarget = (typeof ajaxurl !== 'undefined' && ajaxurl) ? ajaxurl : ((typeof wpat_object !== 'undefined') ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php');

			$.ajax({
				url: ajaxTarget,
				type: 'POST',
				data: {
					action: 'wpat_csv_import_batch',
					target_post_type: targetPostType,
					strategy: strategy,
					rows: chunk
				},
				success: function(response) {
					if (response.success) {
						totalImported += response.data.imported || 0;
						totalUpdated  += response.data.updated || 0;
						totalSkipped  += response.data.skipped || 0;
						currentIndex  += batchSize;
						processNextBatch();
					} else {
						alert('Error durante la importación: ' + (response.data ? response.data.message : 'Error desconocido'));
						$btn.prop('disabled', false).text('Reintentar Importación');
					}
				},
				error: function() {
					alert('Fallo de conexión al importar el lote.');
					$btn.prop('disabled', false).text('Reintentar Importación');
				}
			});
		}

		processNextBatch();
	});

	// 28. Buscador AJAX en vivo de Productos (Campos Extras WooCommerce)
	var productSearchTimeout = null;

	$(document).on('input', '.wpat-product-search-input', function() {
		var $input = $(this);
		var term = $input.val().trim();
		var $wrap = $input.closest('.wpat-scope-product-wrap');
		var $results = $wrap.find('.wpat-product-search-results');

		clearTimeout(productSearchTimeout);

		if (term.length < 2) {
			$results.hide().empty();
			return;
		}

		productSearchTimeout = setTimeout(function() {
			$results.html('<div style="padding: 6px 10px; color: #64748b;">Buscando...</div>').show();

			var nonce = $('#wpat_settings_nonce').val();

			$.ajax({
				url: (typeof ajaxurl !== 'undefined' && ajaxurl ? ajaxurl : (typeof wpat_object !== 'undefined' ? wpat_object.ajax_url : '/wp-admin/admin-ajax.php')),
				type: 'GET',
				data: {
					action: 'wpat_search_products',
					term: term,
					nonce: nonce
				},
				success: function(response) {
					if (response.success && response.data.length > 0) {
						var html = '';
						$.each(response.data, function(i, item) {
							var safeTitle = $('<div>').text(item.title).html();
							html += '<div class="wpat-product-search-item" data-id="' + item.id + '" data-title="' + safeTitle + '" style="padding: 6px 10px; cursor: pointer; border-bottom: 1px solid #f1f5f9; transition: background 0.15s;">' + safeTitle + '</div>';
						});
						$results.html(html).show();
					} else {
						$results.html('<div style="padding: 6px 10px; color: #94a3b8;">No se encontraron productos</div>').show();
					}
				},
				error: function() {
					$results.html('<div style="padding: 6px 10px; color: #ef4444;">Error al buscar</div>').show();
				}
			});
		}, 300);
	});

	$(document).on('mouseenter', '.wpat-product-search-item', function() {
		$(this).css('background', '#f1f5f9');
	}).on('mouseleave', '.wpat-product-search-item', function() {
		$(this).css('background', '#ffffff');
	});

	$(document).on('click', '.wpat-product-search-item', function() {
		var $item = $(this);
		var id = String($item.data('id'));
		var title = $item.data('title');
		var $wrap = $item.closest('.wpat-scope-product-wrap');
		var $hidden = $wrap.find('.wpat-products-hidden-ids');
		var $tags = $wrap.find('.wpat-selected-products-tags');
		var $input = $wrap.find('.wpat-product-search-input');
		var $results = $wrap.find('.wpat-product-search-results');

		var currentIds = $hidden.val() ? $hidden.val().split(',').map(function(s) { return s.trim(); }).filter(Boolean) : [];

		if (currentIds.indexOf(id) === -1) {
			currentIds.push(id);
			$hidden.val(currentIds.join(', '));

			var tagHtml = '<span class="wpat-product-tag" data-id="' + id + '" style="background: #e2e8f0; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 6px; font-size: 11px; display: inline-flex; align-items: center; gap: 6px;">' +
				title + ' <a href="#" class="wpat-remove-product-tag" style="color: #ef4444; text-decoration: none; font-weight: bold;">&times;</a></span>';
			$tags.append(tagHtml);
		}

		$input.val('');
		$results.hide().empty();
	});

	$(document).on('click', '.wpat-remove-product-tag', function(e) {
		e.preventDefault();
		var $tag = $(this).closest('.wpat-product-tag');
		var id = String($tag.data('id'));
		var $wrap = $tag.closest('.wpat-scope-product-wrap');
		var $hidden = $wrap.find('.wpat-products-hidden-ids');

		var currentIds = $hidden.val() ? $hidden.val().split(',').map(function(s) { return s.trim(); }).filter(Boolean) : [];
		currentIds = currentIds.filter(function(item) { return item !== id; });

		$hidden.val(currentIds.join(', '));
		$tag.remove();
	});

	$(document).on('click', function(e) {
		if (!$(e.target).closest('.wpat-scope-product-wrap').length) {
			$('.wpat-product-search-results').hide();
		}
	});

	// --- GESTIÓN CSV DE AUTOCOMPLETADO MULTI-PAÍS ---
	$(document).on('click', '#wpat_autofill_import_btn', function(e) {
		e.preventDefault();
		var $fileInput = $('#wpat_autofill_csv_input');
		var $msg = $('#wpat_autofill_import_msg');
		var files = $fileInput[0].files;

		if (!files || !files.length) {
			$msg.css('color', '#ef4444').text('Por favor, selecciona un archivo CSV antes de importar.');
			return;
		}

		var formData = new FormData();
		formData.append('action', 'wpat_autofill_import_csv');
		formData.append('security', wpat_object.nonce);
		formData.append('csv_file', files[0]);

		$msg.css('color', '#2563eb').text('Procesando e importando archivo CSV...');

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: formData,
			contentType: false,
			processData: false,
			success: function(response) {
				if (response.success) {
					$msg.css('color', '#10b981').text(response.data.message);
					showToast('Importación realizada con éxito', false);
					setTimeout(function() {
						location.reload();
					}, 1500);
				} else {
					$msg.css('color', '#ef4444').text('Error: ' + response.data.message);
					showToast('Error en la importación', true);
				}
			},
			error: function() {
				$msg.css('color', '#ef4444').text('Error del servidor al procesar la importación.');
				showToast('Error del servidor', true);
			}
		});
	});

	$(document).on('change', '.wpat-autofill-country-toggle', function() {
		var $checkbox = $(this);
		var country = $checkbox.data('country');
		var status = $checkbox.is(':checked') ? '1' : '0';

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_autofill_toggle_country',
				security: wpat_object.nonce,
				country: country,
				status: status
			},
			success: function(response) {
				if (response.success) {
					showToast('Estado del país actualizado', false);
				} else {
					showToast('Error al cambiar estado', true);
				}
			}
		});
	});

	$(document).on('click', '.wpat-autofill-delete-country-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var country = $btn.data('country');

		if (!confirm('¿Estás seguro de que deseas eliminar la configuración del país (' + country + ')?')) {
			return;
		}

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_autofill_delete_country',
				security: wpat_object.nonce,
				country: country
			},
			success: function(response) {
				if (response.success) {
					showToast('País eliminado', 'deactivate');
					$btn.closest('tr').fadeOut(300, function() {
						$(this).remove();
					});
				} else {
					showToast(response.data.message, true);
				}
			}
		});
	});

	// ==========================================
	// DISEÑADOR DE PLANTILLAS DE EMAIL WOOCOMMERCE
	// ==========================================
	var lastActiveEmailField = null;

	$(document).on('focus', '.wpat-email-input-field', function() {
		lastActiveEmailField = this;
	});

	// Inserción de etiquetas dinámicas al pulsar las píldoras
	$(document).on('click', '.wpat-tag-pill-btn', function(e) {
		e.preventDefault();
		var tag = $(this).data('tag');
		if (!tag) return;

		var targetField = lastActiveEmailField || $('#wpat_email_field_welcome')[0] || $('#wpat_email_field_intro')[0];
		if (targetField) {
			var $tf = $(targetField);
			var val = $tf.val() || '';
			var start = targetField.selectionStart !== undefined ? targetField.selectionStart : val.length;
			var end = targetField.selectionEnd !== undefined ? targetField.selectionEnd : val.length;
			var newVal = val.substring(0, start) + tag + val.substring(end);
			$tf.val(newVal).trigger('input');
			targetField.focus();
			if (targetField.setSelectionRange) {
				targetField.setSelectionRange(start + tag.length, start + tag.length);
			}
		}
	});

	// Sincronización del almacenamiento oculto per-template y rastreo de campo activo
	var getActiveEmailType = function() {
		return $('#wpat_email_type_selector').val() || 'customer_processing_order';
	};

	var $lastFocusedEmailField = $('#wpat_email_field_intro');

	$(document).on('focus', '.wpat-email-input-field', function() {
		$lastFocusedEmailField = $(this);
	});

	// Inserción de etiquetas dinámicas clicables
	$(document).on('click', '.wpat-tag-pill-btn', function(e) {
		e.preventDefault();
		var tag = $(this).data('tag');
		if (!tag) return;

		var $target = ($lastFocusedEmailField && $lastFocusedEmailField.length && $lastFocusedEmailField.is(':visible')) ? $lastFocusedEmailField : $('#wpat_email_field_intro');
		if (!$target.length) return;

		var el = $target[0];
		if (document.selection) {
			el.focus();
			var sel = document.selection.createRange();
			sel.text = tag;
		} else if (el.selectionStart || el.selectionStart === 0) {
			var startPos = el.selectionStart;
			var endPos = el.selectionEnd;
			var currentVal = $target.val();
			$target.val(currentVal.substring(0, startPos) + tag + currentVal.substring(endPos, currentVal.length));
			el.selectionStart = startPos + tag.length;
			el.selectionEnd = startPos + tag.length;
		} else {
			$target.val($target.val() + ' ' + tag);
		}

		$target.focus().trigger('input').trigger('change');
		showToast('Etiqueta ' + tag + ' insertada', false);
	});

	$(document).on('input keyup change', '.wpat-email-input-field', function() {
		var $field = $(this);
		var fieldId = $field.attr('id');
		var currentType = getActiveEmailType();
		var storeField = '';

		if (fieldId === 'wpat_email_field_welcome') storeField = 'welcome';
		else if (fieldId === 'wpat_email_field_intro') storeField = 'intro';
		else if (fieldId === 'wpat_email_field_promo') storeField = 'promo';
		else if (fieldId === 'wpat_email_field_footer') storeField = 'footer';

		if (storeField) {
			$('#wpat_store_' + storeField + '_' + currentType).val($field.val());
		}
	});

	// Cambio de tipo de plantilla en el desplegable
	$(document).on('change', '#wpat_email_type_selector', function() {
		var selectedType = $(this).val();

		// Cargar valores del tipo recién seleccionado
		var wVal = $('#wpat_store_welcome_' + selectedType).val() || '';
		var iVal = $('#wpat_store_intro_' + selectedType).val() || '';
		var pVal = $('#wpat_store_promo_' + selectedType).val() || '';
		var fVal = $('#wpat_store_footer_' + selectedType).val() || '';

		$('#wpat_email_field_welcome').val(wVal);
		$('#wpat_email_field_intro').val(iVal);
		$('#wpat_email_field_promo').val(pVal);
		$('#wpat_email_field_footer').val(fVal);

		// Actualizar los placeholders dinámicamente según la plantilla seleccionada
		var defaultsMap = {};
		try {
			var jsonText = $('#wpat_email_defaults_data').text();
			if (jsonText) defaultsMap = JSON.parse(jsonText);
		} catch(err) {}

		if (defaultsMap[selectedType]) {
			var defs = defaultsMap[selectedType];
			if (defs.welcome) $('#wpat_email_field_welcome').attr('placeholder', defs.welcome);
			if (defs.intro) $('#wpat_email_field_intro').attr('placeholder', defs.intro);
			if (defs.promo) $('#wpat_email_field_promo').attr('placeholder', defs.promo);
			if (defs.footer) $('#wpat_email_field_footer').attr('placeholder', defs.footer);
		}
	});

	// Botón Vista Previa en Vivo
	$(document).on('click', '#wpat_email_live_preview_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var origText = $btn.html();
		var emailType = getActiveEmailType();

		$btn.html('⏳ Generando vista previa...').prop('disabled', true);

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_get_email_preview_html',
				security: wpat_object.nonce,
				email_type: emailType
			},
			success: function(response) {
				$btn.html(origText).prop('disabled', false);
				if (response.success && response.data && response.data.html) {
					var $modal = $('#wpat_email_preview_modal');
					if (!$modal.length) {
						$modal = $('<div id="wpat_email_preview_modal" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.75); z-index:999999; display:flex; align-items:center; justify-content:center; padding:20px; box-sizing:border-box;">' +
							'<div style="background:#ffffff; width:100%; max-width:850px; height:90vh; border-radius:12px; display:flex; flex-direction:column; overflow:hidden; box-shadow:0 20px 25px -5px rgba(0,0,0,0.3);">' +
								'<div style="padding:16px 20px; background:#f8fafc; border-bottom:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center;">' +
									'<h3 style="margin:0; font-size:16px; font-weight:700; color:#0f172a;">👁️ Vista Previa en Vivo de Email</h3>' +
									'<button type="button" class="wpat-close-email-modal" style="background:none; border:none; font-size:22px; cursor:pointer; color:#64748b;">&times;</button>' +
								'</div>' +
								'<iframe id="wpat_email_preview_iframe" style="flex:1; width:100%; border:none;"></iframe>' +
							'</div>' +
						'</div>');
						$('body').append($modal);
					}
					var iframe = $modal.find('#wpat_email_preview_iframe')[0];
					$modal.fadeIn(200);
					var doc = iframe.contentWindow || iframe.contentDocument.document || iframe.contentDocument;
					if (doc.document) doc = doc.document;
					doc.open();
					doc.write(response.data.html);
					doc.close();
				} else {
					showToast('Error al generar la vista previa', true);
				}
			},
			error: function() {
				$btn.html(origText).prop('disabled', false);
				showToast('Error de conexión AJAX', true);
			}
		});
	});

	$(document).on('click', '.wpat-close-email-modal', function() {
		$('#wpat_email_preview_modal').fadeOut(200);
	});

	// Botón Enviar Email de Prueba
	$(document).on('click', '#wpat_send_test_email_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var origText = $btn.html();
		var recipient = $('#wpat_test_email_recipient').val();
		var emailType = getActiveEmailType();

		$btn.html('⏳ Enviando...').prop('disabled', true);

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_send_test_email',
				security: wpat_object.nonce,
				recipient: recipient,
				email_type: emailType
			},
			success: function(response) {
				$btn.html(origText).prop('disabled', false);
				if (response.success) {
					showToast(response.data.message, false);
				} else {
					showToast(response.data.message || 'Error al enviar el email de prueba', true);
				}
			},
			error: function() {
				$btn.html(origText).prop('disabled', false);
				showToast('Error de conexión AJAX al enviar', true);
			}
		});
	});

	// ==========================================
	// MÓDULO: VISOR Y MONITOR DE LOGS DE ERROR
	// ==========================================

	var logPollInterval = null;

	// 1. Cambio de subpestañas: Estructurada vs Bruto (Raw)
	$(document).on('click', '.wpat-log-tab-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var target = $btn.data('target');

		$('.wpat-log-tab-btn').removeClass('active').css({
			'color': '#64748b',
			'border-bottom-color': 'transparent'
		});
		$btn.addClass('active').css({
			'color': '#2563eb',
			'border-bottom-color': '#2563eb'
		});

		$('.wpat-log-tab-content').hide();
		$('#wpat_log_view_' + target).show();
	});

	// 2. Filtros combinados (Severidad + Búsqueda en tiempo real)
	function applyLogFilters() {
		var activeFilter = $('.wpat-log-filter-btn.active').data('filter') || 'all';
		var searchTerm = ($('#wpat_log_search').val() || '').toLowerCase().trim();
		var visibleCount = 0;

		$('.wpat-log-entry-row').each(function() {
			var $row = $(this);
			var rowSeverity = $row.data('severity') || '';
			var rowSearch = $row.data('search') || '';

			var matchesFilter = (activeFilter === 'all' || rowSeverity === activeFilter);
			var matchesSearch = (searchTerm === '' || rowSearch.indexOf(searchTerm) !== -1);

			if (matchesFilter && matchesSearch) {
				$row.show();
				visibleCount++;
			} else {
				$row.hide();
			}
		});

		// Manejar fila vacía por filtro
		if ($('.wpat-log-entry-row').length > 0) {
			if (visibleCount === 0) {
				if ($('#wpat_log_no_filter_match').length === 0) {
					$('#wpat_log_entries_tbody').append('<tr id="wpat_log_no_filter_match"><td colspan="5" style="text-align:center; padding:30px; color:#64748b;">No se encontraron registros que coincidan con los filtros seleccionados.</td></tr>');
				}
				$('#wpat_log_no_filter_match').show();
			} else {
				$('#wpat_log_no_filter_match').hide();
			}
		}
	}

	$(document).on('click', '.wpat-log-filter-btn', function(e) {
		e.preventDefault();
		$('.wpat-log-filter-btn').removeClass('active');
		$(this).addClass('active');
		applyLogFilters();
	});

	$(document).on('input', '#wpat_log_search', function() {
		applyLogFilters();
	});

	// 3. Desplegar / Colapsar Stack Trace
	$(document).on('click', '.wpat-toggle-trace-btn', function(e) {
		e.preventDefault();
		var targetId = $(this).data('target');
		$(targetId).slideToggle(150);
	});

	// 4. Copiar Snippet para wp-config.php
	$(document).on('click', '#wpat_copy_wp_config_snippet', function(e) {
		e.preventDefault();
		var snippet = $(this).data('snippet') || '';
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(snippet).then(function() {
				showToast('Código de wp-config.php copiado al portapapeles', false);
			});
		} else {
			var $temp = $('<textarea>');
			$('body').append($temp);
			$temp.val(snippet).select();
			document.execCommand('copy');
			$temp.remove();
			showToast('Código de wp-config.php copiado al portapapeles', false);
		}
	});

	// 5. Copiar Error Individual
	$(document).on('click', '.wpat-copy-single-error-btn', function(e) {
		e.preventDefault();
		var raw = $(this).data('raw') || '';
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(raw).then(function() {
				showToast('Error copiado al portapapeles', false);
			});
		} else {
			var $temp = $('<textarea>');
			$('body').append($temp);
			$temp.val(raw).select();
			document.execCommand('copy');
			$temp.remove();
			showToast('Error copiado al portapapeles', false);
		}
	});

	// 6. Copiar Último Error Registrado
	$(document).on('click', '#wpat_copy_last_error_btn', function(e) {
		e.preventDefault();
		var $firstBtn = $('.wpat-copy-single-error-btn').first();
		if ($firstBtn.length > 0) {
			$firstBtn.trigger('click');
		} else {
			showToast('No hay errores registrados para copiar', true);
		}
	});

	// 7. Copiar Todo en Bruto (Raw)
	$(document).on('click', '#wpat_copy_raw_log_btn', function(e) {
		e.preventDefault();
		var rawText = $('#wpat_log_raw_pre').text() || '';
		if (!rawText.trim()) {
			showToast('El log está vacío', true);
			return;
		}
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(rawText).then(function() {
				showToast('Log completo copiado al portapapeles', false);
			});
		} else {
			var $temp = $('<textarea>');
			$('body').append($temp);
			$temp.val(rawText).select();
			document.execCommand('copy');
			$temp.remove();
			showToast('Log completo copiado al portapapeles', false);
		}
	});

	// 8. Actualizar Logs vía AJAX (Live Fetch)
	function renderLogRows(entries) {
		var $tbody = $('#wpat_log_entries_tbody');
		$tbody.empty();

		if (!entries || entries.length === 0) {
			$tbody.html('<tr class="wpat-log-empty-row"><td colspan="5" style="text-align: center; padding: 40px 20px;"><div style="font-size: 38px; margin-bottom: 10px;">✨</div><strong style="font-size: 15px; color: #0f172a; display: block;">¡Excelente! No hay errores registrados</strong><p style="color: #64748b; font-size: 13px; margin: 4px 0 0 0;">El archivo <code>debug.log</code> está completamente limpio o no ha registrado incidentes.</p></td></tr>');
			return;
		}

		$.each(entries, function(idx, entry) {
			var traceBtn = '';
			var traceBox = '';
			if (entry.stack_trace && entry.stack_trace.trim() !== '') {
				traceBtn = '<button type="button" class="button button-small wpat-toggle-trace-btn" data-target="#wpat_trace_' + idx + '" title="Ver Stack Trace de ejecución" style="padding: 0 6px; height: 26px; line-height: 24px;"><span class="dashicons dashicons-arrow-down-alt2" style="font-size: 14px; width: 14px; height: 14px; line-height: 1;"></span> Stack</button>';
				traceBox = '<div class="wpat-log-trace-box" id="wpat_trace_' + idx + '" style="display: none; margin-top: 10px; background: #0f172a; color: #f8fafc; border-radius: 6px; padding: 12px; font-family: monospace; font-size: 11.5px; white-space: pre-wrap; line-height: 1.5; max-height: 250px; overflow-y: auto;">' + $('<div>').text(entry.stack_trace).html() + '</div>';
			}

			var fileHtml = '—';
			if (entry.file) {
				var lineBadge = entry.line ? '<span class="wpat-log-line-num" style="background: #e2e8f0; color: #0f172a; padding: 1px 5px; border-radius: 4px; font-weight: 700; margin-left: 4px;">:' + $('<div>').text(entry.line).html() + '</span>' : '';
				fileHtml = '<div style="font-family: monospace; font-size: 11.5px; color: #475569; word-break: break-all;" title="' + $('<div>').text(entry.file).html() + '">' + $('<div>').text(entry.file).html() + lineBadge + '</div>';
			}

			var rawCombined = (entry.raw_line || '') + (entry.stack_trace ? '\n' + entry.stack_trace : '');
			var searchStr = ((entry.message || '') + ' ' + (entry.file || '') + ' ' + (entry.line || '') + ' ' + (entry.severity || '')).toLowerCase();

			var rowHtml = '<tr class="wpat-log-entry-row severity-' + entry.badge_class + '" data-severity="' + entry.badge_class + '" data-search="' + $('<div>').text(searchStr).html() + '">' +
				'<td style="padding: 12px 14px; vertical-align: top;"><span class="wpat-severity-badge ' + entry.badge_class + '">' + $('<div>').text(entry.severity).html() + '</span></td>' +
				'<td style="padding: 12px 14px; vertical-align: top; white-space: nowrap;"><strong style="font-size: 12px; color: #1e293b; display: block;">' + $('<div>').text(entry.time_human).html() + '</strong><span style="font-size: 11px; color: #94a3b8;" title="' + $('<div>').text(entry.timestamp).html() + '">' + $('<div>').text(entry.timestamp).html() + '</span></td>' +
				'<td style="padding: 12px 14px; vertical-align: top;"><div class="wpat-log-msg-text" style="font-size: 13px; color: #0f172a; font-weight: 500; word-break: break-word; line-height: 1.4;">' + $('<div>').text(entry.message).html() + '</div>' + traceBox + '</td>' +
				'<td style="padding: 12px 14px; vertical-align: top;">' + fileHtml + '</td>' +
				'<td style="padding: 12px 14px; vertical-align: top; text-align: right; white-space: nowrap;"><div style="display: flex; gap: 4px; justify-content: flex-end;">' + traceBtn + '<button type="button" class="button button-small wpat-copy-single-error-btn" data-raw="' + $('<div>').text(rawCombined).html() + '" title="Copiar este error completo" style="padding: 0 6px; height: 26px; line-height: 24px;"><span class="dashicons dashicons-clipboard" style="font-size: 14px; width: 14px; height: 14px; line-height: 1;"></span></button></div></td>' +
			'</tr>';

			$tbody.append(rowHtml);
		});

		applyLogFilters();
	}

	function fetchErrorLogs(silent) {
		if ($('#wpat_log_entries_tbody').length === 0) {
			return;
		}

		var $btn = $('#wpat_refresh_logs_btn');
		if (!silent) {
			$btn.prop('disabled', true).find('.dashicons').addClass('dashicons-update-spin');
		}

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_get_error_logs',
				security: wpat_object.error_log_nonce
			},
			success: function(response) {
				if (!silent) {
					$btn.prop('disabled', false).find('.dashicons').removeClass('dashicons-update-spin');
				}

				if (response.success && response.data) {
					var d = response.data;
					// Actualizar tamaño de archivo
					$('#wpat_log_filesize_badge').text(d.size_fmt || '0 B');

					// Actualizar contadores
					if (d.stats) {
						$('#wpat_stat_total').text(d.stats.total || 0);
						$('#wpat_stat_fatal').text(d.stats.fatal || 0);
						$('#wpat_stat_warning').text(d.stats.warning || 0);
						$('#wpat_stat_notice').text(d.stats.notice || 0);
						$('#wpat_stat_deprecated').text(d.stats.deprecated || 0);

						$('.f-count').text(d.stats.fatal || 0);
						$('.w-count').text(d.stats.warning || 0);
						$('.n-count').text(d.stats.notice || 0);
						$('.d-count').text(d.stats.deprecated || 0);
					}

					// Actualizar consola Raw
					$('#wpat_log_raw_pre').text(d.raw || '');

					// Renderizar filas de tabla
					renderLogRows(d.entries || []);

					if (!silent) {
						showToast('Registros de error actualizados', false);
					}
				}
			},
			error: function() {
				if (!silent) {
					$btn.prop('disabled', false).find('.dashicons').removeClass('dashicons-update-spin');
					showToast('Error al conectar para actualizar logs', true);
				}
			}
		});
	}

	$(document).on('click', '#wpat_refresh_logs_btn', function(e) {
		e.preventDefault();
		fetchErrorLogs(false);
	});

	// 9. Auto-refresco en vivo (Polling)
	$(document).on('change', '#wpat_log_auto_refresh_toggle', function() {
		var isChecked = $(this).is(':checked');
		if (isChecked) {
			$('#wpat_log_live_status_label').html('<span style="color:#10b981;">● En vivo</span> (5s)');
			logPollInterval = setInterval(function() {
				fetchErrorLogs(true);
			}, 5000);
			showToast('Auto-refresco activado (cada 5s)', false);
		} else {
			$('#wpat_log_live_status_label').text('Auto-refresco (5s)');
			if (logPollInterval) {
				clearInterval(logPollInterval);
				logPollInterval = null;
			}
			showToast('Auto-refresco pausado', false);
		}
	});

	// 10. Vaciar Archivo de Log
	$(document).on('click', '#wpat_clear_log_btn', function(e) {
		e.preventDefault();
		if (!confirm('¿Estás seguro de que deseas vaciar completamente el registro debug.log? Esta acción borrará todos los errores almacenados.')) {
			return;
		}

		var $btn = $(this);
		var origHtml = $btn.html();
		$btn.prop('disabled', true).html('⏳ Vaciando...');

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_clear_error_log',
				security: wpat_object.error_log_nonce
			},
			success: function(response) {
				$btn.prop('disabled', false).html(origHtml);
				if (response.success) {
					showToast(response.data.message || 'El registro se ha vaciado correctamente', false);
					fetchErrorLogs(true);
				} else {
					showToast(response.data.message || 'No se pudo vaciar el archivo de log', true);
				}
			},
			error: function() {
				$btn.prop('disabled', false).html(origHtml);
				showToast('Error de conexión AJAX al vaciar log', true);
			}
		});
	});

	// ==========================================
	// MÓDULO: GESTOR DE ROLES Y PERMISOS (ROLE MANAGER)
	// ==========================================

	// Función para recalcular contadores de permisos (concedidos / totales)
	function updateRoleManagerCounters() {
		var totalGranted = 0;

		$('.wpat-cap-category-card').each(function() {
			var $cat = $(this);
			var catGranted = $cat.find('.wpat-cap-checkbox:checked').length;
			$cat.find('.granted-count').text(catGranted);
			totalGranted += catGranted;
		});

		$('#wpat_granted_caps_counter').text(totalGranted);
	}

	// Inicializar contadores si estamos en la vista de roles
	if ($('.wpat-role-manager-wrapper').length > 0) {
		updateRoleManagerCounters();
	}

	// 1. Cambio de Rol activo desde el Sidebar
	$(document).on('click', '.wpat-role-item', function(e) {
		e.preventDefault();
		var $item = $(this);
		var roleSlug = $item.data('role');

		if ($item.hasClass('active')) {
			return;
		}

		$('.wpat-role-item').removeClass('active').css({
			'background': 'transparent',
			'border-color': 'transparent',
			'box-shadow': 'none'
		}).find('div[style*="font-weight: 700"]').css('color', '#1e293b');

		$item.addClass('active').css({
			'background': '#ffffff',
			'border-color': '#2563eb',
			'box-shadow': '0 2px 6px rgba(37,99,235,0.1)'
		}).find('div[style*="font-weight: 700"]').css('color', '#1e40af');

		$('#wpat_current_editing_role').val(roleSlug);
		$('#wpat_active_role_slug').text(roleSlug);
		$('#wpat_save_bar_role_name').text($item.find('div[style*="font-weight: 700"]').text().trim());
		$('#wpat_active_role_title').text($item.find('div[style*="font-weight: 700"]').text().trim());

		// Botón de clonar
		$('#wpat_clone_active_role_btn').data('slug', roleSlug).data('name', $item.find('div[style*="font-weight: 700"]').text().trim());

		// Cargar capabilities vía AJAX
		$('body').css('cursor', 'wait');
		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_get_role_caps',
				security: wpat_object.role_manager_nonce,
				role: roleSlug
			},
			success: function(response) {
				$('body').css('cursor', 'default');
				if (response.success && response.data) {
					var d = response.data;
					var caps = d.capabilities || {};
					var isAdmin = d.is_admin;
					var isCore = d.is_core;

					// Mostrar/Ocultar botón eliminar
					if (isCore) {
						$('#wpat_delete_active_role_btn').hide();
					} else {
						$('#wpat_delete_active_role_btn').show().data('slug', roleSlug);
					}

					// Actualizar checkboxes
					$('.wpat-cap-checkbox').each(function() {
						var $cb = $(this);
						var cap = $cb.closest('.wpat-cap-item').data('cap');
						var hasCap = (caps[cap] === true || caps[cap] === '1' || caps[cap] === 1);

						$cb.prop('checked', hasCap);

						// Bloqueo de caps críticas si es admin
						var critCaps = ['manage_options', 'edit_users', 'promote_users', 'activate_plugins', 'edit_plugins', 'edit_theme_options', 'read'];
						if (isAdmin && critCaps.indexOf(cap) !== -1) {
							$cb.prop('disabled', true);
							$cb.closest('.wpat-cap-item').css('cursor', 'not-allowed');
						} else {
							$cb.prop('disabled', false);
							$cb.closest('.wpat-cap-item').css('cursor', 'pointer');
						}

						if (hasCap) {
							$cb.closest('.wpat-cap-item').addClass('active').css({
								'background': '#f0fdf4',
								'border-color': '#bbf7d0'
							});
						} else {
							$cb.closest('.wpat-cap-item').removeClass('active').css({
								'background': '#ffffff',
								'border-color': '#e2e8f0'
							});
						}
					});

					updateRoleManagerCounters();
				}
			},
			error: function() {
				$('body').css('cursor', 'default');
				showToast('Error de conexión al cargar permisos del rol', true);
			}
		});
	});

	// 2. Conmutar visual de checkbox individual
	$(document).on('change', '.wpat-cap-checkbox', function() {
		var $cb = $(this);
		var $item = $cb.closest('.wpat-cap-item');

		if ($cb.is(':checked')) {
			$item.addClass('active').css({
				'background': '#f0fdf4',
				'border-color': '#bbf7d0'
			});
		} else {
			$item.removeClass('active').css({
				'background': '#ffffff',
				'border-color': '#e2e8f0'
			});
		}

		updateRoleManagerCounters();
	});

	// 2.1. Desplegar / Plegar Acordeón de Categoría individual
	$(document).on('click', '.wpat-cap-cat-header', function(e) {
		if ($(e.target).closest('.wpat-cat-check-all, .wpat-cat-uncheck-all').length > 0) {
			return; // Evitar colapsar si se hace clic en los botones de marcar/desmarcar
		}
		var $header = $(this);
		var $card = $header.closest('.wpat-cap-category-card');
		var $body = $card.find('.wpat-cap-cat-body');
		var $arrow = $header.find('.wpat-cat-accordion-arrow');

		$body.slideToggle(150, function() {
			if ($body.is(':visible')) {
				$arrow.css('transform', 'rotate(0deg)');
			} else {
				$arrow.css('transform', 'rotate(-90deg)');
			}
		});
	});

	// 2.2. Desplegar Todo / Plegar Todo
	$(document).on('click', '#wpat_expand_all_cats_btn', function(e) {
		e.preventDefault();
		$('.wpat-cap-cat-body').slideDown(150);
		$('.wpat-cat-accordion-arrow').css('transform', 'rotate(0deg)');
	});

	$(document).on('click', '#wpat_collapse_all_cats_btn', function(e) {
		e.preventDefault();
		$('.wpat-cap-cat-body').slideUp(150);
		$('.wpat-cat-accordion-arrow').css('transform', 'rotate(-90deg)');
	});

	// 3. Búsqueda y filtrado en tiempo real de permisos (con auto-despliegue)
	$(document).on('input', '#wpat_cap_search_input', function() {
		var term = ($(this).val() || '').toLowerCase().trim();

		$('.wpat-cap-category-card').each(function() {
			var $cat = $(this);
			var $body = $cat.find('.wpat-cap-cat-body');
			var $arrow = $cat.find('.wpat-cat-accordion-arrow');
			var visibleInCat = 0;

			$cat.find('.wpat-cap-item').each(function() {
				var $item = $(this);
				var searchText = $item.data('search') || '';

				if (term === '' || searchText.indexOf(term) !== -1) {
					$item.show();
					visibleInCat++;
				} else {
					$item.hide();
				}
			});

			if (visibleInCat === 0 && term !== '') {
				$cat.hide();
			} else {
				$cat.show();
				if (term !== '' && visibleInCat > 0) {
					$body.slideDown(100);
					$arrow.css('transform', 'rotate(0deg)');
				}
			}
		});
	});

	// 4. Marcar / Desmarcar bloque de categoría
	$(document).on('click', '.wpat-cat-check-all', function(e) {
		e.stopPropagation();
		var cat = $(this).data('cat');
		var $card = $('.wpat-cap-category-card[data-category="' + cat + '"]');

		$card.find('.wpat-cap-checkbox:not(:disabled)').prop('checked', true).each(function() {
			$(this).closest('.wpat-cap-item').addClass('active').css({
				'background': '#f0fdf4',
				'border-color': '#bbf7d0'
			});
		});

		updateRoleManagerCounters();
	});

	$(document).on('click', '.wpat-cat-uncheck-all', function(e) {
		e.stopPropagation();
		var cat = $(this).data('cat');
		var $card = $('.wpat-cap-category-card[data-category="' + cat + '"]');

		$card.find('.wpat-cap-checkbox:not(:disabled)').prop('checked', false).each(function() {
			$(this).closest('.wpat-cap-item').removeClass('active').css({
				'background': '#ffffff',
				'border-color': '#e2e8f0'
			});
		});

		updateRoleManagerCounters();
	});

	// 5. Conceder Todos / Revocar Todos
	$(document).on('click', '#wpat_check_all_caps_btn', function(e) {
		e.preventDefault();
		$('.wpat-cap-checkbox:not(:disabled)').prop('checked', true).each(function() {
			$(this).closest('.wpat-cap-item').addClass('active').css({
				'background': '#f0fdf4',
				'border-color': '#bbf7d0'
			});
		});
		updateRoleManagerCounters();
	});

	$(document).on('click', '#wpat_uncheck_all_caps_btn', function(e) {
		e.preventDefault();
		$('.wpat-cap-checkbox:not(:disabled)').prop('checked', false).each(function() {
			$(this).closest('.wpat-cap-item').removeClass('active').css({
				'background': '#ffffff',
				'border-color': '#e2e8f0'
			});
		});
		updateRoleManagerCounters();
	});

	// 6. Guardar Permisos del Rol vía AJAX
	$(document).on('click', '#wpat_save_role_caps_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var origHtml = $btn.html();
		var roleSlug = $('#wpat_current_editing_role').val();

		var capsObj = {};
		$('.wpat-cap-checkbox').each(function() {
			var capSlug = $(this).closest('.wpat-cap-item').data('cap');
			if ($(this).is(':checked')) {
				capsObj[capSlug] = 1;
			}
		});

		$btn.prop('disabled', true).html('⏳ Guardando permisos...');

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_save_role_caps',
				security: wpat_object.role_manager_nonce,
				role: roleSlug,
				capabilities: capsObj
			},
			success: function(response) {
				$btn.prop('disabled', false).html(origHtml);
				if (response.success) {
					showToast(response.data.message || 'Permisos actualizados correctamente', false);
				} else {
					showToast(response.data.message || 'Error al guardar permisos', true);
				}
			},
			error: function() {
				$btn.prop('disabled', false).html(origHtml);
				showToast('Error de conexión AJAX al guardar permisos', true);
			}
		});
	});

	// 7. Modal Crear / Clonar Rol
	$(document).on('click', '#wpat_open_create_role_modal_btn', function(e) {
		e.preventDefault();
		$('#wpat_role_modal_title').text('Crear Nuevo Rol');
		$('#wpat_new_role_name').val('');
		$('#wpat_new_role_slug').val('');
		$('#wpat_new_role_clone_from').val('');
		$('#wpat_create_role_modal').css('display', 'flex').hide().fadeIn(150);
	});

	$(document).on('click', '#wpat_clone_active_role_btn', function(e) {
		e.preventDefault();
		var sourceSlug = $(this).data('slug') || '';
		var sourceName = $(this).data('name') || '';

		$('#wpat_role_modal_title').text('Clonar Rol: ' + sourceName);
		$('#wpat_new_role_name').val(sourceName + ' (Copia)');
		$('#wpat_new_role_slug').val(sourceSlug + '_copia');
		$('#wpat_new_role_clone_from').val(sourceSlug);
		$('#wpat_create_role_modal').css('display', 'flex').hide().fadeIn(150);
	});

	$(document).on('click', '.wpat-close-modal-btn', function(e) {
		e.preventDefault();
		$('#wpat_create_role_modal').fadeOut(150);
	});

	$(document).on('click', '#wpat_create_role_modal', function(e) {
		if ($(e.target).is('#wpat_create_role_modal')) {
			$('#wpat_create_role_modal').fadeOut(150);
		}
	});

	function submitCreateRole() {
		var $submitBtn = $('#wpat_submit_create_role_btn');
		var origText = $submitBtn.text();
		var roleName = $('#wpat_new_role_name').val().trim();

		if (!roleName) {
			showToast('Por favor introduce un nombre para el rol', true);
			$('#wpat_new_role_name').focus();
			return;
		}

		$submitBtn.prop('disabled', true).text('Creando...');

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_create_custom_role',
				security: wpat_object.role_manager_nonce,
				role_name: roleName,
				role_slug: $('#wpat_new_role_slug').val().trim(),
				clone_from: $('#wpat_new_role_clone_from').val()
			},
			success: function(response) {
				$submitBtn.prop('disabled', false).text(origText);
				if (response.success) {
					$('#wpat_create_role_modal').fadeOut(150);
					showToast(response.data.message || 'Rol creado con éxito', false);
					// Recargar la página con el nuevo rol seleccionado
					setTimeout(function() {
						window.location.href = window.location.pathname + '?page=wp-agency-toolkit&mod=role-manager&role=' + encodeURIComponent(response.data.role_slug || '');
					}, 800);
				} else {
					showToast(response.data.message || 'Error al crear el rol', true);
				}
			},
			error: function() {
				$submitBtn.prop('disabled', false).text(origText);
				showToast('Error de conexión AJAX al crear rol', true);
			}
		});
	}

	$(document).on('click', '#wpat_submit_create_role_btn', function(e) {
		e.preventDefault();
		submitCreateRole();
	});

	$(document).on('keypress', '#wpat_new_role_name, #wpat_new_role_slug', function(e) {
		if (e.which === 13) {
			e.preventDefault();
			submitCreateRole();
		}
	});

	// 8. Eliminar Rol Personalizado
	$(document).on('click', '#wpat_delete_active_role_btn', function(e) {
		e.preventDefault();
		var roleSlug = $(this).data('slug') || $('#wpat_current_editing_role').val();

		if (!confirm('¿Estás seguro de que deseas eliminar este rol personalizado? Si hay usuarios con este rol, serán reasignados automáticamente al rol "Suscriptor".')) {
			return;
		}

		var $btn = $(this);
		$btn.prop('disabled', true);

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_delete_custom_role',
				security: wpat_object.role_manager_nonce,
				role: roleSlug
			},
			success: function(response) {
				if (response.success) {
					showToast(response.data.message || 'Rol eliminado con éxito', false);
					setTimeout(function() {
						window.location.href = window.location.pathname + '?page=wp-agency-toolkit&mod=role-manager';
					}, 800);
				} else {
					$btn.prop('disabled', false);
					showToast(response.data.message || 'No se pudo eliminar el rol', true);
				}
			},
			error: function() {
				$btn.prop('disabled', false);
				showToast('Error de conexión AJAX al eliminar rol', true);
			}
		});
	});

	// 9. Restaurar Roles Nativos por Defecto
	$(document).on('click', '#wpat_reset_roles_btn', function(e) {
		e.preventDefault();
		if (!confirm('¿Estás seguro de que deseas restaurar los roles nativos de WordPress (Administrador, Editor, Autor, Colaborador, Suscriptor) a sus capacidades predeterminadas de fábrica? Esta acción sobrescribirá cualquier permiso modificado en ellos.')) {
			return;
		}

		var $btn = $(this);
		$btn.prop('disabled', true);

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_reset_default_roles',
				security: wpat_object.role_manager_nonce
			},
			success: function(response) {
				if (response.success) {
					showToast(response.data.message || 'Roles nativos restaurados a fábrica', false);
					setTimeout(function() {
						window.location.reload();
					}, 800);
				} else {
					$btn.prop('disabled', false);
					showToast(response.data.message || 'No se pudieron restaurar los roles', true);
				}
			},
			error: function() {
				$btn.prop('disabled', false);
				showToast('Error de conexión AJAX al restaurar roles', true);
			}
		});
	});

	// ==========================================
	// MÓDULO: BANNER DE COOKIES & RGPD (COOKIE-CONSENT)
	// ==========================================

	// 1. Cambio de sub-pestañas en Cookie Consent
	$(document).on('click', '.wpat-cookie-tab-btn', function(e) {
		e.preventDefault();
		var tab = $(this).data('tab');
		$('.wpat-cookie-tab-btn').removeClass('active').css({
			'border-bottom-color': 'transparent',
			'color': '#64748b'
		});
		$(this).addClass('active').css({
			'border-bottom-color': '#2563eb',
			'color': '#2563eb'
		});

		$('.wpat-cookie-tab-panel').hide();
		$('#wpat_cookie_tab_' + tab).fadeIn(200);
		$('#wpat_cookie_active_subtab').val(tab);
	});

	// 2. Usar URL de Privacidad de WordPress
	$(document).on('click', '#wpat_set_wp_privacy_url_btn', function(e) {
		e.preventDefault();
		var url = $(this).data('url');
		if (url) {
			$('#wpat_cookie_consent_policy_url').val(url);
			showToast('URL de Política de WordPress asignada', false);
		}
	});

	// 3. Copiar Shortcode al Portapapeles
	$(document).on('click', '#wpat_copy_shortcode_btn', function(e) {
		e.preventDefault();
		var shortcode = '[wpat_cookie_table]';
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(shortcode).then(function() {
				showToast('Shortcode [wpat_cookie_table] copiado al portapapeles', false);
			});
		} else {
			var $temp = $('<input>');
			$('body').append($temp);
			$temp.val(shortcode).select();
			document.execCommand('copy');
			$temp.remove();
			showToast('Shortcode copiado', false);
		}
	});

	// 4. Escáner Inteligente de Cookies vía AJAX
	$(document).on('click', '#wpat_scan_cookies_btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $status = $('#wpat_scanner_status_area');
		var $tbody = $('#wpat_scan_tbody');

		$btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin" style="animation: rotation 1.5s infinite linear;"></span> Escaneando...');
		$status.removeClass('notice-error notice-success').css({
			'display': 'block',
			'background': '#eff6ff',
			'color': '#1e40af',
			'border': '1px solid #bfdbfe'
		}).html('🔍 Analizando plugins activos, rastreadores y cookies del sitio en tiempo real...');

		$.ajax({
			url: wpat_object.ajax_url,
			type: 'POST',
			data: {
				action: 'wpat_scan_cookies',
				security: wpat_object.cookie_consent_nonce
			},
			success: function(response) {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Escanear Cookies Ahora');

				if (response.success && response.data) {
					var cookies = response.data.cookies || [];
					var total = response.data.total || 0;

					$status.css({
						'background': '#ecfdf5',
						'color': '#047857',
						'border': '1px solid #a7f3d0'
					}).html('✅ Escaneo completado: <strong>' + total + ' cookies y rastreadores</strong> identificados en tu instalación.');

					if (cookies.length > 0) {
						var html = '';
						cookies.forEach(function(c) {
							var badgeBg = '#e2e8f0';
							var badgeTx = '#475569';
							if (c.category === 'necessary') {
								badgeBg = '#eff6ff';
								badgeTx = '#1d4ed8';
							} else if (c.category === 'analytics') {
								badgeBg = '#ecfdf5';
								badgeTx = '#047857';
							} else if (c.category === 'marketing') {
								badgeBg = '#fef2f2';
								badgeTx = '#b91c1c';
							}

							html += '<tr style="border-bottom: 1px solid #f1f5f9;">';
							html += '<td style="padding: 10px 14px; font-weight: 700; color: #1e293b;"><code>' + $('<div>').text(c.name).html() + '</code></td>';
							html += '<td style="padding: 10px 14px; color: #475569;">' + $('<div>').text(c.provider).html() + '</td>';
							html += '<td style="padding: 10px 14px;"><span style="background:' + badgeBg + '; color:' + badgeTx + '; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:700;">' + $('<div>').text(c.cat_label).html() + '</span></td>';
							html += '<td style="padding: 10px 14px; color: #64748b; font-size: 12.5px;">' + $('<div>').text(c.purpose).html() + '</td>';
							html += '<td style="padding: 10px 14px; color: #475569; font-weight: 600; font-size: 12px;">' + $('<div>').text(c.expiry).html() + '</td>';
							html += '</tr>';
						});
						$tbody.html(html);
					}
					showToast('Escaneo de cookies finalizado con éxito (' + total + ' detectadas)', false);
				} else {
					$status.css({
						'background': '#fef2f2',
						'color': '#b91c1c',
						'border': '1px solid #fecaca'
					}).html('⚠️ Error durante el escaneo: ' + (response.data ? response.data.message : 'Respuesta no válida'));
					showToast('Error en el escáner de cookies', true);
				}
			},
			error: function() {
				$btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> Escanear Cookies Ahora');
				$status.css({
					'background': '#fef2f2',
					'color': '#b91c1c',
					'border': '1px solid #fecaca'
				}).html('⚠️ Error de conexión AJAX al realizar el escaneo de cookies.');
				showToast('Error de conexión AJAX', true);
			}
		});
	// 5. Incrementar Versión de Política (Forzar Re-consentimiento)
	$(document).on('click', '#wpat_bump_consent_version_btn', function(e) {
		e.preventDefault();
		var $input = $('#wpat_cookie_consent_version');
		var currentVal = parseFloat($input.val()) || 1.0;
		var nextVal = (Math.round((currentVal + 0.1) * 10) / 10).toFixed(1);
		$input.val(nextVal);
		showToast('Versión actualizada a ' + nextVal + '. Guarda los cambios para forzar el banner.', false);
	});

});


