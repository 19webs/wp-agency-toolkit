/**
 * DISEÑADOR DE CHECKOUT HIGH-CONVERSION - WP AGENCY TOOLKIT
 */
jQuery(document).ready(function($) {
	'use strict';

	// --- 1. MOBILE ORDER SUMMARY TOGGLE ---
	$(document).on('click', '.wpat-mobile-order-summary-toggle', function() {
		var $review = $('#order_review');
		var $arrow = $(this).find('.wpat-summary-arrow');
		
		$review.slideToggle(250, function() {
			if ($review.is(':visible')) {
				$arrow.text('▲');
			} else {
				$arrow.text('▼');
			}
		});
	});

	// --- 1.1 VALIDACIÓN DE CAMPOS OBLIGATORIOS POR PASO ---
	function validateStepFields($container) {
		var isValid = true;
		var $firstInvalid = null;

		$container.find('.validate-required input:visible, .validate-required select:visible, .validate-required textarea:visible, input[required]:visible, select[required]:visible').each(function() {
			var $field = $(this);
			var val = $field.val();

			if ($field.is(':checkbox') && !$field.is(':checked')) {
				isValid = false;
				$field.closest('.form-row').addClass('woocommerce-invalid');
				if (!$firstInvalid) $firstInvalid = $field;
			} else if (!val || (typeof val === 'string' && val.trim() === '')) {
				isValid = false;
				$field.closest('.form-row').addClass('woocommerce-invalid');
				$field.css('border-color', '#ef4444');
				if (!$firstInvalid) $firstInvalid = $field;
			} else {
				$field.closest('.form-row').removeClass('woocommerce-invalid').addClass('woocommerce-validated');
				$field.css('border-color', '');
			}
		});

		// Validar email si existe en este contenedor
		var $emailField = $container.find('#billing_email');
		if ($emailField.length && $emailField.is(':visible')) {
			var emailVal = $emailField.val() ? $emailField.val().trim() : '';
			var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
			if (!emailRegex.test(emailVal)) {
				isValid = false;
				$emailField.closest('.form-row').addClass('woocommerce-invalid');
				$emailField.css('border-color', '#ef4444');
				if (!$firstInvalid) $firstInvalid = $emailField;
			}
		}

		if (!isValid && $firstInvalid) {
			$('html, body').animate({
				scrollTop: $firstInvalid.offset().top - 80
			}, 300);
			$firstInvalid.focus();
		}

		return isValid;
	}

	$(document).on('input change', '.woocommerce-invalid input, .woocommerce-invalid select', function() {
		if ($(this).val()) {
			$(this).closest('.form-row').removeClass('woocommerce-invalid');
			$(this).css('border-color', '');
		}
	});

	// --- 2. MULTI-STEP NAVIGATION (NEXT / PREV BUTTONS & STEPS BAR) ---
	function goToStep(step) {
		step = parseInt(step, 10);
		if (isNaN(step) || step < 1 || step > 3) return;

		// Actualizar barra de pasos
		$('.wpat-step-item').removeClass('active');
		$('.wpat-step-item[data-step="' + step + '"]').addClass('active');

		// Mostrar panel correspondiente
		$('.wpat-step-panel').hide().removeClass('active');
		$('.wpat-step-panel[data-step="' + step + '"]').fadeIn(200).addClass('active');

		// Scroll suave al inicio del checkout
		if ($('.wpat-checkout-container').length) {
			$('html, body').animate({
				scrollTop: $('.wpat-checkout-container').offset().top - 40
			}, 300);
		}
	}

	$(document).on('click', '.wpat-next-btn', function(e) {
		e.preventDefault();
		var $currentPanel = $(this).closest('.wpat-step-panel');
		if ($currentPanel.length && !validateStepFields($currentPanel)) {
			return false;
		}

		var nextStep = $(this).data('next');
		goToStep(nextStep);
	});

	$(document).on('click', '.wpat-prev-btn', function(e) {
		e.preventDefault();
		var prevStep = $(this).data('prev');
		goToStep(prevStep);
	});

	$(document).on('click', '.wpat-step-item', function() {
		var step = $(this).data('step');
		var currentStep = $('.wpat-step-item.active').data('step') || 1;

		if (step > currentStep) {
			var $currentPanel = $('.wpat-step-panel[data-step="' + currentStep + '"]');
			if ($currentPanel.length && !validateStepFields($currentPanel)) {
				return false;
			}
		}
		goToStep(step);
	});

	// --- 2.1 ACCORDION CHECKOUT CONTROLS ---
	function toggleAccordionStep(step) {
		step = parseInt(step, 10);
		if (isNaN(step) || step < 1 || step > 3) return;

		var $targetItem = $('.wpat-accordion-item[data-accordion-step="' + step + '"]');
		if (!$targetItem.length) return;

		$('.wpat-accordion-item').not($targetItem).removeClass('active').find('.wpat-accordion-body').slideUp(200);
		$('.wpat-accordion-item').not($targetItem).find('.wpat-accordion-toggle-icon').text('▼');

		$targetItem.addClass('active').find('.wpat-accordion-body').slideDown(200);
		$targetItem.find('.wpat-accordion-toggle-icon').text('▲');

		$('html, body').animate({
			scrollTop: $targetItem.offset().top - 40
		}, 300);
	}

	$(document).on('click', '.wpat-accordion-header', function() {
		var step = $(this).data('step');
		var currentStep = $('.wpat-accordion-item.active').data('accordion-step') || 1;

		if (step > currentStep) {
			var $currentBody = $('.wpat-accordion-item[data-accordion-step="' + currentStep + '"] .wpat-accordion-body');
			if ($currentBody.length && !validateStepFields($currentBody)) {
				return false;
			}
		}
		toggleAccordionStep(step);
	});

	$(document).on('click', '.wpat-accordion-next-btn', function(e) {
		e.preventDefault();
		var $currentBody = $(this).closest('.wpat-accordion-body');
		if ($currentBody.length && !validateStepFields($currentBody)) {
			return false;
		}
		var nextStep = $(this).data('next');
		toggleAccordionStep(nextStep);
	});

	$(document).on('click', '.wpat-accordion-prev-btn', function(e) {
		e.preventDefault();
		var prevStep = $(this).data('prev');
		toggleAccordionStep(prevStep);
	});

	// --- 3. CUSTOM CLEAN COUPON SUBMIT (CHECKOUT) ---
	$(document).on('click', '#wpat_coupon_apply_btn', function(e) {
		e.preventDefault();
		var $input = $('#wpat_coupon_code_field');
		var code = $input.val() ? $input.val().trim() : '';
		var $box = $(this).closest('.wpat-custom-coupon-box, .wpat-coupon-input-group, .wpat-sidebar-card, .wpat-order-review-card');
		if (!$box.length) $box = $input.parent();

		$('.wpat-checkout-coupon-notice, .wpat-checkout-coupon-response-notice').remove();
		$('.woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message').remove();

		if (!code) {
			$input.css('border-color', '#ef4444').focus();
			var $notice = $('<div class="wpat-checkout-coupon-notice" style="color: #ef4444; font-size: 13px; font-weight: 600; margin-top: 8px; width: 100%;">Por favor, escribe un código de cupón antes de aplicar.</div>');
			$box.append($notice);
			setTimeout(function() {
				$notice.fadeOut(300, function() { $(this).remove(); });
				$input.css('border-color', '');
			}, 3500);
			return false;
		}

		var $btn = $(this);
		var origText = $btn.text();
		$btn.prop('disabled', true).text('Aplicando...');

		var applyUrl = '/?wc-ajax=apply_coupon';
		if (typeof wc_checkout_params !== 'undefined' && wc_checkout_params.wc_ajax_url) {
			applyUrl = wc_checkout_params.wc_ajax_url.toString().replace('%%endpoint%%', 'apply_coupon');
		}

		var data = {
			security: typeof wc_checkout_params !== 'undefined' ? wc_checkout_params.apply_coupon_nonce : '',
			coupon_code: code
		};

		$.ajax({
			type: 'POST',
			url: applyUrl,
			data: data,
			success: function(response) {
				$btn.prop('disabled', false).text(origText);

				if (response) {
					var $noticeWrapper = $('<div class="wpat-checkout-coupon-response-notice" style="margin-top: 10px; width: 100%;">' + response + '</div>');
					$box.append($noticeWrapper);
					if (response.indexOf('woocommerce-error') !== -1 || response.indexOf('no existe') !== -1 || response.indexOf('no es válido') !== -1) {
						$input.css('border-color', '#ef4444');
					} else {
						$input.val('');
					}
				}
				$(document.body).trigger('update_checkout');
			},
			error: function() {
				$btn.prop('disabled', false).text(origText);
				$(document.body).trigger('update_checkout');
			}
		});
	});

	// --- 4. SMART EMAIL AUTOCORRECT SUGGESTION ---
	if (typeof wpatCheckoutOptions !== 'undefined' && wpatCheckoutOptions.email_autocorrect === '1') {
		var commonDomains = {
			'gmai.com': 'gmail.com',
			'gamil.com': 'gmail.com',
			'gmial.com': 'gmail.com',
			'hotmai.com': 'hotmail.com',
			'hotmial.com': 'hotmail.com',
			'yaho.com': 'yahoo.com',
			'outloo.com': 'outlook.com'
		};

		$(document).on('blur', '#billing_email', function() {
			var email = $(this).val().trim();
			$('.wpat-email-autocorrect-notice').remove();

			if (email && email.indexOf('@') !== -1) {
				var parts = email.split('@');
				var domain = parts[1].toLowerCase();

				if (commonDomains[domain]) {
					var suggestedEmail = parts[0] + '@' + commonDomains[domain];
					var htmlNotice = '<div class="wpat-email-autocorrect-notice">¿Quisiste decir <a class="wpat-apply-email-suggestion" data-suggested="' + suggestedEmail + '">' + suggestedEmail + '</a>?</div>';
					$(this).after(htmlNotice);
				}
			}
		});

		$(document).on('click', '.wpat-apply-email-suggestion', function(e) {
			e.preventDefault();
			var suggested = $(this).data('suggested');
			$('#billing_email').val(suggested).trigger('change');
			$('.wpat-email-autocorrect-notice').remove();
		});
	}

	// --- 5. SPAIN POSTAL CODE AUTO-FILL (PROVINCE & CITY DETECTOR) ---
	if (typeof wpatCheckoutOptions !== 'undefined' && wpatCheckoutOptions.autofill_spain_cp === '1' && wpatCheckoutOptions.spain_provinces) {
		function handleSpainPostcode(type) {
			var countryField = $('#' + type + '_country');
			var country = countryField.val();
			if (country !== 'ES') return;

			var cpField = $('#' + type + '_postcode');
			var cp = cpField.val() ? cpField.val().trim() : '';
			if (cp.length < 2) return;

			var prefix = cp.substring(0, 2);
			var provinceCode = wpatCheckoutOptions.spain_provinces[prefix];

			if (provinceCode) {
				var $state = $('#' + type + '_state');
				if ($state.length && $state.val() !== provinceCode) {
					$state.val(provinceCode).trigger('change');
					if ($.fn.select2 && $state.hasClass('select2-hidden-accessible')) {
						$state.trigger('change.select2');
					}
				}
			}
		}

		$(document).on('input blur change', '#billing_postcode', function() {
			handleSpainPostcode('billing');
		});

		$(document).on('input blur change', '#shipping_postcode', function() {
			handleSpainPostcode('shipping');
		});
	}

	// --- 5.1 CHECKOUT ITEM QUANTITY CONTROLS (+ / - / ×) ---
	$(document).on('click', '.wpat-checkout-qty-btn, .wpat-checkout-remove-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var cartKey = $btn.data('cart-key') || $btn.attr('data-cart-key');
		if (!cartKey) return;

		var isPlus = $btn.hasClass('wpat-checkout-qty-plus');
		var isMinus = $btn.hasClass('wpat-checkout-qty-minus');
		var isRemove = $btn.hasClass('wpat-checkout-remove-btn');

		var $controls = $btn.closest('.wpat-checkout-qty-controls');
		var $valSpan = $controls.find('.wpat-checkout-qty-val');
		var currentQty = parseInt($valSpan.text(), 10) || 1;
		var newQty = currentQty;

		if (isPlus) {
			newQty = currentQty + 1;
		} else if (isMinus) {
			newQty = Math.max(0, currentQty - 1);
		} else if (isRemove) {
			newQty = 0;
		}

		$controls.css('opacity', '0.4');

		$.ajax({
			type: 'POST',
			url: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.ajax_url : '/wp-admin/admin-ajax.php',
			data: {
				action: 'wpat_update_checkout_qty',
				security: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.nonce : '',
				cart_key: cartKey,
				qty: newQty
			},
			success: function(response) {
				$(document.body).trigger('update_checkout');
			},
			error: function() {
				$(document.body).trigger('update_checkout');
			}
		});
	});

	// --- 6. CART DESIGNER: QUANTITY BUTTONS (+ / -) & AUTO-UPDATE CART ---
	var cartAutoUpdateTimer = null;

	function triggerAutoCartUpdate() {
		var $updateBtn = $('button[name="update_cart"], input[name="update_cart"], .wpat-cart-update-btn');
		$updateBtn.prop('disabled', false).removeClass('disabled').removeAttr('disabled');

		clearTimeout(cartAutoUpdateTimer);
		cartAutoUpdateTimer = setTimeout(function() {
			if ($updateBtn.length) {
				$('.wpat-cart-layout-wrapper').css({ 'opacity': '0.5', 'pointer-events': 'none' });
				$updateBtn.trigger('click');
			}
		}, 550);
	}

	$(document).on('click', '.wpat-qty-plus', function(e) {
		e.preventDefault();
		var $box = $(this).closest('.wpat-cart-table-qty-box, .wpat-cart-modern-qty-box, .quantity, td.product-quantity');
		var $input = $box.find('input.qty');
		if (!$input.length) $input = $(this).siblings('.quantity').find('input.qty');
		if (!$input.length) $input = $(this).siblings('input.qty');

		var val = parseInt($input.val(), 10) || 1;
		var max = parseInt($input.attr('max'), 10);
		if (isNaN(max) || val < max) {
			$input.val(val + 1).trigger('change');
			triggerAutoCartUpdate();
		}
	});

	$(document).on('click', '.wpat-qty-minus', function(e) {
		e.preventDefault();
		var $box = $(this).closest('.wpat-cart-table-qty-box, .wpat-cart-modern-qty-box, .quantity, td.product-quantity');
		var $input = $box.find('input.qty');
		if (!$input.length) $input = $(this).siblings('.quantity').find('input.qty');
		if (!$input.length) $input = $(this).siblings('input.qty');

		var val = parseInt($input.val(), 10) || 1;
		var min = parseInt($input.attr('min'), 10);
		if (isNaN(min)) min = 1;
		if (val > min) {
			$input.val(val - 1).trigger('change');
			triggerAutoCartUpdate();
		}
	});

	$(document).on('input change', 'input.qty', function(e) {
		if (e.originalEvent) {
			triggerAutoCartUpdate();
		}
	});

	// Enable update cart button before submit and dim layout wrapper
	$(document).on('click', '.wpat-cart-update-btn, button[name="update_cart"]', function() {
		$(this).prop('disabled', false).removeAttr('disabled');
		$('.wpat-cart-layout-wrapper').css({ 'opacity': '0.5', 'pointer-events': 'none' });
	});

	// --- 6.1 CART COUPON SUBMIT (AJAX & NOTICES) ---
	$(document).on('click', '.wpat-cart-coupon-btn, button[name="apply_coupon"]', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var $input = $('#coupon_code, input[name="coupon_code"]');
		var code = $input.val() ? $input.val().trim() : '';
		var $box = $btn.closest('.wpat-cart-coupon-box, .wpat-cart-actions-bar');
		if (!$box.length) $box = $input.parent();

		$('.wpat-cart-coupon-notice, .wpat-cart-coupon-response-notice').remove();
		$('.wpat-cart-container .woocommerce-error, .wpat-cart-container .woocommerce-message').remove();

		if (!code) {
			$input.css('border-color', '#ef4444').focus();
			var $notice = $('<div class="wpat-cart-coupon-notice" style="color: #ef4444; font-size: 13px; font-weight: 600; margin-top: 6px; width: 100%;">Por favor, escribe un código de cupón antes de aplicar.</div>');
			$box.append($notice);

			setTimeout(function() {
				$notice.fadeOut(300, function() { $(this).remove(); });
				$input.css('border-color', '');
			}, 3500);
			return false;
		}

		var origText = $btn.text();
		$btn.prop('disabled', true).text('Aplicando...');

		$.ajax({
			type: 'POST',
			url: typeof wc_cart_params !== 'undefined' ? wc_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'apply_coupon') : '/?wc-ajax=apply_coupon',
			data: {
				coupon_code: code,
				security: typeof wc_cart_params !== 'undefined' ? wc_cart_params.apply_coupon_nonce : ''
			},
			success: function(response) {
				$btn.prop('disabled', false).text(origText);
				if (response) {
					var $noticeWrapper = $('<div class="wpat-cart-coupon-response-notice" style="margin-top: 10px; width: 100%;">' + response + '</div>');
					$box.append($noticeWrapper);
					if (response.indexOf('woocommerce-error') !== -1 || response.indexOf('no existe') !== -1 || response.indexOf('no es válido') !== -1) {
						$input.css('border-color', '#ef4444');
					} else {
						$input.val('');
						$('.wpat-cart-layout-wrapper').css({ 'opacity': '0.5', 'pointer-events': 'none' });
						window.location.reload();
					}
				}
			},
			error: function() {
				$btn.prop('disabled', false).text(origText);
				window.location.reload();
			}
		});
	});

	// --- 6.2 VACIAR CARRITO (EMPTY CART) AJAX ---
	$(document).on('click', '#wpat_empty_cart_btn, .wpat-empty-cart-btn', function(e) {
		e.preventDefault();
		if (!confirm('¿Estás seguro de que deseas vaciar tu carrito?')) {
			return false;
		}

		var $btn = $(this);
		$btn.prop('disabled', true).text('Vaciando...');
		$('.wpat-cart-layout-wrapper').css({ 'opacity': '0.4', 'pointer-events': 'none' });

		$.ajax({
			type: 'POST',
			url: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.ajax_url : '/wp-admin/admin-ajax.php',
			data: {
				action: 'wpat_empty_cart_ajax',
				security: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.nonce : ''
			},
			success: function(response) {
				if (response && response.success && response.data.empty_html) {
					$('.wpat-cart-container').replaceWith(response.data.empty_html);
				} else {
					window.location.reload();
				}
			},
			error: function() {
				window.location.reload();
			}
		});
	});

	// Detectar si la lista de items quedó a 0 tras actualizar/eliminar
	$(document.body).on('updated_wc_div updated_cart_totals removed_from_cart', function() {
		var $cartForm = $('.woocommerce-cart-form');
		if ($cartForm.length) {
			var remainingItems = $cartForm.find('.cart_item, .woocommerce-cart-form__cart-item, .wpat-cart-modern-card').length;
			if (remainingItems === 0) {
				$.ajax({
					type: 'POST',
					url: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.ajax_url : '/wp-admin/admin-ajax.php',
					data: {
						action: 'wpat_empty_cart_ajax',
						security: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.nonce : ''
					},
					success: function(response) {
						if (response && response.success && response.data.empty_html) {
							$('.wpat-cart-container').replaceWith(response.data.empty_html);
						} else {
							window.location.reload();
						}
					},
					error: function() {
						window.location.reload();
					}
				});
			}
		}
	});

	// --- 7. CART DESIGNER: SLIDE-OUT DRAWER CART ---
	function openCartDrawer() {
		$('.wpat-cart-drawer-panel').addClass('open');
		$('.wpat-drawer-overlay').addClass('active');
		$('body').addClass('wpat-drawer-open');
	}

	function closeCartDrawer() {
		$('.wpat-cart-drawer-panel').removeClass('open');
		$('.wpat-drawer-overlay').removeClass('active');
		$('body').removeClass('wpat-drawer-open');
	}

	$(document).on('click', '.wpat-drawer-close-btn, .wpat-drawer-overlay', function(e) {
		e.preventDefault();
		closeCartDrawer();
	});

	$(document).on('click', '.wpat-open-drawer-cart', function(e) {
		e.preventDefault();
		openCartDrawer();
	});

	// Auto-abrir mini-carrito deslizable al añadir producto (vía AJAX, recarga tras añadir o submit)
	if (typeof wpatCheckoutOptions !== 'undefined' && wpatCheckoutOptions.drawer_auto_open === '1') {
		if (wpatCheckoutOptions.just_added === '1') {
			setTimeout(function() {
				openCartDrawer();
			}, 350);
		}
	}

	$(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
		if (typeof wpatCheckoutOptions !== 'undefined' && wpatCheckoutOptions.drawer_auto_open === '1') {
			if (fragments && fragments['div.wpat-drawer-cart-body']) {
				$('.wpat-drawer-cart-body').replaceWith(fragments['div.wpat-drawer-cart-body']);
			}
			if (fragments && fragments['span.wpat-drawer-cart-count']) {
				$('.wpat-drawer-cart-count').replaceWith(fragments['span.wpat-drawer-cart-count']);
			}
			openCartDrawer();
		}
	});

	$(document).on('submit', 'form.cart', function() {
		if (typeof wpatCheckoutOptions !== 'undefined' && wpatCheckoutOptions.drawer_auto_open === '1') {
			$(document).one('ajaxComplete', function() {
				setTimeout(function() {
					openCartDrawer();
				}, 400);
			});
		}
	});

	// --- 7.1 DRAWER CART AJAX QUANTITY & REMOVAL ---
	$(document).on('click', '.wpat-drawer-qty-btn, .wpat-drawer-remove-btn', function(e) {
		e.preventDefault();
		var $btn = $(this);
		var cartKey = $btn.data('cart-key') || $btn.attr('data-cart-key') || $btn.attr('data-cart_item_key');
		if (!cartKey) return;

		var isPlus = $btn.hasClass('wpat-drawer-qty-plus');
		var isMinus = $btn.hasClass('wpat-drawer-qty-minus');
		var isRemove = $btn.hasClass('wpat-drawer-remove-btn');

		var $item = $btn.closest('.wpat-drawer-item');
		var $valSpan = $item.find('.wpat-drawer-qty-val');
		var currentQty = parseInt($valSpan.text(), 10) || 1;
		var newQty = currentQty;

		if (isPlus) {
			newQty = currentQty + 1;
		} else if (isMinus) {
			newQty = Math.max(0, currentQty - 1);
		} else if (isRemove) {
			newQty = 0;
		}

		$item.css('opacity', '0.4');

		$.ajax({
			type: 'POST',
			url: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.ajax_url : '/wp-admin/admin-ajax.php',
			data: {
				action: 'wpat_update_checkout_qty',
				security: typeof wpatCheckoutOptions !== 'undefined' ? wpatCheckoutOptions.nonce : '',
				cart_key: cartKey,
				qty: newQty
			},
			success: function(response) {
				if (response && response.success && response.data) {
					if (response.data.fragments) {
						if (response.data.fragments['div.wpat-drawer-cart-body']) {
							$('.wpat-drawer-cart-body').replaceWith(response.data.fragments['div.wpat-drawer-cart-body']);
						}
						if (response.data.fragments['span.wpat-drawer-cart-count']) {
							$('.wpat-drawer-cart-count').replaceWith(response.data.fragments['span.wpat-drawer-cart-count']);
						}
					} else {
						if (response.data.cart_count !== undefined) {
							$('.wpat-drawer-cart-count').text(response.data.cart_count);
						}
					}
					$(document.body).trigger('wc_fragment_refresh');
					$(document.body).trigger('update_checkout');
				} else {
					window.location.reload();
				}
			},
			error: function() {
				window.location.reload();
			}
		});
	});
});
